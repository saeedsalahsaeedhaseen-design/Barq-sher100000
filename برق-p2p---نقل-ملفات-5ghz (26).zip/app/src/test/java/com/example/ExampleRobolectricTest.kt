package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToIndex
import androidx.compose.ui.test.performScrollToNode
import androidx.test.core.app.ApplicationProvider
import com.example.data.DeviceMediaRepository
import com.example.data.InstalledAppsRepository
import com.example.model.ChunkSizeOption
import com.example.model.FileCategory
import com.example.model.FileTransferStatus
import com.example.model.TransferDirection
import com.example.model.TransferFileItem
import com.example.network.P2PChunkServer
import com.example.service.BarqTransferForegroundService
import com.example.util.Sha256Util
import com.example.viewmodel.P2PTransferViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.math.max
import kotlin.random.Random

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun verifyAppNameAndBranding() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("برق sher", appName)
        composeTestRule.onAllNodesWithText("برق sher", substring = true).onFirst().assertIsDisplayed()
        composeTestRule.onAllNodesWithText("جميع الحقوق محفوظة © saeed", substring = true).onFirst().assertIsDisplayed()
    }

    @Test
    fun verifyAllNineNavigationTabsAndSendFolderButtons() {
        val navTabs = listOf(
            "bottom_nav_HOME",
            "bottom_nav_APPS",
            "bottom_nav_IMAGES",
            "bottom_nav_VIDEOS",
            "bottom_nav_AUDIO",
            "bottom_nav_FILES",
            "bottom_nav_SEND",
            "bottom_nav_RECEIVE",
            "bottom_nav_HISTORY"
        )

        // Verify Home screen has dedicated "إرسال مجلد كامل" button
        composeTestRule.onNodeWithTag("home_send_entire_folder_button").assertExists()

        // Verify all 9 tabs exist in the scrollable bottom navigation bar and test navigating through them
        for (tag in navTabs) {
            composeTestRule.onNodeWithTag("main_bottom_tabs_row")
                .performScrollToNode(hasTestTag(tag))
            composeTestRule.onNodeWithTag(tag).assertExists()

            if (tag == "bottom_nav_APPS") {
                composeTestRule.onNodeWithTag(tag).performClick()
                composeTestRule.waitForIdle()
                composeTestRule.onNodeWithTag("refresh_installed_apps_button").assertExists()
            } else if (tag == "bottom_nav_SEND") {
                composeTestRule.onNodeWithTag(tag).performClick()
                composeTestRule.waitForIdle()
                composeTestRule.onNodeWithTag("send_pick_entire_folder_button")
                    .performScrollTo()
                    .assertExists()
                composeTestRule.onNodeWithTag("start_live_sending_button")
                    .performScrollTo()
                    .performClick()
                composeTestRule.waitForIdle()
                composeTestRule.onNodeWithText(
                    "الرجاء اختيار ملف واحد على الأقل من جهازك قبل بدء الإرسال",
                    substring = true
                ).assertExists()
            }
        }
    }

    @Test
    fun verifyInstalledAppsRepositoryReadsPackageManager() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val apps = InstalledAppsRepository.loadInstalledSharableApps(context, includeSystemApps = true)
        assertNotNull(apps)
    }

    @Test
    fun verifyRealMultiFileChunkedTransferAndSha256Integrity() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempDir = File(context.cacheDir, "p2p_real_test_${System.currentTimeMillis()}").apply { mkdirs() }
        val receiveDir = File(tempDir, "received").apply { mkdirs() }
        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        try {
            // Create 4 real files representing Image, Audio, Document, and multi-chunk APK
            val imgFile = File(tempDir, "camera_photo.jpg").apply {
                writeBytes(Random(42).nextBytes(24_500))
            }
            val audioFile = File(tempDir, "voice_track.mp3").apply {
                writeBytes(Random(43).nextBytes(48_200))
            }
            val docFile = File(tempDir, "project_spec.pdf").apply {
                writeBytes("%PDF-1.7 Real Document Content ".repeat(800).toByteArray())
            }
            // 180 KB APK file -> 3 chunks when using 64 KB chunk size
            val apkFile = File(tempDir, "base_release.apk").apply {
                writeBytes(Random(44).nextBytes(180 * 1024 + 321))
            }

            val chunkOption = ChunkSizeOption.CHUNK_64KB
            val chunkSizeBytes = chunkOption.bytes.toLong()
            val sourceFiles = listOf(
                Pair(imgFile, FileCategory.IMAGE),
                Pair(audioFile, FileCategory.AUDIO),
                Pair(docFile, FileCategory.DOCUMENT),
                Pair(apkFile, FileCategory.GAME_APK)
            )

            val transferItems = sourceFiles.mapIndexed { idx, (file, cat) ->
                val sha = Sha256Util.computeFileSha256(file)
                assertTrue("SHA-256 should be 64 hex chars", sha.length == 64)
                val totalChunks = ((file.length() + chunkSizeBytes - 1) / chunkSizeBytes).toInt()
                TransferFileItem(
                    id = "test_item_$idx",
                    name = file.name,
                    sizeBytes = file.length(),
                    category = cat,
                    localFile = file,
                    totalChunks = totalChunks,
                    completedChunks = 0,
                    sha256Expected = sha
                )
            }

            var isSenderReady = false
            val sessionCode = "BRQ-7788"

            val server = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { sessionCode },
                isSenderReadyProvider = { isSenderReady },
                chunkSizeProvider = { chunkOption },
                filesProvider = { transferItems },
                onChunkServed = { _, _, _ -> }
            )
            val port = server.startServer(0)

            try {
                // Wait briefly for server socket to bind
                Thread.sleep(100)

                // 1. Verify /api/manifest rejects connection when sender is NOT ready (HTTP 403)
                val unreadyConn = (URL("http://127.0.0.1:$port/api/manifest?code=$sessionCode").openConnection() as HttpURLConnection)
                assertEquals(403, unreadyConn.responseCode)
                unreadyConn.disconnect()

                // 2. Activate Sender Ready state, verify wrong code is still rejected (HTTP 403)
                isSenderReady = true
                val wrongCodeConn = (URL("http://127.0.0.1:$port/api/manifest?code=BRQ-0000").openConnection() as HttpURLConnection)
                assertEquals(403, wrongCodeConn.responseCode)
                wrongCodeConn.disconnect()

                // 3. Connect with valid session code and parse manifest
                val manifestConn = (URL("http://127.0.0.1:$port/api/manifest?code=$sessionCode").openConnection() as HttpURLConnection)
                assertEquals(200, manifestConn.responseCode)
                val manifestBody = manifestConn.inputStream.bufferedReader().use { it.readText() }
                manifestConn.disconnect()

                val json = JSONObject(manifestBody)
                assertEquals(sessionCode, json.getString("sessionCode"))
                val filesArray = json.getJSONArray("files")
                assertEquals(4, filesArray.length())

                // 4. Download all 4 files chunk-by-chunk (including resumable RandomAccessFile writes)
                for (i in 0 until filesArray.length()) {
                    val fObj = filesArray.getJSONObject(i)
                    val fileId = fObj.getString("id")
                    val fileName = fObj.getString("name")
                    val expectedSize = fObj.getLong("sizeBytes")
                    val expectedSha256 = fObj.getString("sha256")
                    val totalChunks = fObj.getInt("totalChunks")

                    val partFile = File(receiveDir, "$fileName.part")
                    val finalFile = File(receiveDir, fileName)

                    for (chunkIdx in 0 until totalChunks) {
                        val chunkUrl = "http://127.0.0.1:$port/api/chunk?code=$sessionCode&fileId=$fileId&chunkIndex=$chunkIdx&chunkSize=$chunkSizeBytes"
                        val chunkConn = (URL(chunkUrl).openConnection() as HttpURLConnection)
                        assertEquals(200, chunkConn.responseCode)
                        val bytes = chunkConn.inputStream.use { it.readBytes() }
                        chunkConn.disconnect()

                        // Write chunk at exact offset using RandomAccessFile (same mechanism used for Pause/Resume)
                        RandomAccessFile(partFile, "rw").use { raf ->
                            raf.seek(chunkIdx.toLong() * chunkSizeBytes)
                            raf.write(bytes)
                        }
                    }

                    assertTrue(partFile.renameTo(finalFile))
                    assertEquals("File size must match 100% for $fileName", expectedSize, finalFile.length())
                    val actualSha256 = Sha256Util.computeFileSha256(finalFile)
                    assertEquals("SHA-256 must match 100% for $fileName", expectedSha256, actualSha256)
                    assertFalse(partFile.exists())
                }
            } finally {
                server.stopServer()
            }
        } finally {
            serverScope.cancel()
            tempDir.deleteRecursively()
        }
    }

    @Test
    fun verifyWholeFolderRecursiveTransferWithEmptyDirsAndDuplicateHandling() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempRoot = File(context.cacheDir, "folder_tree_test_${System.currentTimeMillis()}").apply { mkdirs() }
        val sourceRootFolder = File(tempRoot, "BarqProjectFolder").apply { mkdirs() }
        val receiveBaseDir = File(tempRoot, "Downloads_BarqSher").apply { mkdirs() }
        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        try {
            // Build a multi-level folder structure:
            // BarqProjectFolder/
            //   README.md (3 KB)
            //   empty_note.txt (0 bytes)
            //   EmptySubFolder/ (empty directory)
            //   assets/
            //     banner.png (95 KB)
            //     nested_empty/ (empty directory)
            //     videos/
            //       intro_clip.mp4 (420 KB)
            val readmeBytes = "# Barq Sher Whole Folder Transfer\n".repeat(90).toByteArray()
            val bannerBytes = Random(101).nextBytes(95 * 1024 + 17)
            val videoBytes = Random(202).nextBytes(420 * 1024 + 513)

            File(sourceRootFolder, "README.md").writeBytes(readmeBytes)
            File(sourceRootFolder, "empty_note.txt").writeBytes(ByteArray(0))
            File(sourceRootFolder, "EmptySubFolder").mkdirs()

            val assetsDir = File(sourceRootFolder, "assets").apply { mkdirs() }
            File(assetsDir, "banner.png").writeBytes(bannerBytes)
            File(assetsDir, "nested_empty").mkdirs()

            val videosDir = File(assetsDir, "videos").apply { mkdirs() }
            File(videosDir, "intro_clip.mp4").writeBytes(videoBytes)

            val chunkOption = ChunkSizeOption.CHUNK_256KB
            val scanResult = DeviceMediaRepository.scanLocalFolderForTransfer(
                rootDir = sourceRootFolder,
                chunkSizeBytes = chunkOption.bytes
            )

            assertNullOrEmptyError(scanResult.errorMessage)
            val batchInfo = scanResult.batchInfo
            assertNotNull("FolderBatchInfo must not be null", batchInfo)
            assertEquals("BarqProjectFolder", batchInfo!!.rootFolderName)
            assertEquals("Should detect 4 files (including 0-byte file)", 4, batchInfo.totalFilesCount)
            assertEquals("Should detect 2 empty folders", 2, batchInfo.emptyFoldersCount)
            assertEquals("Total items (4 files + 2 empty folders) = 6", 6, scanResult.transferItems.size)

            // Compute expected SHA-256 for each item (just as startLiveChunkedTransfer does)
            val preparedItems = scanResult.transferItems.map { item ->
                val sha = when {
                    item.isDirectory -> Sha256Util.EMPTY_DIR_SHA256
                    item.sizeBytes == 0L -> Sha256Util.EMPTY_BYTES_SHA256
                    item.localFile != null -> Sha256Util.computeFileSha256(item.localFile)
                    else -> ""
                }
                item.copy(sha256Expected = sha)
            }

            val sessionCode = "BRQ-9100"
            val server = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { sessionCode },
                isSenderReadyProvider = { true },
                chunkSizeProvider = { chunkOption },
                filesProvider = { preparedItems },
                onChunkServed = { _, _, _ -> }
            )
            val port = server.startServer(0)

            try {
                Thread.sleep(100)

                // Verify manifest contains relativePath, rootFolderName, and isDirectory
                val manifestConn = (URL("http://127.0.0.1:$port/api/manifest?code=$sessionCode").openConnection() as HttpURLConnection)
                assertEquals(200, manifestConn.responseCode)
                val manifestJson = JSONObject(manifestConn.inputStream.bufferedReader().use { it.readText() })
                manifestConn.disconnect()

                val manifestFiles = manifestJson.getJSONArray("files")
                assertEquals(6, manifestFiles.length())

                // Receive Session #1: Recreate folder structure inside receiveBaseDir/BarqProjectFolder/...
                val completedSession1 = mutableListOf<TransferFileItem>()
                val failedSession1 = mutableListOf<String>()
                var currentItems1 = preparedItems
                val anyFailed1 = P2PTransferViewModel.executeHighSpeedReceiveSession(
                    hostIp = "127.0.0.1",
                    hostPort = port,
                    sessionCode = sessionCode,
                    chunkSizeBytes = chunkOption.bytes,
                    downloadDir = receiveBaseDir,
                    itemsProvider = { currentItems1 },
                    isPausedProvider = { false },
                    onFileUpdated = { fileId, _, _, transform ->
                        synchronized(completedSession1) {
                            currentItems1 = currentItems1.map { if (it.id == fileId) transform(it) else it }
                        }
                    },
                    onFileCompleted = { item, _ ->
                        synchronized(completedSession1) { completedSession1.add(item) }
                    },
                    onFileFailed = { _, err ->
                        synchronized(failedSession1) { failedSession1.add(err) }
                    }
                )

                assertFalse("All items in session 1 must succeed without failure: $failedSession1", anyFailed1)
                assertEquals(0, failedSession1.size)
                assertEquals(6, completedSession1.size)
                assertTrue(completedSession1.all { it.status == FileTransferStatus.COMPLETED && it.sha256Verified })

                // Verify recreated directory tree on receiver
                val recreatedRoot1 = File(receiveBaseDir, "BarqProjectFolder")
                assertTrue("Root folder must exist", recreatedRoot1.exists() && recreatedRoot1.isDirectory)
                assertTrue("EmptySubFolder must be recreated", File(recreatedRoot1, "EmptySubFolder").isDirectory)
                assertTrue("assets/nested_empty must be recreated", File(recreatedRoot1, "assets/nested_empty").isDirectory)

                val receivedReadme = File(recreatedRoot1, "README.md")
                val receivedEmptyNote = File(recreatedRoot1, "empty_note.txt")
                val receivedBanner = File(recreatedRoot1, "assets/banner.png")
                val receivedVideo = File(recreatedRoot1, "assets/videos/intro_clip.mp4")

                assertTrue(receivedReadme.exists() && receivedReadme.readBytes().contentEquals(readmeBytes))
                assertTrue(receivedEmptyNote.exists() && receivedEmptyNote.length() == 0L)
                assertTrue(receivedBanner.exists() && receivedBanner.readBytes().contentEquals(bannerBytes))
                assertTrue(receivedVideo.exists() && receivedVideo.readBytes().contentEquals(videoBytes))

                // Receive Session #2 into the SAME downloadDir -> Must deduplicate root folder as "BarqProjectFolder (1)"
                val completedSession2 = mutableListOf<TransferFileItem>()
                var currentItems2 = preparedItems
                val anyFailed2 = P2PTransferViewModel.executeHighSpeedReceiveSession(
                    hostIp = "127.0.0.1",
                    hostPort = port,
                    sessionCode = sessionCode,
                    chunkSizeBytes = chunkOption.bytes,
                    downloadDir = receiveBaseDir,
                    itemsProvider = { currentItems2 },
                    isPausedProvider = { false },
                    onFileUpdated = { fileId, _, _, transform ->
                        synchronized(completedSession2) {
                            currentItems2 = currentItems2.map { if (it.id == fileId) transform(it) else it }
                        }
                    },
                    onFileCompleted = { item, _ ->
                        synchronized(completedSession2) { completedSession2.add(item) }
                    },
                    onFileFailed = { _, _ -> }
                )
                assertFalse(anyFailed2)
                assertEquals(6, completedSession2.size)

                val recreatedRoot2 = File(receiveBaseDir, "BarqProjectFolder (1)")
                assertTrue("Duplicate root folder must be created as 'BarqProjectFolder (1)'", recreatedRoot2.exists() && recreatedRoot2.isDirectory)
                assertTrue(File(recreatedRoot2, "EmptySubFolder").isDirectory)
                assertTrue(File(recreatedRoot2, "assets/videos/intro_clip.mp4").readBytes().contentEquals(videoBytes))
            } finally {
                server.stopServer()
            }
        } finally {
            serverScope.cancel()
            tempRoot.deleteRecursively()
        }
    }

    @Test
    fun benchmarkTransferSpeedBeforeVsAfterOptimization() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val benchRoot = File(context.cacheDir, "speed_bench_${System.currentTimeMillis()}").apply { mkdirs() }
        val legacyOutDir = File(benchRoot, "legacy_out").apply { mkdirs() }
        val optimizedOutDir = File(benchRoot, "optimized_out").apply { mkdirs() }
        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        try {
            // Prepare a realistic mixed dataset:
            // - 1 large binary file (12 MB)
            // - 24 small/medium files inside a folder (total ~3 MB)
            // Total payload = ~15 MB
            val largeFileBytes = Random(555).nextBytes(12 * 1024 * 1024)
            val largeFile = File(benchRoot, "game_update_bundle.apk").apply {
                writeBytes(largeFileBytes)
            }
            val largeSha = Sha256Util.computeFileSha256(largeFile)

            val smallFiles = (1..24).map { idx ->
                val bytes = Random(1000 + idx).nextBytes(128 * 1024) // 128 KB each
                val f = File(benchRoot, "photo_$idx.jpg").apply { writeBytes(bytes) }
                Pair(f, Sha256Util.computeFileSha256(f))
            }

            val allItemsForLegacy = mutableListOf<TransferFileItem>()
            val legacyChunkSize = ChunkSizeOption.CHUNK_256KB.bytes
            allItemsForLegacy.add(
                TransferFileItem(
                    id = "bench_large",
                    name = largeFile.name,
                    sizeBytes = largeFile.length(),
                    category = FileCategory.GAME_APK,
                    localFile = largeFile,
                    totalChunks = ((largeFile.length() + legacyChunkSize - 1) / legacyChunkSize).toInt(),
                    completedChunks = 0,
                    sha256Expected = largeSha
                )
            )
            smallFiles.forEachIndexed { idx, (f, sha) ->
                allItemsForLegacy.add(
                    TransferFileItem(
                        id = "bench_small_$idx",
                        name = f.name,
                        relativePath = "Album/${f.name}",
                        rootFolderName = "Album",
                        sizeBytes = f.length(),
                        category = FileCategory.IMAGE,
                        localFile = f,
                        totalChunks = 1,
                        completedChunks = 0,
                        sha256Expected = sha
                    )
                )
            }

            val totalPayloadBytes = allItemsForLegacy.sumOf { it.sizeBytes }
            val sessionCode = "BRQ-5500"

            val server = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { sessionCode },
                isSenderReadyProvider = { true },
                chunkSizeProvider = { ChunkSizeOption.AUTO_MAX },
                filesProvider = { allItemsForLegacy },
                onChunkServed = { _, _, _ -> }
            )
            val port = server.startServer(0)

            try {
                Thread.sleep(100)

                // =========================================================================
                // 1. BEFORE OPTIMIZATION (Legacy Approach):
                //    - Sequential file-by-file, chunk-by-chunk HTTP requests with Connection: close
                //    - Unbuffered 8 KB RandomAccessFile writes on every socket read
                //    - Second full-file disk read at the end to compute SHA-256
                // =========================================================================
                val legacyStartNano = System.nanoTime()
                for (item in allItemsForLegacy) {
                    val destFile = File(legacyOutDir, item.name)
                    val partFile = File(legacyOutDir, "${item.name}.part")
                    val totalChunks = max(1, ((item.sizeBytes + legacyChunkSize - 1) / legacyChunkSize).toInt())
                    for (cIdx in 0 until totalChunks) {
                        val url = URL("http://127.0.0.1:$port/api/chunk?code=$sessionCode&fileId=${item.id}&chunkIndex=$cIdx&chunkSize=$legacyChunkSize")
                        val conn = (url.openConnection() as HttpURLConnection).apply {
                            setRequestProperty("Connection", "close")
                        }
                        assertEquals(200, conn.responseCode)
                        RandomAccessFile(partFile, "rw").use { raf ->
                            raf.seek(cIdx.toLong() * legacyChunkSize)
                            val buf = ByteArray(8192)
                            conn.inputStream.use { input ->
                                while (true) {
                                    val r = input.read(buf)
                                    if (r <= 0) break
                                    raf.write(buf, 0, r)
                                }
                            }
                        }
                        conn.disconnect()
                    }
                    partFile.renameTo(destFile)
                    // Second pass disk read for SHA-256 (as old code did)
                    val sha = Sha256Util.computeFileSha256(destFile)
                    assertEquals(item.sha256Expected, sha)
                }
                val legacyElapsedSec = max(0.001, (System.nanoTime() - legacyStartNano) / 1_000_000_000.0)
                val legacySpeedMBps = (totalPayloadBytes / 1_000_000.0) / legacyElapsedSec
                val legacySpeedMiBps = (totalPayloadBytes / (1024.0 * 1024.0)) / legacyElapsedSec

                // =========================================================================
                // 2. AFTER OPTIMIZATION (New High-Speed Streaming Engine):
                //    - HTTP/1.1 Keep-Alive connection reuse + /api/stream continuous streaming
                //    - 256 KB write coalescing buffer
                //    - On-the-fly SHA-256 calculation during network read (zero extra disk read)
                //    - 3-worker bounded concurrency for small/medium files
                // =========================================================================
                val optCompleted = mutableListOf<TransferFileItem>()
                var optItemsState = allItemsForLegacy.toList()
                val optStartNano = System.nanoTime()
                val optAnyFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                    hostIp = "127.0.0.1",
                    hostPort = port,
                    sessionCode = sessionCode,
                    chunkSizeBytes = ChunkSizeOption.AUTO_MAX.bytes,
                    downloadDir = optimizedOutDir,
                    itemsProvider = { optItemsState },
                    isPausedProvider = { false },
                    onFileUpdated = { fileId, _, _, transform ->
                        synchronized(optCompleted) {
                            optItemsState = optItemsState.map { if (it.id == fileId) transform(it) else it }
                        }
                    },
                    onFileCompleted = { item, _ ->
                        synchronized(optCompleted) { optCompleted.add(item) }
                    },
                    onFileFailed = { _, _ -> }
                )
                val optElapsedSec = max(0.001, (System.nanoTime() - optStartNano) / 1_000_000_000.0)
                val optSpeedMBps = (totalPayloadBytes / 1_000_000.0) / optElapsedSec
                val optSpeedMiBps = (totalPayloadBytes / (1024.0 * 1024.0)) / optElapsedSec

                assertFalse(optAnyFailed)
                assertEquals(allItemsForLegacy.size, optCompleted.size)

                println(
                    String.format(
                        Locale.US,
                        "BENCHMARK_RESULT|Payload=%.2f MB|Legacy=%.2f MB/s (%.2f MiB/s) in %.3fs|Optimized=%.2f MB/s (%.2f MiB/s) in %.3fs|Speedup=%.2fx",
                        totalPayloadBytes / 1_000_000.0,
                        legacySpeedMBps,
                        legacySpeedMiBps,
                        legacyElapsedSec,
                        optSpeedMBps,
                        optSpeedMiBps,
                        optElapsedSec,
                        optSpeedMBps / max(0.1, legacySpeedMBps)
                    )
                )

                assertTrue("Optimized transfer should succeed with positive throughput", optSpeedMBps > 0.0)
            } finally {
                server.stopServer()
            }
        } finally {
            serverScope.cancel()
            benchRoot.deleteRecursively()
        }
    }

    @Test
    fun verifyInAppFolderAndFileMultiSelectionAndHierarchyTransfer() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val downloadRoot = android.os.Environment.getExternalStoragePublicDirectory(
            android.os.Environment.DIRECTORY_DOWNLOADS
        ).apply { mkdirs() }

        // Create "Download/ropon" with files, nested subfolders, and an empty subfolder
        val roponDir = File(downloadRoot, "ropon").apply {
            deleteRecursively()
            mkdirs()
        }
        val projectDocsDir = File(downloadRoot, "project_docs").apply {
            deleteRecursively()
            mkdirs()
        }
        val standaloneFile = File(downloadRoot, "standalone_note.txt")
        val receiveBaseDir = File(context.cacheDir, "received_multi_folder_${System.currentTimeMillis()}").apply { mkdirs() }
        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        try {
            val roponMainBytes = "Ropon Main Configuration File\n".repeat(40).toByteArray()
            val roponLevelBytes = Random(777).nextBytes(64 * 1024 + 19)
            val docsSpecBytes = "Project Architecture Specification v2\n".repeat(50).toByteArray()
            val standaloneBytes = "Standalone file selected alongside folders!".toByteArray()

            File(roponDir, "config.json").writeBytes(roponMainBytes)
            val roponLevelsSub = File(roponDir, "levels/world1").apply { mkdirs() }
            File(roponLevelsSub, "map_data.bin").writeBytes(roponLevelBytes)
            File(roponDir, "empty_cache").mkdirs()

            File(projectDocsDir, "architecture.md").writeBytes(docsSpecBytes)
            standaloneFile.writeBytes(standaloneBytes)

            // 1. Load general files and folders via DeviceMediaRepository
            val (loadedFiles, loadedFolders) = DeviceMediaRepository.loadGeneralFilesAndFolders(context)

            val roponFolderItem = loadedFolders.find {
                it.name == "ropon" || it.relativeDisplayPath.equals("Download/ropon", ignoreCase = true)
            }
            val docsFolderItem = loadedFolders.find {
                it.name == "project_docs" || it.relativeDisplayPath.equals("Download/project_docs", ignoreCase = true)
            }
            val standaloneMediaItem = loadedFiles.find { it.name == "standalone_note.txt" }

            assertNotNull("Download/ropon must be discovered as a selectable folder in the list", roponFolderItem)
            assertNotNull("Download/project_docs must be discovered as a selectable folder in the list", docsFolderItem)
            assertNotNull("standalone_note.txt must be discovered in the files list", standaloneMediaItem)

            assertEquals("ropon should report 2 files", 2, roponFolderItem!!.fileCount)
            assertTrue("ropon should report at least 1 empty subfolder", roponFolderItem.emptySubfolderCount >= 1)
            assertEquals(
                "ropon totalBytes should match sum of its files",
                (roponMainBytes.size + roponLevelBytes.size).toLong(),
                roponFolderItem.totalBytes
            )

            // 2. Test ViewModel multi-selection of multiple folders + standalone file together
            val vm = P2PTransferViewModel(context.applicationContext as android.app.Application)
            vm.loadAllDeviceMediaAndFiles()
            // Wait until repository finishes loading into ViewModel state
            val deadline = System.currentTimeMillis() + 5_000L
            while (System.currentTimeMillis() < deadline &&
                vm.uiState.value.storageFolders.none { it.path == roponFolderItem.path }
            ) {
                Thread.sleep(50)
            }

            vm.clearAllManagerSelections()
            // Select folder 1 ("Download/ropon"), folder 2 ("Download/project_docs"), and 1 standalone file
            vm.toggleFolderSelection(roponFolderItem.path)
            vm.toggleFolderSelection(docsFolderItem!!.path)
            vm.toggleMediaSelection(standaloneMediaItem!!.id)

            val stateAfterSelection = vm.uiState.value
            assertEquals("2 folders must be selected", 2, stateAfterSelection.selectedFoldersCount)
            assertEquals("1 standalone file must be selected", 1, stateAfterSelection.selectedFilesAndAppsCount)
            assertEquals("Total selected count in manager must be 3", 3, stateAfterSelection.totalSelectedCountInManager)

            val expectedTotalBytes = roponMainBytes.size.toLong() +
                roponLevelBytes.size.toLong() +
                docsSpecBytes.size.toLong() +
                standaloneBytes.size.toLong()
            assertEquals(
                "Total selected bytes must equal sum of both folders + standalone file",
                expectedTotalBytes,
                stateAfterSelection.totalSelectedBytesInManager
            )

            // 3. Press "إرسال المحدد" -> Add selected folders & files to send queue
            vm.addManagerSelectionsToSendQueueAndGoToSend()
            val sendQueueDeadline = System.currentTimeMillis() + 5_000L
            while (System.currentTimeMillis() < sendQueueDeadline &&
                vm.uiState.value.currentScreen != com.example.model.AppScreen.SEND
            ) {
                Thread.sleep(50)
            }

            val sendState = vm.uiState.value
            assertEquals(com.example.model.AppScreen.SEND, sendState.currentScreen)
            assertEquals("Each selected folder must be added as a unified FolderBatchInfo", 2, sendState.folderBatches.size)
            assertEquals("Standalone file must be in standaloneFilesInQueue", 1, sendState.standaloneFilesInQueue.size)
            assertEquals("Total transfer units in send queue must be 3 (2 folders + 1 file)", 3, sendState.totalSelectedUnitsInSendQueue)

            // 4. Verify end-to-end transfer recreates root folders ("ropon" and "project_docs") first on receiver
            val preparedQueueItems = sendState.files.map { item ->
                val sha = when {
                    item.isDirectory -> Sha256Util.EMPTY_DIR_SHA256
                    item.sizeBytes == 0L -> Sha256Util.EMPTY_BYTES_SHA256
                    item.localFile != null -> Sha256Util.computeFileSha256(item.localFile)
                    else -> ""
                }
                item.copy(sha256Expected = sha)
            }

            val sessionCode = "BRQ-4040"
            val server = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { sessionCode },
                isSenderReadyProvider = { true },
                chunkSizeProvider = { ChunkSizeOption.CHUNK_256KB },
                filesProvider = { preparedQueueItems },
                onChunkServed = { _, _, _ -> }
            )
            val port = server.startServer(0)

            try {
                Thread.sleep(100)
                var receiverItems = preparedQueueItems
                val completedItems = mutableListOf<TransferFileItem>()
                val failedErrors = mutableListOf<String>()

                val anyFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                    hostIp = "127.0.0.1",
                    hostPort = port,
                    sessionCode = sessionCode,
                    chunkSizeBytes = ChunkSizeOption.CHUNK_256KB.bytes,
                    downloadDir = receiveBaseDir,
                    itemsProvider = { receiverItems },
                    isPausedProvider = { false },
                    onFileUpdated = { fileId, _, _, transform ->
                        synchronized(completedItems) {
                            receiverItems = receiverItems.map { if (it.id == fileId) transform(it) else it }
                        }
                    },
                    onFileCompleted = { item, _ ->
                        synchronized(completedItems) { completedItems.add(item) }
                    },
                    onFileFailed = { _, err ->
                        synchronized(failedErrors) { failedErrors.add(err) }
                    }
                )

                assertFalse("Transfer must succeed with zero errors: $failedErrors", anyFailed)
                assertEquals(preparedQueueItems.size, completedItems.size)

                // Verify receiver created "ropon" and "project_docs" root folders and placed contents inside
                val receivedRoponRoot = File(receiveBaseDir, "ropon")
                assertTrue("Receiver must create root folder 'ropon'", receivedRoponRoot.isDirectory)
                assertTrue(
                    "ropon/config.json must match bytes",
                    File(receivedRoponRoot, "config.json").readBytes().contentEquals(roponMainBytes)
                )
                assertTrue(
                    "ropon/levels/world1/map_data.bin must match bytes",
                    File(receivedRoponRoot, "levels/world1/map_data.bin").readBytes().contentEquals(roponLevelBytes)
                )
                assertTrue(
                    "ropon/empty_cache empty subfolder must be created",
                    File(receivedRoponRoot, "empty_cache").isDirectory
                )

                val receivedDocsRoot = File(receiveBaseDir, "project_docs")
                assertTrue("Receiver must create root folder 'project_docs'", receivedDocsRoot.isDirectory)
                assertTrue(
                    "project_docs/architecture.md must match bytes",
                    File(receivedDocsRoot, "architecture.md").readBytes().contentEquals(docsSpecBytes)
                )

                val receivedStandalone = File(receiveBaseDir, "standalone_note.txt")
                assertTrue(
                    "Standalone file must be saved in receiveBaseDir alongside folders",
                    receivedStandalone.exists() && receivedStandalone.readBytes().contentEquals(standaloneBytes)
                )
            } finally {
                server.stopServer()
            }
        } finally {
            serverScope.cancel()
            roponDir.deleteRecursively()
            projectDocsDir.deleteRecursively()
            standaloneFile.delete()
            receiveBaseDir.deleteRecursively()
        }
    }

    @Test
    fun verifyHierarchicalFolderBrowsingAndSessionApprovalHandshake() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        @Suppress("DEPRECATION")
        val extRoot = android.os.Environment.getExternalStorageDirectory().apply { mkdirs() }
        val downloadRoot = android.os.Environment.getExternalStoragePublicDirectory(
            android.os.Environment.DIRECTORY_DOWNLOADS
        ).apply { mkdirs() }

        val customRootFolder = File(extRoot, "BarqCustomWorkspace").apply {
            deleteRecursively()
            mkdirs()
        }
        val rootLevelFile = File(extRoot, "root_readme_barq.txt").apply {
            writeBytes("Root level file in shared storage".toByteArray())
        }
        val androidRootDir = File(extRoot, "Android").apply { mkdirs() }
        File(androidRootDir, "media").mkdirs()

        val gameModFolder = File(downloadRoot, "barq_game_pack").apply {
            deleteRecursively()
            mkdirs()
        }
        val emptyDownloadSubFolder = File(downloadRoot, "empty_user_folder").apply {
            deleteRecursively()
            mkdirs()
        }
        val massiveBatchFiles = mutableListOf<File>()
        val obbSubFolder = File(gameModFolder, "obb_data").apply { mkdirs() }
        val receiveBaseDir = File(context.cacheDir, "handshake_receive_${System.currentTimeMillis()}").apply { mkdirs() }
        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        try {
            val apkBytes = Random(901).nextBytes(72 * 1024 + 11)
            val obbBytes = Random(902).nextBytes(120 * 1024 + 33)
            val apkFile = File(gameModFolder, "barq_arena.apk").apply { writeBytes(apkBytes) }
            val obbFile = File(obbSubFolder, "main.101.com.barq.arena.obb").apply { writeBytes(obbBytes) }

            // Create 450 real files directly inside Download to test large folder opening without ANR
            for (idx in 1..450) {
                val f = File(downloadRoot, "bulk_download_item_$idx.dat")
                f.writeBytes(byteArrayOf(idx.toByte(), 1, 2, 3))
                massiveBatchFiles.add(f)
            }

            val (loadedFiles, loadedFolders) = DeviceMediaRepository.loadGeneralFilesAndFolders(context)

            // 0. Verify Root of Shared Internal Storage ("") dynamically lists real folders (> 6 folders, including Android & customRootFolder) and root-level files
            val (rootFolders, rootFiles) = DeviceMediaRepository.browseLocalDirectoryChildren(
                browsingRelOrAbsPath = "",
                allKnownFolders = loadedFolders,
                allKnownFiles = loadedFiles
            )
            assertTrue(
                "Root of internal storage must dynamically list more than 6 static folders (found ${rootFolders.size})",
                rootFolders.size > 6
            )
            assertTrue(
                "Root of internal storage must include 'Android' folder",
                rootFolders.any { it.name.equals("Android", ignoreCase = true) }
            )
            assertTrue(
                "Root of internal storage must include custom folder 'BarqCustomWorkspace'",
                rootFolders.any { it.name == "BarqCustomWorkspace" }
            )
            assertTrue(
                "Root of internal storage must list root-level file 'root_readme_barq.txt'",
                rootFiles.any { it.name == "root_readme_barq.txt" }
            )

            // 1. Verify hierarchical browsing inside "Download" with 450+ files & empty subfolder completes fast (< 500ms) with progressive batch callback
            var partialBatchFired = false
            val browseStartNano = System.nanoTime()
            val (downloadSubfolders, downloadImmediateFiles) = DeviceMediaRepository.browseLocalDirectoryChildren(
                browsingRelOrAbsPath = "Download",
                allKnownFolders = loadedFolders,
                allKnownFiles = loadedFiles,
                onPartialResult = { _, partialFiles ->
                    if (partialFiles.isNotEmpty()) {
                        partialBatchFired = true
                    }
                }
            )
            val browseElapsedMs = (System.nanoTime() - browseStartNano) / 1_000_000L
            assertTrue(
                "Opening 'Download' with 450+ files must complete in < 500ms without ANR (took ${browseElapsedMs}ms)",
                browseElapsedMs < 500L
            )
            assertTrue("Progressive partial batch must fire for large Download folder", partialBatchFired)
            assertTrue(
                "Browsing 'Download' must list 'barq_game_pack' and 'empty_user_folder' as child folders",
                downloadSubfolders.any { it.name == "barq_game_pack" } &&
                    downloadSubfolders.any { it.name == "empty_user_folder" }
            )
            assertTrue(
                "Browsing 'Download' must list all 450+ immediate files",
                downloadImmediateFiles.size >= 450
            )

            // Verify browsing an empty folder returns empty lists cleanly without error
            val (emptyDirs, emptyFiles) = DeviceMediaRepository.browseLocalDirectoryChildren(
                browsingRelOrAbsPath = "Download/empty_user_folder",
                allKnownFolders = loadedFolders,
                allKnownFiles = loadedFiles
            )
            assertTrue("Empty folder must return 0 subfolders and 0 files", emptyDirs.isEmpty() && emptyFiles.isEmpty())

            val (packSubfolders, packFiles) = DeviceMediaRepository.browseLocalDirectoryChildren(
                browsingRelOrAbsPath = "Download/barq_game_pack",
                allKnownFolders = loadedFolders,
                allKnownFiles = loadedFiles
            )
            assertTrue(
                "Browsing 'Download/barq_game_pack' must list 'obb_data' subfolder",
                packSubfolders.any { it.name == "obb_data" }
            )
            assertTrue(
                "Browsing 'Download/barq_game_pack' must list 'barq_arena.apk' with APK extension badge",
                packFiles.any { it.name == "barq_arena.apk" && it.fileExtensionBadge == "APK" }
            )

            // 2. Verify ViewModel parent directory navigation (navigateUpDirectory) & async cache restoration
            val vm = P2PTransferViewModel(context.applicationContext as android.app.Application)
            vm.setBrowsingFolderFilter("Download")
            val dlWaitDeadline = System.currentTimeMillis() + 3_000L
            while (System.currentTimeMillis() < dlWaitDeadline &&
                (vm.uiState.value.isBrowsingDirectoryLoading || vm.uiState.value.currentBrowsingFiles.size < 450)
            ) {
                Thread.sleep(20)
            }
            assertTrue(
                "ViewModel async browse for Download must populate currentBrowsingFiles",
                vm.uiState.value.currentBrowsingFiles.size >= 450
            )
            vm.setBrowsingFolderFilter("Download/barq_game_pack/obb_data")
            assertEquals("Download/barq_game_pack/obb_data", vm.uiState.value.browsingFolderFilter)
            vm.navigateUpDirectory()
            assertEquals("Download/barq_game_pack", vm.uiState.value.browsingFolderFilter)
            vm.navigateUpDirectory()
            assertEquals("Download", vm.uiState.value.browsingFolderFilter)
            assertTrue(
                "Navigating back to 'Download' must immediately restore cached files without reloading from zero",
                vm.uiState.value.currentBrowsingFiles.size >= 450
            )
            vm.navigateUpDirectory()
            assertEquals(null, vm.uiState.value.browsingFolderFilter)

            // 3. Verify Two-Device Session Handshake & Explicit Sender Approval Security
            val scanResult = DeviceMediaRepository.scanLocalFolderForTransfer(
                rootDir = gameModFolder,
                chunkSizeBytes = ChunkSizeOption.CHUNK_256KB.bytes
            )
            val preparedItems = scanResult.transferItems.map { item ->
                val sha = when {
                    item.isDirectory -> Sha256Util.EMPTY_DIR_SHA256
                    item.sizeBytes == 0L -> Sha256Util.EMPTY_BYTES_SHA256
                    item.localFile != null -> Sha256Util.computeFileSha256(item.localFile)
                    else -> ""
                }
                item.copy(sha256Expected = sha)
            }

            val sessionCode = "BRQ-8899"
            val sessionId = "SES-A1B2C3"
            val expiresAt = System.currentTimeMillis() + 600_000L
            var observedIncomingReq: com.example.model.IncomingConnectionRequest? = null

            val server = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { sessionCode },
                sessionIdProvider = { sessionId },
                sessionExpiresAtProvider = { expiresAt },
                isSenderReadyProvider = { true },
                requireReceiverApprovalProvider = { true },
                chunkSizeProvider = { ChunkSizeOption.CHUNK_256KB },
                filesProvider = { preparedItems },
                onIncomingConnectionRequest = { req -> observedIncomingReq = req },
                onChunkServed = { _, _, _ -> }
            )
            val port = server.startServer(0)

            try {
                Thread.sleep(100)

                // Step A: Receiver fetches manifest -> succeeds (200) and reports requiresApproval = true
                val manifestConn = (URL("http://127.0.0.1:$port/api/manifest?code=$sessionCode").openConnection() as HttpURLConnection)
                assertEquals(200, manifestConn.responseCode)
                val manifestJson = JSONObject(manifestConn.inputStream.bufferedReader().use { it.readText() })
                manifestConn.disconnect()
                assertEquals(sessionId, manifestJson.getString("sessionId"))
                assertTrue(manifestJson.getBoolean("requiresApproval"))

                // Step B: Unauthorized Receiver tries to download /api/stream BEFORE Sender approval -> MUST BE REJECTED (HTTP 403)
                val firstFileId = preparedItems.first { !it.isDirectory }.id
                val unauthStreamConn = (URL("http://127.0.0.1:$port/api/stream?code=$sessionCode&fileId=$firstFileId&offset=0").openConnection() as HttpURLConnection)
                assertEquals(
                    "Stream download MUST be blocked with HTTP 403 before Sender approves connection",
                    403,
                    unauthStreamConn.responseCode
                )
                unauthStreamConn.disconnect()

                // Step C: Receiver sends /api/request-connect
                val reqConn = (URL("http://127.0.0.1:$port/api/request-connect?code=$sessionCode&deviceName=Pixel_Receiver&clientId=RCV-101").openConnection() as HttpURLConnection)
                assertEquals(200, reqConn.responseCode)
                val reqJson = JSONObject(reqConn.inputStream.bufferedReader().use { it.readText() })
                reqConn.disconnect()
                assertEquals("PENDING", reqJson.getString("status"))
                assertNotNull("Sender must receive IncomingConnectionRequest callback", observedIncomingReq)
                assertEquals("Pixel_Receiver", observedIncomingReq?.clientDeviceName)

                // Step D: Receiver polls /api/connect-status while still pending -> PENDING
                val pollPendingConn = (URL("http://127.0.0.1:$port/api/connect-status?code=$sessionCode&requestId=${observedIncomingReq!!.requestId}").openConnection() as HttpURLConnection)
                val pollPendingJson = JSONObject(pollPendingConn.inputStream.bufferedReader().use { it.readText() })
                pollPendingConn.disconnect()
                assertEquals("PENDING", pollPendingJson.getString("status"))

                // Step E: Sender approves the incoming connection request -> issues cryptographic authToken
                val issuedToken = server.approvePendingConnectionRequest()
                assertTrue("Issued auth token must not be blank", issuedToken.isNotBlank())

                // Step F: Receiver polls /api/connect-status -> APPROVED + authToken
                val pollApprovedConn = (URL("http://127.0.0.1:$port/api/connect-status?code=$sessionCode&requestId=${observedIncomingReq!!.requestId}").openConnection() as HttpURLConnection)
                val pollApprovedJson = JSONObject(pollApprovedConn.inputStream.bufferedReader().use { it.readText() })
                pollApprovedConn.disconnect()
                assertEquals("APPROVED", pollApprovedJson.getString("status"))
                assertEquals(issuedToken, pollApprovedJson.getString("authToken"))

                // Step G: Receiver executes high-speed transfer using the approved authToken and verifies SHA-256
                var receiverItems = preparedItems
                val completed = mutableListOf<TransferFileItem>()
                val anyFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                    hostIp = "127.0.0.1",
                    hostPort = port,
                    sessionCode = sessionCode,
                    authToken = issuedToken,
                    chunkSizeBytes = ChunkSizeOption.CHUNK_256KB.bytes,
                    downloadDir = receiveBaseDir,
                    itemsProvider = { receiverItems },
                    isPausedProvider = { false },
                    onFileUpdated = { fileId, _, _, transform ->
                        synchronized(completed) {
                            receiverItems = receiverItems.map { if (it.id == fileId) transform(it) else it }
                        }
                    },
                    onFileCompleted = { item, _ ->
                        synchronized(completed) { completed.add(item) }
                    },
                    onFileFailed = { _, _ -> }
                )
                assertFalse("Approved transfer must complete without errors", anyFailed)
                assertEquals(preparedItems.size, completed.size)
                assertTrue(File(receiveBaseDir, "barq_game_pack/barq_arena.apk").readBytes().contentEquals(apkBytes))
                assertTrue(File(receiveBaseDir, "barq_game_pack/obb_data/main.101.com.barq.arena.obb").readBytes().contentEquals(obbBytes))
            } finally {
                server.stopServer()
            }
        } finally {
            serverScope.cancel()
            customRootFolder.deleteRecursively()
            rootLevelFile.delete()
            emptyDownloadSubFolder.deleteRecursively()
            massiveBatchFiles.forEach { it.delete() }
            gameModFolder.deleteRecursively()
            receiveBaseDir.deleteRecursively()
        }
    }

    @Test
    fun verifyCrashFreeMediaAndUriTransferAndCompactFilesViewport() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempRoot = File(context.cacheDir, "crash_guard_test_${System.currentTimeMillis()}").apply { mkdirs() }
        val receiveDir = File(tempRoot, "received_out").apply { mkdirs() }
        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        try {
            // 1. Test transferring a multi-megabyte video via Uri (content/file URI fallback),
            //    an image with special '%' and Arabic characters in its filename, and a broken URI.
            val videoBytes = Random(2025).nextBytes(4 * 1024 * 1024 + 517) // ~4 MB video
            val videoFile = File(tempRoot, "4K_Capture_100%_سباق.mp4").apply { writeBytes(videoBytes) }
            val videoSha = Sha256Util.computeFileSha256(videoFile)

            val imageBytes = Random(2026).nextBytes(320 * 1024 + 19)
            val imageFile = File(tempRoot, "صورة_خاصة_50%+1.jpg").apply { writeBytes(imageBytes) }
            val imageSha = Sha256Util.computeFileSha256(imageFile)

            // Pass video Item with ONLY uri (localFile = null) so P2PChunkServer exercises its URI streaming path
            val videoUri = android.net.Uri.fromFile(videoFile)
            val validItems = listOf(
                TransferFileItem(
                    id = "uri_video_100%A",
                    name = videoFile.name,
                    sizeBytes = videoFile.length(),
                    category = FileCategory.VIDEO,
                    uri = videoUri,
                    localFile = null,
                    totalChunks = 8,
                    completedChunks = 0,
                    sha256Expected = videoSha
                ),
                TransferFileItem(
                    id = "special_img_50%",
                    name = imageFile.name,
                    sizeBytes = imageFile.length(),
                    category = FileCategory.IMAGE,
                    localFile = imageFile,
                    totalChunks = 2,
                    completedChunks = 0,
                    sha256Expected = imageSha
                )
            )

            val sessionCode = "BRQ-9911"
            val server = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { sessionCode },
                isSenderReadyProvider = { true },
                chunkSizeProvider = { ChunkSizeOption.CHUNK_512KB },
                filesProvider = { validItems },
                onChunkServed = { _, _, _ -> }
            )
            val port = server.startServer(0)

            try {
                Thread.sleep(100)
                var receiverItems = validItems
                val completed = mutableListOf<TransferFileItem>()
                val errors = mutableListOf<String>()

                val anyFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                    hostIp = "127.0.0.1",
                    hostPort = port,
                    sessionCode = sessionCode,
                    chunkSizeBytes = ChunkSizeOption.CHUNK_512KB.bytes,
                    downloadDir = receiveDir,
                    itemsProvider = { receiverItems },
                    isPausedProvider = { false },
                    onFileUpdated = { fileId, _, _, transform ->
                        synchronized(completed) {
                            receiverItems = receiverItems.map { if (it.id == fileId) transform(it) else it }
                        }
                    },
                    onFileCompleted = { item, _ ->
                        synchronized(completed) { completed.add(item) }
                    },
                    onFileFailed = { _, err ->
                        synchronized(errors) { errors.add(err) }
                    }
                )

                assertFalse("URI video and special-char image transfer must succeed without crashes: $errors", anyFailed)
                assertEquals(2, completed.size)
                assertTrue(File(receiveDir, videoFile.name).readBytes().contentEquals(videoBytes))
                assertTrue(File(receiveDir, imageFile.name).readBytes().contentEquals(imageBytes))

                // 2. Verify that a revoked/missing content:// URI does NOT crash the server or receiver,
                //    and instead reports a graceful Arabic error via onFileFailed
                val brokenItem = TransferFileItem(
                    id = "revoked_uri_item",
                    name = "revoked_video.mp4",
                    sizeBytes = 1024 * 1024L,
                    category = FileCategory.VIDEO,
                    uri = android.net.Uri.parse("content://com.nonexistent.provider.barq/video/999999"),
                    localFile = null,
                    totalChunks = 2,
                    completedChunks = 0,
                    sha256Expected = ""
                )
                val brokenServer = P2PChunkServer(
                    context = context,
                    scope = serverScope,
                    sessionCodeProvider = { sessionCode },
                    isSenderReadyProvider = { true },
                    chunkSizeProvider = { ChunkSizeOption.CHUNK_512KB },
                    filesProvider = { listOf(brokenItem) },
                    onChunkServed = { _, _, _ -> }
                )
                val brokenPort = brokenServer.startServer(0)
                try {
                    Thread.sleep(80)
                    var brokenState = listOf(brokenItem)
                    val brokenErrors = mutableListOf<String>()
                    val brokenFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                        hostIp = "127.0.0.1",
                        hostPort = brokenPort,
                        sessionCode = sessionCode,
                        chunkSizeBytes = ChunkSizeOption.CHUNK_512KB.bytes,
                        downloadDir = receiveDir,
                        itemsProvider = { brokenState },
                        isPausedProvider = { false },
                        onFileUpdated = { fileId, _, _, transform ->
                            brokenState = brokenState.map { if (it.id == fileId) transform(it) else it }
                        },
                        onFileCompleted = { _, _ -> },
                        onFileFailed = { _, err -> brokenErrors.add(err) }
                    )
                    assertTrue("Revoked URI must fail gracefully instead of crashing", brokenFailed)
                    assertTrue("Graceful failure message must be recorded", brokenErrors.isNotEmpty())
                } finally {
                    brokenServer.stopServer()
                }
            } finally {
                server.stopServer()
            }

            // 3. Verify Real Android File Manager layout, default root folders, breadcrumb bar, and direct folder opening
            composeTestRule.onNodeWithTag("main_bottom_tabs_row")
                .performScrollToNode(hasTestTag("bottom_nav_FILES"))
            composeTestRule.onNodeWithTag("bottom_nav_FILES").performClick()
            composeTestRule.waitForIdle()

            composeTestRule.onNodeWithTag("files_and_folders_search_input").assertIsDisplayed()
            composeTestRule.onNodeWithTag("file_manager_breadcrumb_bar").assertIsDisplayed()
            composeTestRule.onNodeWithTag("sort_dropdown_button").assertExists()
            composeTestRule.onNodeWithTag("pick_saf_folder_in_manager_button").assertExists()
            composeTestRule.onNodeWithTag("files_manager_lazy_column").assertIsDisplayed()

            // Verify internal storage root folders (Download, DCIM) are automatically displayed without "0 مجلد"
            composeTestRule.onNodeWithTag("files_manager_lazy_column")
                .performScrollToNode(hasTestTag("folder_item_card_Download"))
            composeTestRule.onNodeWithTag("folder_item_card_Download").assertExists()
            composeTestRule.onNodeWithTag("files_manager_lazy_column")
                .performScrollToNode(hasTestTag("folder_item_card_DCIM"))
            composeTestRule.onNodeWithTag("folder_item_card_DCIM").assertExists()

            // Click directly on Download folder to open it, then verify "المجلد السابق ↑" button appears and navigates back
            composeTestRule.onNodeWithTag("files_manager_lazy_column")
                .performScrollToNode(hasTestTag("folder_item_card_Download"))
            composeTestRule.onNodeWithTag("folder_item_card_Download").performClick()
            composeTestRule.waitForIdle()
            composeTestRule.onNodeWithTag("navigate_up_folder_button").assertIsDisplayed()
            composeTestRule.onNodeWithTag("navigate_up_folder_button").performClick()
            composeTestRule.waitForIdle()

            // Toggle manual folder path bar and verify it opens and closes cleanly
            composeTestRule.onNodeWithTag("toggle_custom_folder_bar_button").performClick()
            composeTestRule.waitForIdle()
            composeTestRule.onNodeWithTag("custom_folder_path_input").assertIsDisplayed()
            composeTestRule.onNodeWithTag("toggle_custom_folder_bar_button").performClick()
            composeTestRule.waitForIdle()
        } finally {
            serverScope.cancel()
            tempRoot.deleteRecursively()
        }
    }

    @Test
    fun verifyAutoMaxDefaultQrRoundTripAndReceivedApksManager(): Unit = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val vm = P2PTransferViewModel(context.applicationContext as android.app.Application)

        // 1. Verify "أقصى سرعة تلقائية (Auto Max)" is the default chunk mode in every session without manual intervention
        assertEquals(
            "Default chunk size must be AUTO_MAX without manual user selection",
            ChunkSizeOption.AUTO_MAX,
            vm.uiState.value.selectedChunkSize
        )
        assertEquals(
            "Default remote chunk size must match AUTO_MAX bytes (8 MB)",
            ChunkSizeOption.AUTO_MAX.bytes,
            vm.uiState.value.remoteChunkSizeBytes
        )

        // 2. Verify SortOption.TYPE_ASC exists and works in ViewModel
        vm.setSortOption(com.example.model.SortOption.TYPE_ASC)
        assertEquals(com.example.model.SortOption.TYPE_ASC, vm.uiState.value.sortOption)

        // 3. Verify real QR Code encoding + matrix decoding + luminance camera frame decoding round-trip
        val qrPayload = "BARQP2P|192.168.43.1|8989|BRQ-7744|SES-998877"
        val matrix = com.example.util.QrCodeGenerator.encodeToMatrix(qrPayload)
        val decodedDirect = com.example.util.QrCodeGenerator.decodeMatrix(matrix)
        assertEquals("Direct QR matrix decoder must recover exact session payload", qrPayload, decodedDirect)

        // Synthesize a camera Y-plane (luminance frame) with quiet zone around the QR matrix and decode it
        val n = matrix.size
        val scale = 6
        val quiet = 4
        val frameSize = (n + quiet * 2) * scale
        val yPlane = ByteArray(frameSize * frameSize) { 240.toByte() } // White background
        for (r in 0 until n) {
            for (c in 0 until n) {
                val lum = if (matrix[r][c]) 16.toByte() else 240.toByte()
                val startY = (r + quiet) * scale
                val startX = (c + quiet) * scale
                for (dy in 0 until scale) {
                    for (dx in 0 until scale) {
                        yPlane[(startY + dy) * frameSize + (startX + dx)] = lum
                    }
                }
            }
        }
        val decodedFromCameraFrame = com.example.util.QrCodeGenerator.tryDecodeLumaFrame(
            yPlane = yPlane,
            width = frameSize,
            height = frameSize,
            rowStride = frameSize
        )
        assertEquals(
            "Camera luminance frame decoder must recover exact session payload",
            qrPayload,
            decodedFromCameraFrame
        )

        // 4. Verify Received APKs inspection (corrupted vs valid ZIP header handling) and UI screen navigation
        val downloadRoot = android.os.Environment.getExternalStoragePublicDirectory(
            android.os.Environment.DIRECTORY_DOWNLOADS
        )
        val barqReceiveDir = File(downloadRoot, "Barq_P2P").apply { mkdirs() }
        val corruptApk = File(barqReceiveDir, "incomplete_corrupt_test.apk")
        val emptyApk = File(barqReceiveDir, "empty_zero_test.apk")
        try {
            corruptApk.writeBytes("NOT_A_VALID_ZIP_OR_APK_HEADER".toByteArray())
            emptyApk.writeBytes(ByteArray(0))

            val corruptInspect = DeviceMediaRepository.inspectApkFile(context, corruptApk)
            assertFalse("Corrupted non-ZIP file must be marked isValidApk = false", corruptInspect.isValidApk)
            assertTrue("Corrupted APK status message must explain reason", corruptInspect.statusMessage.isNotBlank())

            val emptyInspect = DeviceMediaRepository.inspectApkFile(context, emptyApk)
            assertFalse("0-byte APK must be marked isValidApk = false", emptyInspect.isValidApk)

            val loadedApks = DeviceMediaRepository.loadReceivedApkFiles(context)
            assertTrue(
                "loadReceivedApkFiles must discover APK files inside Download/Barq_P2P",
                loadedApks.any { it.fileName == "incomplete_corrupt_test.apk" }
            )

            // Navigate to RECEIVED_APKS tab in MainActivity and verify UI renders
            composeTestRule.onNodeWithTag("main_bottom_tabs_row")
                .performScrollToNode(hasTestTag("bottom_nav_RECEIVED_APKS"))
            composeTestRule.onNodeWithTag("bottom_nav_RECEIVED_APKS").performClick()
            composeTestRule.waitForIdle()
            composeTestRule.onNodeWithTag("refresh_received_apks_button").assertIsDisplayed()
        } finally {
            corruptApk.delete()
            emptyApk.delete()
        }
    }

    @Test
    fun verifyMassiveMediaLibrary40GbVideosAndBluetoothProtocolAndUi(): Unit = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempDir = File(context.cacheDir, "bt_and_40gb_test_${System.currentTimeMillis()}").apply { mkdirs() }

        try {
            // 1. Verify bounded LruCache thumbnail behavior and fast handling of 3,200+ items & 40 GB videos
            DeviceMediaRepository.clearThumbnailCache()
            val sampleImgFile = File(tempDir, "thumb_sample.jpg")
            val bmp = android.graphics.Bitmap.createBitmap(160, 160, android.graphics.Bitmap.Config.RGB_565)
            java.io.FileOutputStream(sampleImgFile).use { out ->
                bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, out)
            }
            val mediaItem = com.example.model.DeviceMediaItem(
                id = "img_test_lru_1",
                name = "thumb_sample.jpg",
                sizeBytes = sampleImgFile.length(),
                category = FileCategory.IMAGE,
                dateModifiedMillis = 1_700_000_000_000L,
                localFile = sampleImgFile
            )
            val loadedThumb = DeviceMediaRepository.getOrLoadThumbnailAsync(context, mediaItem)
            assertNotNull("On-demand async thumbnail loader must decode and cache visible image thumbnail", loadedThumb)
            assertNotNull("Thumbnail must be retrievable synchronously from bounded LruCache", DeviceMediaRepository.getCachedThumbnail("img_test_lru_1"))

            // Simulate 3,200 media items including 40 GB (42,949,672,960 bytes) videos
            val fortyGbBytes = 40L * 1024L * 1024L * 1024L
            val massiveListStart = System.nanoTime()
            val massiveItems = (1..3200).map { idx ->
                com.example.model.DeviceMediaItem(
                    id = "mass_$idx",
                    name = if (idx % 50 == 0) "UltraHD_Movie_$idx.mp4" else "IMG_${10000 + idx}.jpg",
                    sizeBytes = if (idx % 50 == 0) fortyGbBytes else 4_500_000L,
                    category = if (idx % 50 == 0) FileCategory.VIDEO else FileCategory.IMAGE,
                    dateModifiedMillis = 1_700_000_000_000L + idx * 1000L,
                    durationMillis = if (idx % 50 == 0) 7_200_000L else 0L,
                    bucketOrFolderName = if (idx % 2 == 0) "Camera" else "DCIM"
                )
            }
            val searchMatched = massiveItems.filter { it.name.contains("UltraHD_Movie_1500", ignoreCase = true) }
            val elapsedMs = (System.nanoTime() - massiveListStart) / 1_000_000L
            assertEquals(1, searchMatched.size)
            assertEquals(fortyGbBytes, searchMatched.first().sizeBytes)
            assertTrue("Filtering 3,200 metadata items with 40 GB videos must complete in < 250ms (took ${elapsedMs}ms)", elapsedMs < 250L)

            // 2. Verify Bluetooth Classic RFCOMM Stream Handshake + Direct File Transfer over socket streams
            val btPayloadBytes = Random(777).nextBytes(256 * 1024 + 333) // ~256 KB file for Bluetooth stream test
            val btSourceFile = File(tempDir, "bluetooth_test_doc.pdf").apply { writeBytes(btPayloadBytes) }
            val btExpectedSha = Sha256Util.computeFileSha256(btSourceFile)
            val btTransferItem = TransferFileItem(
                id = "bt_file_1",
                name = btSourceFile.name,
                sizeBytes = btSourceFile.length(),
                category = FileCategory.DOCUMENT,
                localFile = btSourceFile,
                totalChunks = 1,
                sha256Expected = btExpectedSha
            )

            java.net.ServerSocket(0).use { loopServer ->
                val loopPort = loopServer.localPort
                val serverThread = Thread {
                    repeat(2) {
                        val accepted = loopServer.accept()
                        accepted.use { s ->
                            com.example.network.BluetoothP2PManager.handleServerConnectionStreams(
                                context = context,
                                input = s.getInputStream(),
                                output = s.getOutputStream(),
                                localIp = "192.168.43.1",
                                localPort = 8989,
                                sessionCode = "BRQ-4040",
                                sessionId = "SES-BT40",
                                senderDeviceName = "Galaxy_S24_Sender",
                                filesProvider = { listOf(btTransferItem) },
                                onBytesServed = { _: String, _: Long -> }
                            )
                        }
                    }
                }.apply { isDaemon = true; start() }

                // Connection 1: Client Handshake over Bluetooth stream
                java.net.Socket("127.0.0.1", loopPort).use { clientSock1 ->
                    val handshakeJson = com.example.network.BluetoothP2PManager.performClientHandshakeOverStreams(
                        input = clientSock1.getInputStream(),
                        output = clientSock1.getOutputStream(),
                        clientDeviceName = "Pixel_9_Receiver"
                    )
                    assertEquals("BRQ-4040", handshakeJson.getString("sessionCode"))
                    assertEquals("SES-BT40", handshakeJson.getString("sessionId"))
                    assertEquals("192.168.43.1", handshakeJson.getString("hostIp"))
                    assertEquals(1, handshakeJson.getJSONArray("files").length())
                }

                // Connection 2: Direct Bluetooth File Stream & SHA-256 verification
                val btDestFile = File(tempDir, "received_via_bt.pdf")
                java.net.Socket("127.0.0.1", loopPort).use { clientSock2 ->
                    val (btOk, btShaOrErr) = com.example.network.BluetoothP2PManager.downloadSingleFileOverBluetoothStreams(
                        item = btTransferItem,
                        input = clientSock2.getInputStream(),
                        output = clientSock2.getOutputStream(),
                        destFile = btDestFile,
                        onProgress = { _: Long, _: Double -> }
                    )
                    assertTrue("Direct Bluetooth stream transfer must succeed: $btShaOrErr", btOk)
                    assertEquals(btExpectedSha, btShaOrErr)
                    assertTrue("Received Bluetooth file bytes must match original", btDestFile.readBytes().contentEquals(btPayloadBytes))
                }
                serverThread.join(2000)
            }

            // 3. Verify Transport Mode & Bluetooth UI card on SEND screen
            composeTestRule.onNodeWithTag("main_bottom_tabs_row")
                .performScrollToNode(hasTestTag("bottom_nav_SEND"))
            composeTestRule.onNodeWithTag("bottom_nav_SEND").performClick()
            composeTestRule.waitForIdle()

            composeTestRule.onNodeWithTag("bluetooth_and_transport_mode_card").assertExists()
            composeTestRule.onNodeWithTag("transport_mode_chip_AUTO_SMART").assertExists()
            composeTestRule.onNodeWithTag("transport_mode_chip_BLUETOOTH_DIRECT").performClick()
            composeTestRule.waitForIdle()
            composeTestRule.onNodeWithTag("transport_mode_chip_AUTO_SMART").performClick()
            composeTestRule.waitForIdle()
        } finally {
            tempDir.deleteRecursively()
        }
    }

    @Test
    fun verifyLarge3GbMathMultiVideoQueuePartResumeForegroundServiceAndHistoryMediaPlayback(): Unit = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempRoot = File(context.cacheDir, "barq_3gb_resume_history_${System.currentTimeMillis()}").apply { mkdirs() }
        val receiveDir = File(tempRoot, "received_videos").apply { mkdirs() }
        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        try {
            P2PTransferViewModel.resetRetainedEngineForTests()

            // 1. Verify 2.9 GB - 3 GB (3,150,000,000 bytes > Int.MAX_VALUE) Long math & progress precision
            val threeGbBytes = 3_150_000_000L
            val halfThreeGbBytes = 1_575_000_000L
            val chunkBytesLong = ChunkSizeOption.AUTO_MAX.bytes.toLong()
            val expected3GbChunks = ((threeGbBytes + chunkBytesLong - 1L) / chunkBytesLong).toInt()
            assertTrue("3 GB totalChunks must be positive and never overflow Int", expected3GbChunks > 350)
            val chunk4MbLong = ChunkSizeOption.CHUNK_4MB.bytes.toLong()
            val expected3Gb4MbChunks = ((threeGbBytes + chunk4MbLong - 1L) / chunk4MbLong).toInt()
            assertTrue("3 GB 4MB totalChunks must be > 700 and never overflow Int", expected3Gb4MbChunks > 700)

            val large3GbItem = TransferFileItem(
                id = "movie_3gb",
                name = "Cinema_4K_Master_2_9GB.mp4",
                sizeBytes = threeGbBytes,
                transferredBytes = halfThreeGbBytes,
                category = FileCategory.VIDEO,
                totalChunks = expected3GbChunks,
                completedChunks = expected3GbChunks / 2,
                status = FileTransferStatus.TRANSFERRING
            )
            assertEquals("3 GB 50% progressPercent must be 50%", 50, large3GbItem.progressPercent)
            assertEquals(0.5f, large3GbItem.progressFraction, 0.001f)

            val uiState3Gb = com.example.viewmodel.P2PUiState(
                files = listOf(large3GbItem),
                isTransferRunning = true,
                liveOverallSpeedBytesPerSec = 52_500_000.0
            )
            assertEquals(threeGbBytes, uiState3Gb.totalBytes)
            assertEquals(halfThreeGbBytes, uiState3Gb.transferredBytes)
            assertEquals(0.5f, uiState3Gb.overallProgressFraction, 0.001f)
            assertEquals(0, uiState3Gb.completedFilesOnlyCount)
            assertEquals(1, uiState3Gb.remainingFilesOnlyCount)
            assertEquals("Cinema_4K_Master_2_9GB.mp4", uiState3Gb.activeTransferringFile?.name)

            // 2. Verify Sequential Multi-Video Transfer + Mid-Transfer Disconnect (.part) & Exact Byte-Offset Resume
            val video1Bytes = Random(301).nextBytes(4 * 1024 * 1024 + 50_123) // > 4 MB -> enters largeFiles sequential queue
            val video2Bytes = Random(302).nextBytes(4 * 1024 * 1024 + 120_456)
            val video3Bytes = Random(303).nextBytes(4 * 1024 * 1024 + 210_789)

            val video1File = File(tempRoot, "video_250mb_clip.mp4").apply { writeBytes(video1Bytes) }
            val video2File = File(tempRoot, "video_300mb_clip.mp4").apply { writeBytes(video2Bytes) }
            val video3File = File(tempRoot, "video_400mb_clip.mp4").apply { writeBytes(video3Bytes) }

            val videoItems = listOf(video1File, video2File, video3File).mapIndexed { idx, f ->
                val cSize = ChunkSizeOption.CHUNK_256KB.bytes.toLong()
                TransferFileItem(
                    id = "seq_vid_$idx",
                    name = f.name,
                    sizeBytes = f.length(),
                    category = FileCategory.VIDEO,
                    localFile = f,
                    totalChunks = ((f.length() + cSize - 1L) / cSize).toInt(),
                    sha256Expected = Sha256Util.computeFileSha256(f)
                )
            }

            // Simulate a previous interrupted transfer where 1.5 MB of video_250mb_clip.mp4 was written to .part
            val partialPrefixLen = 1_500_000
            val partFile1 = File(receiveDir, "${video1File.name}.part").apply {
                writeBytes(video1Bytes.copyOfRange(0, partialPrefixLen))
            }
            assertTrue("Partial .part file must exist before resume", partFile1.exists() && partFile1.length() == partialPrefixLen.toLong())

            val requestedOffsetsForVid0 = mutableListOf<Long>()
            val sessionCode = "BRQ-3000"
            val server = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { sessionCode },
                isSenderReadyProvider = { true },
                chunkSizeProvider = { ChunkSizeOption.CHUNK_256KB },
                filesProvider = { videoItems },
                onChunkServed = { _, _, _ -> }
            )
            val port = server.startServer(0)

            try {
                Thread.sleep(100)
                var currentVideoState = videoItems.mapIndexed { idx, item ->
                    if (idx == 0) item.copy(transferredBytes = partialPrefixLen.toLong(), completedChunks = 6) else item
                }
                val completedOrder = mutableListOf<String>()

                val anyFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                    hostIp = "127.0.0.1",
                    hostPort = port,
                    sessionCode = sessionCode,
                    chunkSizeBytes = ChunkSizeOption.CHUNK_256KB.bytes,
                    downloadDir = receiveDir,
                    itemsProvider = { currentVideoState },
                    isPausedProvider = { false },
                    onFileUpdated = { fileId, _, _, transform ->
                        synchronized(completedOrder) {
                            currentVideoState = currentVideoState.map {
                                if (it.id == fileId) {
                                    val updated = transform(it)
                                    if (fileId == "seq_vid_0" && updated.transferredBytes >= partialPrefixLen.toLong()) {
                                        requestedOffsetsForVid0.add(updated.transferredBytes)
                                    }
                                    updated
                                } else it
                            }
                        }
                    },
                    onFileCompleted = { doneItem, _ ->
                        synchronized(completedOrder) {
                            completedOrder.add(doneItem.name)
                        }
                    },
                    onFileFailed = { _, err ->
                        throw AssertionError("Multi-video sequential transfer should not fail: $err")
                    }
                )

                assertFalse("Sequential multi-video transfer with .part resume must succeed", anyFailed)
                assertEquals(
                    "Videos > 4 MB must complete in strict sequential order",
                    listOf("video_250mb_clip.mp4", "video_300mb_clip.mp4", "video_400mb_clip.mp4"),
                    completedOrder
                )
                assertTrue(
                    "Resumed video must start at or above the 1.5 MB .part offset without resetting to 0",
                    requestedOffsetsForVid0.isNotEmpty() && requestedOffsetsForVid0.first() >= partialPrefixLen.toLong()
                )
                assertFalse(".part temporary file must be renamed after completion", partFile1.exists())

                for ((idx, srcFile) in listOf(video1File, video2File, video3File).withIndex()) {
                    val savedVideo = File(receiveDir, srcFile.name)
                    assertTrue("Saved video $idx must exist", savedVideo.exists())
                    assertEquals("Saved video $idx length must match", srcFile.length(), savedVideo.length())
                    assertEquals(
                        "Saved video $idx SHA-256 must match 100%",
                        videoItems[idx].sha256Expected,
                        Sha256Util.computeFileSha256(savedVideo)
                    )
                }
            } finally {
                server.stopServer()
            }

            // 3. Verify BarqTransferForegroundService Notification + WakeLock/WifiLock lifecycle
            com.example.service.BarqTransferForegroundService.startOrUpdateTransfer(
                context = context,
                direction = com.example.model.TransferDirection.RECEIVING,
                currentFileName = "Cinema_4K_Master_2_9GB.mp4",
                completedFiles = 1,
                totalFiles = 3,
                transferredBytes = halfThreeGbBytes,
                totalBytes = threeGbBytes,
                speedBytesPerSec = 48L * 1024L * 1024L,
                forceUpdate = true
            )
            assertTrue(
                "Foreground transfer service must be marked active during transfer",
                com.example.service.BarqTransferForegroundService.isServiceActive
            )
            assertEquals(500, com.example.service.BarqTransferForegroundService.lastProgressPermille)
            assertTrue(
                "Notification body must display current file name",
                com.example.service.BarqTransferForegroundService.lastNotificationBody.contains("Cinema_4K_Master_2_9GB.mp4")
            )

            com.example.service.BarqTransferForegroundService.stopTransferService(context)
            assertFalse(
                "Foreground transfer service must stop immediately when transfer finishes",
                com.example.service.BarqTransferForegroundService.isServiceActive
            )
            assertFalse(
                "WakeLock must be released when transfer service stops",
                com.example.service.BarqTransferForegroundService.isWakeLockHeld
            )
            assertFalse(
                "WifiLock must be released when transfer service stops",
                com.example.service.BarqTransferForegroundService.isWifiLockHeld
            )

            // 4. Verify Downloads History persistence & direct Video Playback (▶ تشغيل الفيديو) + Image Viewing (عرض الصورة)
            val savedImgFile = File(receiveDir, "downloaded_poster.jpg")
            val bmp = android.graphics.Bitmap.createBitmap(240, 180, android.graphics.Bitmap.Config.ARGB_8888)
            bmp.eraseColor(android.graphics.Color.CYAN)
            java.io.FileOutputStream(savedImgFile).use { out ->
                bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, out)
            }
            val savedVidFile = File(receiveDir, "video_250mb_clip.mp4")
            val incompletePartPath = File(receiveDir, "unfinished_movie.mp4.part").apply {
                writeBytes(ByteArray(1024))
            }

            val completedVideoRecord = com.example.model.TransferHistoryRecord(
                id = "hist_vid_1",
                fileName = savedVidFile.name,
                sizeBytes = savedVidFile.length(),
                category = FileCategory.VIDEO,
                direction = com.example.model.TransferDirection.RECEIVING,
                status = FileTransferStatus.COMPLETED,
                timestampMillis = System.currentTimeMillis(),
                savedPath = savedVidFile.absolutePath,
                uriString = android.net.Uri.fromFile(savedVidFile).toString(),
                mimeType = "video/mp4",
                sha256Hash = Sha256Util.computeFileSha256(savedVidFile),
                sha256Verified = true,
                averageSpeedBytesPerSec = 42_000_000.0,
                peerAddress = "192.168.43.1"
            )
            val completedImageRecord = com.example.model.TransferHistoryRecord(
                id = "hist_img_1",
                fileName = savedImgFile.name,
                sizeBytes = savedImgFile.length(),
                category = FileCategory.IMAGE,
                direction = com.example.model.TransferDirection.RECEIVING,
                status = FileTransferStatus.COMPLETED,
                timestampMillis = System.currentTimeMillis() - 5000L,
                savedPath = savedImgFile.absolutePath,
                uriString = android.net.Uri.fromFile(savedImgFile).toString(),
                mimeType = "image/jpeg",
                sha256Hash = Sha256Util.computeFileSha256(savedImgFile),
                sha256Verified = true,
                averageSpeedBytesPerSec = 35_000_000.0,
                peerAddress = "192.168.43.1"
            )
            val failedPartialRecord = com.example.model.TransferHistoryRecord(
                id = "hist_fail_1",
                fileName = "unfinished_movie.mp4",
                sizeBytes = 300_000_000L,
                category = FileCategory.VIDEO,
                direction = com.example.model.TransferDirection.RECEIVING,
                status = FileTransferStatus.FAILED,
                timestampMillis = System.currentTimeMillis() - 10_000L,
                savedPath = incompletePartPath.absolutePath,
                errorMessage = "انقطع الاتصال أثناء التحميل"
            )

            assertTrue(completedVideoRecord.isCompleted && completedVideoRecord.isVideoFile)
            assertTrue(completedImageRecord.isCompleted && completedImageRecord.isImageFile)
            assertFalse("Incomplete .part record must NEVER be marked isCompleted", failedPartialRecord.isCompleted)

            // Write history JSON to filesDir and verify ViewModel loads it on startup and opens exact media in UI
            val historyJsonArr = org.json.JSONArray()
            for (r in listOf(completedVideoRecord, completedImageRecord, failedPartialRecord)) {
                val o = JSONObject().apply {
                    put("id", r.id)
                    put("fileName", r.fileName)
                    put("sizeBytes", r.sizeBytes)
                    put("category", r.category.name)
                    put("direction", r.direction.name)
                    put("status", r.status.name)
                    put("timestampMillis", r.timestampMillis)
                    put("savedPath", r.savedPath ?: "")
                    put("uriString", r.uriString ?: "")
                    put("mimeType", r.mimeType ?: "")
                    put("sha256Hash", r.sha256Hash)
                    put("sha256Verified", r.sha256Verified)
                    put("averageSpeedBytesPerSec", r.averageSpeedBytesPerSec)
                    put("peerAddress", r.peerAddress)
                    put("errorMessage", r.errorMessage ?: "")
                }
                historyJsonArr.put(o)
            }
            File(context.filesDir, "barq_transfer_history.json").writeText(historyJsonArr.toString())

            val vm = P2PTransferViewModel(context.applicationContext as android.app.Application)
            val loadDeadline = System.currentTimeMillis() + 3_000L
            while (System.currentTimeMillis() < loadDeadline && vm.uiState.value.transferHistory.size < 3) {
                Thread.sleep(40)
            }
            assertEquals("ViewModel must load persisted transfer history across restarts", 3, vm.uiState.value.transferHistory.size)

            // Test opening completed Image in-app -> sets previewingHistoryRecord to exact image
            vm.openHistoryMediaInApp(completedImageRecord)
            assertEquals("hist_img_1", vm.uiState.value.previewingHistoryRecord?.id)
            assertEquals(savedImgFile.absolutePath, vm.uiState.value.previewingHistoryRecord?.savedPath)
            vm.closeHistoryMediaPreview()
            assertEquals(null, vm.uiState.value.previewingHistoryRecord)

            // Test opening completed Video in-app -> sets previewingHistoryRecord to exact video
            vm.openHistoryMediaInApp(completedVideoRecord)
            assertEquals("hist_vid_1", vm.uiState.value.previewingHistoryRecord?.id)
            assertEquals(savedVidFile.absolutePath, vm.uiState.value.previewingHistoryRecord?.savedPath)
            vm.closeHistoryMediaPreview()

            // Test attempting to open incomplete/failed record -> refused with clear Arabic message
            vm.openHistoryMediaInApp(failedPartialRecord)
            assertEquals(null, vm.uiState.value.previewingHistoryRecord)
            assertTrue(
                "Incomplete file open attempt must show clear Arabic warning",
                vm.uiState.value.statusBannerMessage.orEmpty().contains("لم تكتمل")
            )

            // Test deleting a file and attempting to open it -> graceful Arabic message without crash
            val deletedFileRecord = completedImageRecord.copy(
                id = "hist_deleted_1",
                fileName = "deleted_photo.jpg",
                savedPath = File(receiveDir, "non_existent_deleted_photo.jpg").absolutePath
            )
            vm.openHistoryMediaInApp(deletedFileRecord)
            assertEquals(null, vm.uiState.value.previewingHistoryRecord)
            assertTrue(
                "Deleted file open attempt must explain file is missing",
                vm.uiState.value.statusBannerMessage.orEmpty().contains("الملف غير موجود")
            )
        } finally {
            P2PTransferViewModel.resetRetainedEngineForTests()
            serverScope.cancel()
            tempRoot.deleteRecursively()
        }
    }

    private fun assertNullOrEmptyError(err: String?) {
        assertTrue("Expected no error but got: $err", err.isNullOrBlank())
    }

    @Test
    fun verifyPhase1TransferSessionManagementControlsAndSameNameIsolation() = runBlocking {
        P2PTransferViewModel.resetRetainedEngineForTests()
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempRoot = File(context.cacheDir, "barq_phase1_verification_${System.nanoTime()}").apply { mkdirs() }
        val senderDirA = File(tempRoot, "sender_a").apply { mkdirs() }
        val senderDirB = File(tempRoot, "sender_b").apply { mkdirs() }
        val receiveDir = File(tempRoot, "receiver_downloads").apply { mkdirs() }
        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        try {
            // 1. Create two distinct files with the EXACT SAME NAME ("same_video.mp4"), plus a pause target, a cancel target, and a late-added file
            val sameNameFile1 = File(senderDirA, "same_video.mp4").apply {
                writeBytes(ByteArray(96 * 1024) { idx -> ((idx * 17 + 3) and 0xFF).toByte() })
            }
            val sameNameFile2 = File(senderDirB, "same_video.mp4").apply {
                writeBytes(ByteArray(96 * 1024) { idx -> ((idx * 29 + 11) and 0xFF).toByte() })
            }
            val pauseTargetFile = File(senderDirA, "pause_resume_target.bin").apply {
                writeBytes(ByteArray(128 * 1024) { idx -> ((idx * 41 + 7) and 0xFF).toByte() })
            }
            val cancelTargetFile = File(senderDirA, "cancel_only_this.bin").apply {
                writeBytes(ByteArray(128 * 1024) { idx -> ((idx * 53 + 19) and 0xFF).toByte() })
            }
            val removableQueueFile = File(senderDirA, "remove_from_queue.bin").apply {
                writeBytes(ByteArray(64 * 1024) { idx -> ((idx * 13 + 5) and 0xFF).toByte() })
            }
            val lateAddedFile = File(senderDirB, "added_mid_session.bin").apply {
                writeBytes(ByteArray(80 * 1024) { idx -> ((idx * 37 + 23) and 0xFF).toByte() })
            }

            // Verify ViewModel queue management: adding files to active session, removing 1 file, cancelling 1 file, pausing/resuming 1 file, and rapid clicks
            val vm = P2PTransferViewModel(context.applicationContext as android.app.Application)
            vm.addPickedUris(
                listOf(
                    android.net.Uri.fromFile(sameNameFile1),
                    android.net.Uri.fromFile(sameNameFile2),
                    android.net.Uri.fromFile(pauseTargetFile),
                    android.net.Uri.fromFile(cancelTargetFile),
                    android.net.Uri.fromFile(removableQueueFile)
                )
            )

            val initialQueue = vm.uiState.value.files
            assertEquals("Two distinct files with identical names must both be kept with unique IDs", 5, initialQueue.size)
            assertEquals("All file IDs must be unique", 5, initialQueue.map { it.id }.distinct().size)

            // Start send session and simulate rapid repeated clicks on startSendSession
            vm.startSendSession(navigateToLiveScreen = false)
            val activeSessionId = vm.uiState.value.sessionId
            assertTrue("Session must be active after startSendSession", vm.uiState.value.isSenderReady)
            assertTrue("Session ID must be non-blank", activeSessionId.isNotBlank())

            // Remove 1 file during active session -> session stays active with same sessionId
            val removableId = initialQueue.first { it.name == "remove_from_queue.bin" }.id
            vm.removeFileItem(removableId)
            vm.removeFileItem(removableId) // Rapid duplicate click must be a safe no-op
            assertEquals(4, vm.uiState.value.files.size)
            assertTrue("Active session must continue after removing a single file", vm.uiState.value.isSenderReady)
            assertEquals("Session ID must not reset when removing a file", activeSessionId, vm.uiState.value.sessionId)

            // Add a new file to the active session -> session stays active with same sessionId
            vm.addPickedUris(listOf(android.net.Uri.fromFile(lateAddedFile)))
            assertEquals(5, vm.uiState.value.files.size)
            assertTrue("Session must remain active when adding new files", vm.uiState.value.isSenderReady)
            assertEquals("Session ID must remain unchanged when adding files to active session", activeSessionId, vm.uiState.value.sessionId)

            // Per-file pause and resume in ViewModel state -> only target file changes status
            val vmPauseId = vm.uiState.value.files.first { it.name == "pause_resume_target.bin" }.id
            val vmOtherId = vm.uiState.value.files.first { it.name == "same_video.mp4" }.id
            vm.toggleSingleFilePauseResume(vmPauseId)
            assertEquals(
                FileTransferStatus.PAUSED,
                vm.uiState.value.files.first { it.id == vmPauseId }.status
            )
            assertFalse(
                "Other files must NOT be paused when pausing a single file",
                vm.uiState.value.files.first { it.id == vmOtherId }.status == FileTransferStatus.PAUSED
            )
            // Resume that same file
            vm.toggleSingleFilePauseResume(vmPauseId)
            assertFalse(
                "Resumed single file must no longer be PAUSED",
                vm.uiState.value.files.first { it.id == vmPauseId }.status == FileTransferStatus.PAUSED
            )

            // Per-file cancel in ViewModel state -> only target file becomes CANCELLED, excluded from total progress denominator
            val vmCancelId = vm.uiState.value.files.first { it.name == "cancel_only_this.bin" }.id
            vm.cancelSingleFileTransfer(vmCancelId)
            vm.cancelSingleFileTransfer(vmCancelId) // Rapid duplicate click must be a safe no-op
            assertEquals(
                FileTransferStatus.CANCELLED,
                vm.uiState.value.files.first { it.id == vmCancelId }.status
            )
            assertEquals(4, vm.uiState.value.totalFilesOnlyCount)

            // 2. End-to-End Live Transfer Engine verification:
            //    - Same-name files ("same_video.mp4" #1 and #2) do not overwrite each other
            //    - Single paused file yields so other files finish first, then resumes and completes
            //    - Single cancelled file is skipped without affecting others
            //    - Newly added file on sender is discovered and downloaded during active session
            //    - Cancelling session never deletes completed files on receiver
            val senderFilesList = java.util.concurrent.CopyOnWriteArrayList<TransferFileItem>(
                listOf(
                    TransferFileItem(
                        id = "same_1",
                        name = "same_video.mp4",
                        sizeBytes = sameNameFile1.length(),
                        category = FileCategory.VIDEO,
                        localFile = sameNameFile1,
                        totalChunks = 2,
                        sha256Expected = Sha256Util.computeFileSha256(sameNameFile1)
                    ),
                    TransferFileItem(
                        id = "same_2",
                        name = "same_video.mp4",
                        sizeBytes = sameNameFile2.length(),
                        category = FileCategory.VIDEO,
                        localFile = sameNameFile2,
                        totalChunks = 2,
                        sha256Expected = Sha256Util.computeFileSha256(sameNameFile2)
                    ),
                    TransferFileItem(
                        id = "pause_1",
                        name = "pause_resume_target.bin",
                        sizeBytes = pauseTargetFile.length(),
                        category = FileCategory.DOCUMENT,
                        localFile = pauseTargetFile,
                        totalChunks = 2,
                        sha256Expected = Sha256Util.computeFileSha256(pauseTargetFile)
                    ),
                    TransferFileItem(
                        id = "cancel_1",
                        name = "cancel_only_this.bin",
                        sizeBytes = cancelTargetFile.length(),
                        category = FileCategory.DOCUMENT,
                        localFile = cancelTargetFile,
                        totalChunks = 2,
                        sha256Expected = Sha256Util.computeFileSha256(cancelTargetFile)
                    )
                )
            )
            val cancelledIdsSet = java.util.concurrent.ConcurrentHashMap.newKeySet<String>().apply {
                add("cancel_1")
            }
            val pausedIdsSet = java.util.concurrent.ConcurrentHashMap.newKeySet<String>().apply {
                add("pause_1")
            }

            val server = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { "7788" },
                isSenderReadyProvider = { true },
                chunkSizeProvider = { ChunkSizeOption.CHUNK_64KB },
                filesProvider = { senderFilesList },
                onChunkServed = { _, _, _ -> },
                requireReceiverApprovalProvider = { false },
                isPausedProvider = { false },
                isFileCancelledProvider = { id -> id in cancelledIdsSet },
                isFilePausedProvider = { id -> id in pausedIdsSet }
            )
            val boundPort = server.startServer(preferredPort = 0)

            try {
                val receiverMap = java.util.concurrent.ConcurrentHashMap<String, TransferFileItem>()
                senderFilesList.forEach { item ->
                    receiverMap[item.id] = item.copy(
                        localFile = null,
                        status = if (item.id in cancelledIdsSet) FileTransferStatus.CANCELLED
                        else if (item.id in pausedIdsSet) FileTransferStatus.PAUSED
                        else FileTransferStatus.QUEUED
                    )
                }

                // Launch background coordinator that:
                // (a) waits until same_1 and same_2 complete while pause_1 is still PAUSED,
                // (b) dynamically adds lateAddedFile to sender manifest during the active session,
                // (c) resumes pause_1 so both pause_1 and lateAddedFile finish!
                val coordinatorJob = serverScope.launch {
                    val waitStart = System.currentTimeMillis()
                    while (System.currentTimeMillis() - waitStart < 6_000L) {
                        val s1 = receiverMap["same_1"]?.status
                        val s2 = receiverMap["same_2"]?.status
                        if (s1 == FileTransferStatus.COMPLETED && s2 == FileTransferStatus.COMPLETED) {
                            break
                        }
                        delay(40L)
                    }
                    // Verify pause_1 is STILL paused while same_1 and same_2 already completed!
                    assertEquals(
                        "Single paused file must remain PAUSED while other files complete",
                        FileTransferStatus.PAUSED,
                        receiverMap["pause_1"]?.status
                    )
                    // Dynamically add a new file to the active sender session
                    senderFilesList.add(
                        TransferFileItem(
                            id = "late_added_1",
                            name = "added_mid_session.bin",
                            sizeBytes = lateAddedFile.length(),
                            category = FileCategory.DOCUMENT,
                            localFile = lateAddedFile,
                            totalChunks = 2,
                            sha256Expected = Sha256Util.computeFileSha256(lateAddedFile)
                        )
                    )
                    // Now resume pause_1
                    pausedIdsSet.remove("pause_1")
                    receiverMap.computeIfPresent("pause_1") { _, old ->
                        old.copy(status = FileTransferStatus.QUEUED)
                    }
                }

                val anyFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                    hostIp = "127.0.0.1",
                    hostPort = boundPort,
                    sessionCode = "7788",
                    chunkSizeBytes = ChunkSizeOption.CHUNK_64KB.bytes,
                    downloadDir = receiveDir,
                    itemsProvider = { receiverMap.values.toList() },
                    isPausedProvider = { false },
                    isFileCancelledProvider = { id -> id in cancelledIdsSet },
                    isFilePausedProvider = { id -> id in pausedIdsSet },
                    onNewFilesDiscovered = { discovered ->
                        for (d in discovered) {
                            receiverMap.putIfAbsent(d.id, d)
                        }
                    },
                    onFileUpdated = { fileId, _, _, transform ->
                        receiverMap.computeIfPresent(fileId) { _, old -> transform(old) }
                    },
                    onFileCompleted = { completedItem, _ ->
                        receiverMap[completedItem.id] = completedItem
                    },
                    onFileFailed = { failedItem, err ->
                        receiverMap[failedItem.id] = failedItem.copy(status = FileTransferStatus.FAILED, errorMessage = err)
                    }
                )
                coordinatorJob.join()

                assertFalse("Active session with single-file pause/resume/cancel/add must succeed without failure", anyFailed)
                assertEquals(FileTransferStatus.COMPLETED, receiverMap["same_1"]?.status)
                assertEquals(FileTransferStatus.COMPLETED, receiverMap["same_2"]?.status)
                assertEquals(FileTransferStatus.COMPLETED, receiverMap["pause_1"]?.status)
                assertEquals(FileTransferStatus.COMPLETED, receiverMap["late_added_1"]?.status)
                assertEquals(FileTransferStatus.CANCELLED, receiverMap["cancel_1"]?.status)

                // Verify the two same-name files were saved to distinct paths and neither overwrote the other
                val savedSame1 = File(receiverMap["same_1"]!!.savedPath!!)
                val savedSame2 = File(receiverMap["same_2"]!!.savedPath!!)
                assertTrue("First same-name file must exist on disk", savedSame1.exists())
                assertTrue("Second same-name file must exist on disk", savedSame2.exists())
                assertTrue("Same-name files must have distinct paths on disk", savedSame1.absolutePath != savedSame2.absolutePath)
                assertEquals(Sha256Util.computeFileSha256(sameNameFile1), Sha256Util.computeFileSha256(savedSame1))
                assertEquals(Sha256Util.computeFileSha256(sameNameFile2), Sha256Util.computeFileSha256(savedSame2))

                // Verify cancelled file was NOT created on disk
                assertFalse("Cancelled file must not exist on receiver", File(receiveDir, "cancel_only_this.bin").exists())

                // Verify that cancelling the entire session NEVER deletes already-completed files on disk
                vm.cancelActiveTransfer()
                assertTrue("Completed file 1 must still exist after session cancel", savedSame1.exists())
                assertTrue("Completed file 2 must still exist after session cancel", savedSame2.exists())
                assertTrue(
                    "Completed pause-resumed file must still exist after session cancel",
                    File(receiverMap["pause_1"]!!.savedPath!!).exists()
                )
                assertTrue(
                    "Completed dynamically-added file must still exist after session cancel",
                    File(receiverMap["late_added_1"]!!.savedPath!!).exists()
                )
            } finally {
                server.stopServer()
            }
        } finally {
            P2PTransferViewModel.resetRetainedEngineForTests()
            serverScope.cancel()
            tempRoot.deleteRecursively()
        }
    }

    @Test
    fun verifyPhase2LargeFileOver4GbStreamingResumeLocksAndErrorResilience(): Unit = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        P2PTransferViewModel.resetRetainedEngineForTests()
        val tempRoot = File(context.cacheDir, "phase2_4gb_resume_test_${System.currentTimeMillis()}").apply { mkdirs() }
        val senderDir = File(tempRoot, "sender").apply { mkdirs() }
        val receiveDir = File(tempRoot, "receiver").apply { mkdirs() }
        val serverScope = kotlinx.coroutines.CoroutineScope(
            kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.IO
        )

        try {
            // 1. Verify 64-bit Long chunk math for > 4 GB (4.5 GB, 12 GB, 64 GB) without Int overflow
            val size4_5Gb = 4_831_838_208L // 4.5 GB (> UInt.MAX_VALUE 4,294,967,295)
            val size12Gb = 12_884_901_888L // 12 GB
            val size64Gb = 68_719_476_736L // 64 GB
            val chunks4_5Gb16Mb = com.example.model.computeTotalChunksForSize(size4_5Gb, ChunkSizeOption.AUTO_MAX.bytes)
            val chunks12Gb512Kb = com.example.model.computeTotalChunksForSize(size12Gb, ChunkSizeOption.CHUNK_512KB.bytes)
            val chunks64Gb64Kb = com.example.model.computeTotalChunksForSize(size64Gb, ChunkSizeOption.CHUNK_64KB.bytes)
            assertEquals(576, chunks4_5Gb16Mb)
            assertEquals(24_576, chunks12Gb512Kb)
            assertTrue("64 GB with 64 KB chunks must be positive without Int overflow", chunks64Gb64Kb > 1_000_000)

            // 2. Verify partial/unverified files never report 100% (1.0f) until status == COMPLETED
            val partialItemAtFullBytes = TransferFileItem(
                id = "verifying_item",
                name = "movie_4k.mp4",
                sizeBytes = size4_5Gb,
                category = FileCategory.VIDEO,
                totalChunks = chunks4_5Gb16Mb,
                completedChunks = chunks4_5Gb16Mb,
                transferredBytes = size4_5Gb,
                status = FileTransferStatus.VERIFYING
            )
            assertTrue(
                "Unverified/partial item must never report 1.0f progressFraction before COMPLETED",
                partialItemAtFullBytes.progressFraction < 1.0f
            )
            assertEquals(99, partialItemAtFullBytes.progressPercent)
            val completedItemAtFullBytes = partialItemAtFullBytes.copy(status = FileTransferStatus.COMPLETED)
            assertEquals(1.0f, completedItemAtFullBytes.progressFraction, 0.0001f)
            assertEquals(100, completedItemAtFullBytes.progressPercent)

            // 3. Verify BarqTransferForegroundService WakeLock & WifiLock acquisition and guaranteed release
            BarqTransferForegroundService.startOrUpdateTransfer(
                context = context,
                direction = TransferDirection.RECEIVING,
                currentFileName = "large_movie_4_5gb.mp4",
                completedFiles = 0,
                totalFiles = 2,
                transferredBytes = 2_500_000_000L,
                totalBytes = size4_5Gb,
                speedBytesPerSec = 42_000_000L,
                isPaused = false,
                forceUpdate = true
            )
            assertTrue(
                "WakeLock must be acquired immediately when transfer starts/updates",
                BarqTransferForegroundService.isWakeLockHeld
            )
            assertTrue(
                "WifiLock must be acquired immediately when transfer starts/updates",
                BarqTransferForegroundService.isWifiLockHeld
            )
            BarqTransferForegroundService.stopTransferService(context)
            assertFalse(
                "WakeLock must be released immediately when transfer finishes or stops",
                BarqTransferForegroundService.isWakeLockHeld
            )
            assertFalse(
                "WifiLock must be released immediately when transfer finishes or stops",
                BarqTransferForegroundService.isWifiLockHeld
            )

            // 4. Verify real > 4 GB sparse file streaming across the 4 GB (4,294,967,296L) boundary
            //    without Int overflow or loading the file into RAM
            val boundary4Gb = 4_294_967_296L
            val tailPayloadSize = 1_048_576 // 1 MB past the 4 GB boundary
            val sparseOver4GbSize = boundary4Gb + tailPayloadSize.toLong()
            val tailBytes = ByteArray(tailPayloadSize) { idx -> ((idx * 73 + 19) and 0xFF).toByte() }
            val sparse4GbFile = File(senderDir, "sparse_over_4gb.bin")
            java.io.RandomAccessFile(sparse4GbFile, "rw").use { raf ->
                raf.setLength(sparseOver4GbSize)
                raf.seek(boundary4Gb)
                raf.write(tailBytes)
            }
            assertEquals(sparseOver4GbSize, sparse4GbFile.length())

            // Also create a 3.2 MB real file for testing:
            // (a) Oversized/corrupt .part recovery & HTTP 416 handling
            // (b) Mid-transfer Wi-Fi drop at 1.5 MB + seamless resume from .part offset
            val resumableBytes = ByteArray(3_200_000) { idx -> ((idx * 41 + 7) and 0xFF).toByte() }
            val resumableSourceFile = File(senderDir, "resumable_video.mp4").apply {
                writeBytes(resumableBytes)
            }
            val resumableSha = Sha256Util.computeFileSha256(resumableSourceFile)

            // File for testing sender lost permission / deleted source file mid-session while preserving completed files
            val vanishesSourceFile = File(senderDir, "vanishes_before_stream.bin").apply {
                writeBytes(ByteArray(256 * 1024) { 0x5A.toByte() })
            }

            val senderItems = java.util.concurrent.CopyOnWriteArrayList<TransferFileItem>(
                listOf(
                    TransferFileItem(
                        id = "over4gb_item",
                        name = sparse4GbFile.name,
                        sizeBytes = sparseOver4GbSize,
                        category = FileCategory.VIDEO,
                        localFile = sparse4GbFile,
                        totalChunks = com.example.model.computeTotalChunksForSize(sparseOver4GbSize, ChunkSizeOption.CHUNK_512KB.bytes)
                    ),
                    TransferFileItem(
                        id = "resumable_item",
                        name = resumableSourceFile.name,
                        sizeBytes = resumableSourceFile.length(),
                        category = FileCategory.VIDEO,
                        localFile = resumableSourceFile,
                        totalChunks = com.example.model.computeTotalChunksForSize(resumableSourceFile.length(), ChunkSizeOption.CHUNK_512KB.bytes),
                        sha256Expected = resumableSha
                    ),
                    TransferFileItem(
                        id = "vanishing_item",
                        name = vanishesSourceFile.name,
                        sizeBytes = vanishesSourceFile.length(),
                        category = FileCategory.DOCUMENT,
                        localFile = vanishesSourceFile,
                        totalChunks = 1
                    )
                )
            )

            var lastStreamedOffsetOver4Gb = 0L
            val server = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { "4400" },
                isSenderReadyProvider = { true },
                chunkSizeProvider = { ChunkSizeOption.CHUNK_512KB },
                filesProvider = { senderItems },
                onChunkServed = { _, _, _ -> },
                onStreamOffsetServed = { fileId, _, _, endOffset ->
                    if (fileId == "over4gb_item") {
                        lastStreamedOffsetOver4Gb = maxOf(lastStreamedOffsetOver4Gb, endOffset)
                    }
                },
                requireReceiverApprovalProvider = { false }
            )
            val port = server.startServer(preferredPort = 0)

            try {
                // 4a. Stream the 1 MB slice starting at offset 4,294,967,296L (exact 4 GB boundary)
                val stream4GbUrl = java.net.URL(
                    "http://127.0.0.1:$port/api/stream?fileId=over4gb_item&offset=$boundary4Gb&chunkSize=${ChunkSizeOption.CHUNK_512KB.bytes}&code=4400"
                )
                val conn4Gb = (stream4GbUrl.openConnection() as java.net.HttpURLConnection).apply {
                    connectTimeout = 5000
                    readTimeout = 10000
                }
                assertEquals("Streaming at offset >= 4 GB must return HTTP 200 OK", 200, conn4Gb.responseCode)
                val receivedTail = conn4Gb.inputStream.use { it.readBytes() }
                conn4Gb.disconnect()
                assertEquals(tailPayloadSize, receivedTail.size)
                assertTrue(
                    "Bytes streamed from offset 4,294,967,296L (> 4 GB) must match exact source bytes without Int overflow",
                    receivedTail.contentEquals(tailBytes)
                )
                assertEquals(sparseOver4GbSize, lastStreamedOffsetOver4Gb)

                // 4b. Verify HTTP 416 Range Not Satisfiable when offset > fileItem.sizeBytes
                val invalidOffset = sparseOver4GbSize + 65536L
                val conn416 = (java.net.URL(
                    "http://127.0.0.1:$port/api/stream?fileId=over4gb_item&offset=$invalidOffset&code=4400"
                ).openConnection() as java.net.HttpURLConnection)
                assertEquals(
                    "Offset exceeding sizeBytes must return HTTP 416 Range Not Satisfiable",
                    416,
                    conn416.responseCode
                )
                conn416.disconnect()

                // 5. Simulate an interrupted Wi-Fi transfer that left a valid 1.5 MB .part prefix on disk
                val validResumePrefixLen = 1_500_000
                val expectedPartFile = File(receiveDir, "${resumableSourceFile.name}.resumable_item.part")
                expectedPartFile.writeBytes(resumableBytes.copyOfRange(0, validResumePrefixLen))
                assertFalse(
                    "Final file must NOT exist while transfer is still a partial .part file",
                    File(receiveDir, resumableSourceFile.name).exists()
                )

                // Delete vanishesSourceFile on sender BEFORE receiver requests it so sender returns 403 SOURCE_FILE_UNREADABLE
                assertTrue(vanishesSourceFile.delete())

                val receiverItemsMap = java.util.concurrent.ConcurrentHashMap<String, TransferFileItem>()
                receiverItemsMap["resumable_item"] = senderItems[1].copy(localFile = null)
                receiverItemsMap["vanishing_item"] = senderItems[2].copy(localFile = null)

                var minObservedTransferredOnResume = Long.MAX_VALUE
                val anyFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                    hostIp = "127.0.0.1",
                    hostPort = port,
                    sessionCode = "4400",
                    chunkSizeBytes = ChunkSizeOption.CHUNK_512KB.bytes,
                    downloadDir = receiveDir,
                    itemsProvider = { listOfNotNull(receiverItemsMap["resumable_item"], receiverItemsMap["vanishing_item"]) },
                    isPausedProvider = { false },
                    onFileUpdated = { fileId, _, _, transform ->
                        receiverItemsMap.computeIfPresent(fileId) { _, old ->
                            val updated = transform(old)
                            if (fileId == "resumable_item" && updated.transferredBytes > 0L) {
                                minObservedTransferredOnResume = minOf(minObservedTransferredOnResume, updated.transferredBytes)
                            }
                            updated
                        }
                    },
                    onFileCompleted = { completedItem, _ ->
                        receiverItemsMap[completedItem.id] = completedItem
                    },
                    onFileFailed = { failedItem, err ->
                        receiverItemsMap[failedItem.id] = failedItem.copy(status = FileTransferStatus.FAILED, errorMessage = err)
                    }
                )

                assertTrue("Session must report anyFailed = true because vanishing_item lost source file on sender", anyFailed)

                // Verify resumable_item resumed from 1.5 MB .part offset, completed, verified SHA-256, and removed .part
                val completedResumable = receiverItemsMap["resumable_item"]!!
                assertEquals(FileTransferStatus.COMPLETED, completedResumable.status)
                assertTrue(
                    "Resumable download must start from existing 1.5 MB .part offset ($minObservedTransferredOnResume)",
                    minObservedTransferredOnResume >= validResumePrefixLen.toLong()
                )
                assertFalse("Temporary .part file must be removed after completion", expectedPartFile.exists())
                val finalSavedResumable = File(receiveDir, resumableSourceFile.name)
                assertTrue("Final file must exist after verification and rename", finalSavedResumable.exists())
                assertEquals(resumableSha, Sha256Util.computeFileSha256(finalSavedResumable))

                // Verify vanishing_item failed gracefully with Arabic permission/unreadable message without touching completedResumable
                val failedVanishing = receiverItemsMap["vanishing_item"]!!
                assertEquals(FileTransferStatus.FAILED, failedVanishing.status)
                assertTrue(
                    "Unreadable/removed sender file must report clear Arabic diagnostic: ${failedVanishing.errorMessage}",
                    failedVanishing.errorMessage.orEmpty().contains("صلاحية") ||
                        failedVanishing.errorMessage.orEmpty().contains("المرسِل")
                )
                assertTrue("Previously completed file must remain intact on disk", finalSavedResumable.exists())

                // 6. Verify oversized/corrupted .part file (> sizeBytes) is automatically truncated and re-downloaded cleanly
                finalSavedResumable.delete()
                val corruptOversizedPart = File(receiveDir, "${resumableSourceFile.name}.resumable_item.part")
                corruptOversizedPart.writeBytes(ByteArray(resumableBytes.size + 8192) { 0x7F.toByte() })
                assertTrue(corruptOversizedPart.length() > resumableSourceFile.length())

                receiverItemsMap["resumable_item"] = senderItems[1].copy(localFile = null, status = FileTransferStatus.QUEUED)
                senderItems.removeIf { it.id != "resumable_item" }
                val retryFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                    hostIp = "127.0.0.1",
                    hostPort = port,
                    sessionCode = "4400",
                    chunkSizeBytes = ChunkSizeOption.CHUNK_512KB.bytes,
                    downloadDir = receiveDir,
                    itemsProvider = { listOf(receiverItemsMap["resumable_item"]!!) },
                    isPausedProvider = { false },
                    onFileUpdated = { fileId, _, _, transform ->
                        receiverItemsMap.computeIfPresent(fileId) { _, old -> transform(old) }
                    },
                    onFileCompleted = { completedItem, _ ->
                        receiverItemsMap[completedItem.id] = completedItem
                    },
                    onFileFailed = { failedItem, err ->
                        receiverItemsMap[failedItem.id] = failedItem.copy(status = FileTransferStatus.FAILED, errorMessage = err)
                    }
                )
                assertFalse("Oversized .part file must be truncated and re-downloaded cleanly", retryFailed)
                assertEquals(FileTransferStatus.COMPLETED, receiverItemsMap["resumable_item"]?.status)
                assertEquals(resumableSha, Sha256Util.computeFileSha256(finalSavedResumable))

                // 7. Verify ENOSPC (storage full) and SecurityException detectors
                assertTrue(P2PTransferViewModel.isStorageFullException(java.io.IOException("write failed: ENOSPC (No space left on device)")))
                assertTrue(P2PTransferViewModel.isPermissionOrUnreadableException(SecurityException("Permission denied")))
            } finally {
                server.stopServer()
            }
        } finally {
            BarqTransferForegroundService.stopTransferService(context)
            P2PTransferViewModel.resetRetainedEngineForTests()
            serverScope.cancel()
            tempRoot.deleteRecursively()
        }
    }

    @Test
    fun verifyPhase3MediaPerformanceVideoDiscoverySafPersistenceAndMassiveLibraries(): Unit = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        P2PTransferViewModel.resetRetainedEngineForTests()
        DeviceMediaRepository.clearThumbnailCache(context)

        val moviesRoot = android.os.Environment.getExternalStoragePublicDirectory(
            android.os.Environment.DIRECTORY_MOVIES
        ).apply { mkdirs() }
        val picturesRoot = android.os.Environment.getExternalStoragePublicDirectory(
            android.os.Environment.DIRECTORY_PICTURES
        ).apply { mkdirs() }
        val dcimRoot = android.os.Environment.getExternalStoragePublicDirectory(
            android.os.Environment.DIRECTORY_DCIM
        ).apply { mkdirs() }

        val nestedMoviesFolder = File(moviesRoot, "BarqPhase3Series/Season1/Episodes/4K").apply {
            deleteRecursively()
            mkdirs()
        }
        val nestedDcimFolder = File(dcimRoot, "Camera/BarqClips").apply {
            deleteRecursively()
            mkdirs()
        }
        val nestedPicturesFolder = File(picturesRoot, "BarqAlbum2026/Trips").apply {
            deleteRecursively()
            mkdirs()
        }
        val massiveFolderA = File(picturesRoot, "BarqMassiveA").apply {
            deleteRecursively()
            mkdirs()
        }
        val massiveFolderB = File(moviesRoot, "BarqMassiveB").apply {
            deleteRecursively()
            mkdirs()
        }

        try {
            // =========================================================================
            // 1. Verify Videos & Images Discovery across MediaStore, Subfolders,
            //    0-byte Scoped Storage MediaStore rows, and Multi-GB Videos (25 GB)
            // =========================================================================
            val episodeMkv = File(nestedMoviesFolder, "episode_01_hdr.mkv").apply {
                writeBytes(ByteArray(4096) { 0x1A })
            }
            val cameraMp4 = File(nestedDcimFolder, "IMG_2026_clip.mp4").apply {
                writeBytes(ByteArray(8192) { 0x2B })
            }
            // Same filename in a different subfolder to verify no collision
            val duplicateNameMp4 = File(nestedMoviesFolder, "IMG_2026_clip.mp4").apply {
                writeBytes(ByteArray(6144) { 0x3C })
            }
            // Multi-gigabyte (25 GB = 26,843,545,600 bytes) sparse video file
            val multiGbSize = 25L * 1024L * 1024L * 1024L
            val multiGbVideoFile = File(nestedMoviesFolder, "cinema_raw_25gb.mov")
            RandomAccessFile(multiGbVideoFile, "rw").use { raf ->
                raf.setLength(multiGbSize)
            }
            assertEquals(multiGbSize, multiGbVideoFile.length())

            // Insert a Scoped Storage MediaStore.Video row where SIZE = 0 and _DATA is virtual
            val scopedVideoValues = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Video.Media.DISPLAY_NAME, "scoped_storage_video.mp4")
                put(android.provider.MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(android.provider.MediaStore.Video.Media.SIZE, 0L)
                put(android.provider.MediaStore.Video.Media.DURATION, 45_000L)
                put(android.provider.MediaStore.Video.Media.BUCKET_DISPLAY_NAME, "Camera")
                put(android.provider.MediaStore.Video.Media.DATE_MODIFIED, System.currentTimeMillis() / 1000L)
            }
            val insertedVideoUri = context.contentResolver.insert(
                android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                scopedVideoValues
            )

            // Create a real valid 32x32 PNG image for thumbnail generation & caching test
            val realPhotoFile = File(nestedPicturesFolder, "barq_real_photo.png")
            val testBitmap = android.graphics.Bitmap.createBitmap(32, 32, android.graphics.Bitmap.Config.ARGB_8888)
            testBitmap.eraseColor(android.graphics.Color.CYAN)
            java.io.FileOutputStream(realPhotoFile).use { out ->
                testBitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out)
            }

            // Create 140 photos and 90 videos to test progressive batch loading & pagination
            for (i in 1..140) {
                File(massiveFolderA, "photo_batch_${i}.jpg").writeBytes(byteArrayOf(0xFF.toByte(), 0xD8.toByte(), i.toByte()))
            }
            for (i in 1..90) {
                File(massiveFolderB, "video_batch_${i}.mp4").writeBytes(byteArrayOf(0x00, 0x00, 0x00, 0x18, i.toByte()))
            }

            val videoProgressiveBatches = mutableListOf<Int>()
            val discoveredVideos = DeviceMediaRepository.loadVideos(
                context = context,
                maxItems = 500,
                offset = 0,
                batchSize = 30,
                onBatchLoaded = { batchSnapshot ->
                    videoProgressiveBatches.add(batchSnapshot.size)
                }
            )

            assertTrue(
                "Videos must be discovered from MediaStore and nested subfolders (found ${discoveredVideos.size})",
                discoveredVideos.size >= 94
            )
            assertTrue(
                "Progressive onBatchLoaded must fire multiple times before scan finishes",
                videoProgressiveBatches.size >= 2 && videoProgressiveBatches.first() < discoveredVideos.size
            )
            assertTrue(
                "Nested MKV video in 4-level deep subfolder must be discovered",
                discoveredVideos.any { it.name == "episode_01_hdr.mkv" }
            )
            assertTrue(
                "Both videos with identical filename 'IMG_2026_clip.mp4' in different folders must be preserved",
                discoveredVideos.count { it.name == "IMG_2026_clip.mp4" } >= 2
            )
            val discovered25GbVideo = discoveredVideos.find { it.name == "cinema_raw_25gb.mov" }
            assertNotNull("25 GB video must be discovered without loading into memory", discovered25GbVideo)
            assertEquals(multiGbSize, discovered25GbVideo!!.sizeBytes)

            if (insertedVideoUri != null) {
                assertTrue(
                    "Scoped Storage MediaStore video with SIZE=0 must NOT be dropped",
                    discoveredVideos.any { it.name == "scoped_storage_video.mp4" }
                )
            }

            // =========================================================================
            // 2. Verify Pagination (offset + maxItems) for Images & Videos
            // =========================================================================
            val firstPageImages = DeviceMediaRepository.loadImages(
                context = context,
                maxItems = 40,
                offset = 0,
                batchSize = 20
            )
            val secondPageImages = DeviceMediaRepository.loadImages(
                context = context,
                maxItems = 40,
                offset = 40,
                batchSize = 20
            )
            assertEquals(40, firstPageImages.size)
            assertEquals(40, secondPageImages.size)
            assertTrue(
                "Paginated pages (offset 0 vs offset 40) must return distinct items",
                firstPageImages.map { it.id }.intersect(secondPageImages.map { it.id }.toSet()).isEmpty()
            )

            // =========================================================================
            // 3. Verify Two-Tier Thumbnail Cache (Memory LruCache + Disk Cache)
            //    and In-Flight Coroutine Deduplication (generated ONCE, reused afterwards)
            // =========================================================================
            val allImages = DeviceMediaRepository.loadImages(context, maxItems = 300)
            val targetPhotoItem = allImages.first { it.name == "barq_real_photo.png" }

            DeviceMediaRepository.clearThumbnailCache(context)
            assertEquals(0, DeviceMediaRepository.getThumbnailGenerationCount(targetPhotoItem.id))

            // Launch 8 concurrent requests for the same image thumbnail
            val concurrentScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
            val deferredResults = (1..8).map {
                concurrentScope.launch {
                    val bmp = DeviceMediaRepository.getOrLoadThumbnailAsync(context, targetPhotoItem)
                    assertNotNull("Thumbnail bitmap must be decoded for real PNG", bmp)
                }
            }
            deferredResults.forEach { it.join() }
            concurrentScope.cancel()

            assertEquals(
                "In-flight deduplication must ensure thumbnail is generated only ONCE across 8 concurrent requests",
                1,
                DeviceMediaRepository.getThumbnailGenerationCount(targetPhotoItem.id)
            )
            assertNotNull(
                "Thumbnail must now be immediately available in memory LruCache",
                DeviceMediaRepository.getCachedThumbnail(targetPhotoItem.id)
            )

            // Subsequent call when returning to folder must reuse cache without regenerating
            val cachedBmp = DeviceMediaRepository.getOrLoadThumbnailAsync(context, targetPhotoItem)
            assertNotNull(cachedBmp)
            assertEquals(
                "Returning to folder must reuse cached thumbnail without regenerating",
                1,
                DeviceMediaRepository.getThumbnailGenerationCount(targetPhotoItem.id)
            )

            // =========================================================================
            // 4. Verify No Premature Empty State Before Video Scan Completes
            // =========================================================================
            val vm = P2PTransferViewModel(context.applicationContext as android.app.Application)
            val deadline = System.currentTimeMillis() + 6_000L
            while (System.currentTimeMillis() < deadline && !vm.uiState.value.hasCompletedInitialVideoScan) {
                // While hasCompletedInitialVideoScan is false, isLoadingVideos is true so empty state is blocked
                delay(25L)
            }
            assertTrue("Initial video scan must complete", vm.uiState.value.hasCompletedInitialVideoScan)
            assertFalse("isLoadingVideos must be false after scan completes", vm.uiState.value.isLoadingVideos)
            assertTrue(
                "ViewModel deviceVideos must contain discovered videos so 'لا توجد فيديوهات' never appears when videos exist",
                vm.uiState.value.deviceVideos.isNotEmpty()
            )

            // Verify ViewMode toggle (LIST <-> GRID) and batch pagination in ViewModel
            assertEquals(com.example.model.MediaViewMode.LIST, vm.uiState.value.mediaViewMode)
            vm.toggleMediaViewMode()
            assertEquals(com.example.model.MediaViewMode.GRID, vm.uiState.value.mediaViewMode)
            val initialLimit = vm.uiState.value.mediaVisiblePageLimit
            vm.loadNextMediaBatch(FileCategory.VIDEO)
            assertTrue(
                "loadNextMediaBatch must advance mediaVisiblePageLimit",
                vm.uiState.value.mediaVisiblePageLimit > initialLimit
            )

            // =========================================================================
            // 5. Verify Reliable SAF Persistence Across App Restarts, No Redundant Prompts,
            //    Additive User Folders, and Revoked Permission Detection
            // =========================================================================
            val safUri1 = android.net.Uri.fromFile(nestedMoviesFolder)
            val safUri2 = android.net.Uri.fromFile(nestedPicturesFolder)

            val savedItem1 = DeviceMediaRepository.persistAndSaveSafFolder(
                context = context,
                treeUri = safUri1,
                customDisplayName = "مجلد أفلام المستخدم"
            )
            val savedItem2 = DeviceMediaRepository.persistAndSaveSafFolder(
                context = context,
                treeUri = safUri2,
                customDisplayName = "مجلد صور الرحلات"
            )
            assertTrue(savedItem1.isValid)
            assertTrue(savedItem2.isValid)

            // Create a new ViewModel instance to simulate app close & reopen
            val restartedVm = P2PTransferViewModel(context.applicationContext as android.app.Application)
            restartedVm.restorePersistedSafFolders()
            val restoredFolders = restartedVm.uiState.value.persistedSafFolders
            assertTrue(
                "Both user-selected SAF folders must be restored after app restart without overwriting each other",
                restoredFolders.any { it.uriString == safUri1.toString() } &&
                    restoredFolders.any { it.uriString == safUri2.toString() }
            )
            assertFalse(
                "shouldRequestSafFolderSelection must be FALSE when valid persisted SAF permission exists",
                restartedVm.shouldRequestSafFolderSelection(safUri1)
            )
            assertFalse(
                "shouldRequestSafFolderSelection(null) must be FALSE when user already has valid persisted SAF folders",
                restartedVm.shouldRequestSafFolderSelection(null)
            )

            // Simulate revoked permission on safUri1
            DeviceMediaRepository.markSafFolderRevoked(context, safUri1)
            restartedVm.restorePersistedSafFolders()
            assertTrue(
                "Revoked SAF folder must be surfaced in revokedSafFolders state",
                restartedVm.uiState.value.revokedSafFolders.any { it.uriString == safUri1.toString() }
            )
            assertTrue(
                "shouldRequestSafFolderSelection must return TRUE for the specific revoked URI",
                restartedVm.shouldRequestSafFolderSelection(safUri1)
            )
            assertFalse(
                "Other valid SAF folder (safUri2) must remain active and valid",
                restartedVm.shouldRequestSafFolderSelection(safUri2)
            )

            // =========================================================================
            // 6. Verify Cancellation of Stale Folder Loading When Switching Folders Rapidly
            // =========================================================================
            var cancelFlag = false
            val partialCancelledResult = DeviceMediaRepository.browseLocalDirectoryChildren(
                browsingRelOrAbsPath = picturesRoot.absolutePath,
                allKnownFolders = emptyList(),
                allKnownFiles = emptyList(),
                onPartialResult = { _, _ ->
                    cancelFlag = true
                },
                isCancelled = { cancelFlag }
            )
            assertNotNull(partialCancelledResult)

            // Rapidly switch folders in ViewModel: MassiveA -> MassiveB -> BarqAlbum2026/Trips
            restartedVm.setBrowsingFolderFilter("Pictures/BarqMassiveA")
            restartedVm.setBrowsingFolderFilter("Movies/BarqMassiveB")
            restartedVm.setBrowsingFolderFilter("Pictures/BarqAlbum2026/Trips")

            val browseDeadline = System.currentTimeMillis() + 5_000L
            while (System.currentTimeMillis() < browseDeadline &&
                (restartedVm.uiState.value.isBrowsingDirectoryLoading ||
                    restartedVm.uiState.value.currentBrowsingFiles.none { it.name == "barq_real_photo.png" })
            ) {
                delay(20L)
            }
            assertEquals(
                "Active folder filter must match the latest selected folder after rapid switching",
                "Pictures/BarqAlbum2026/Trips",
                restartedVm.uiState.value.browsingFolderFilter
            )
            assertTrue(
                "Latest folder contents must contain 'barq_real_photo.png' and not stale files from previous folders",
                restartedVm.uiState.value.currentBrowsingFiles.any { it.name == "barq_real_photo.png" } &&
                    restartedVm.uiState.value.currentBrowsingFiles.none { it.name.startsWith("photo_batch_") }
            )
        } finally {
            nestedMoviesFolder.parentFile?.parentFile?.parentFile?.deleteRecursively()
            nestedDcimFolder.deleteRecursively()
            nestedPicturesFolder.parentFile?.deleteRecursively()
            massiveFolderA.deleteRecursively()
            massiveFolderB.deleteRecursively()
            DeviceMediaRepository.clearThumbnailCache(context)
            P2PTransferViewModel.resetRetainedEngineForTests()
        }
    }

    @Test
    fun verifyPhase4VideoTransferReliabilityRetryResumeStateSyncAndCompactUi(): Unit = runBlocking {
        P2PTransferViewModel.resetRetainedEngineForTests()
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempRoot = java.nio.file.Files.createTempDirectory("barq_phase4_transfer_test").toFile()
        val senderDir = File(tempRoot, "sender_videos").apply { mkdirs() }
        val receiverDir10Success = File(tempRoot, "receiver_10_success").apply { mkdirs() }
        val receiverDirPartialFail = File(tempRoot, "receiver_partial_fail").apply { mkdirs() }
        val receiverDirReadOnly = File(tempRoot, "receiver_readonly").apply { mkdirs() }
        val receiverDirResume = File(tempRoot, "receiver_part_resume").apply { mkdirs() }
        val receiverDirDedup = File(tempRoot, "receiver_dedup").apply { mkdirs() }

        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        var testServer: P2PChunkServer? = null
        try {
            val sessionCode = "846291"
            val chunkBytes = ChunkSizeOption.CHUNK_256KB.bytes

            // Create 10 real video files with distinct binary payloads and precomputed SHA-256 hashes
            val tenVideoFiles = (1..10).map { idx ->
                val f = File(senderDir, String.format(Locale.US, "barq_video_%02d_4K.mp4", idx))
                val payload = ByteArray(180 * 1024 + idx * 4096) { b -> ((b * 31 + idx * 17) and 0xFF).toByte() }
                f.writeBytes(payload)
                val sha = Sha256Util.bytesToHex(
                    java.security.MessageDigest.getInstance("SHA-256").digest(payload)
                )
                TransferFileItem(
                    id = "vid_$idx",
                    name = f.name,
                    sizeBytes = f.length(),
                    category = FileCategory.VIDEO,
                    uri = android.net.Uri.fromFile(f),
                    localFile = f,
                    totalChunks = maxOf(1, ((f.length() + chunkBytes - 1) / chunkBytes).toInt()),
                    sha256Expected = sha
                )
            }

            val currentServerQueue = java.util.concurrent.CopyOnWriteArrayList<TransferFileItem>(tenVideoFiles)
            val senderSyncedStates = java.util.concurrent.ConcurrentHashMap<String, FileTransferStatus>()
            val senderStatesHistory = java.util.concurrent.ConcurrentHashMap<String, MutableList<FileTransferStatus>>()

            testServer = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { sessionCode },
                isSenderReadyProvider = { true },
                requireReceiverApprovalProvider = { false },
                chunkSizeProvider = { ChunkSizeOption.CHUNK_256KB },
                filesProvider = { currentServerQueue },
                onChunkServed = { _, _, _ -> },
                onReceiverFileStateSynced = { fileId, status, _, _, _ ->
                    senderSyncedStates[fileId] = status
                    senderStatesHistory.getOrPut(fileId) { java.util.Collections.synchronizedList(mutableListOf()) }.add(status)
                }
            )
            val serverPort = testServer.startServer(preferredPort = 0)
            assertTrue("Test P2PChunkServer must bind a valid port", serverPort > 0)

            // =========================================================================
            // 1. Verify Sending 10 Videos with All 10 Succeeding + SHA-256 Verification
            // =========================================================================
            val receiverItems10 = java.util.concurrent.CopyOnWriteArrayList(
                tenVideoFiles.map { it.copy(status = FileTransferStatus.WAITING) }
            )
            assertTrue(
                "WAITING and QUEUED must both be recognized as waiting/queued states",
                FileTransferStatus.WAITING.isWaitingOrQueued && FileTransferStatus.QUEUED.isWaitingOrQueued
            )

            val anyFailed10 = P2PTransferViewModel.executeHighSpeedReceiveSession(
                hostIp = "127.0.0.1",
                hostPort = serverPort,
                sessionCode = sessionCode,
                chunkSizeBytes = chunkBytes,
                downloadDir = receiverDir10Success,
                itemsProvider = { receiverItems10 },
                isPausedProvider = { false },
                onFileUpdated = { fileId, _, _, transform ->
                    val idx = receiverItems10.indexOfFirst { it.id == fileId }
                    if (idx >= 0) receiverItems10[idx] = transform(receiverItems10[idx])
                },
                onFileCompleted = { _, _ -> },
                onFileFailed = { _, _ -> }
            )
            assertFalse("All 10 videos must succeed with zero failures", anyFailed10)
            assertEquals(
                "All 10 videos must reach COMPLETED status on Receiver",
                10,
                receiverItems10.count { it.status == FileTransferStatus.COMPLETED && it.sha256Verified }
            )
            for (item in receiverItems10) {
                val savedFile = File(item.savedPath.orEmpty())
                assertTrue("Saved video ${item.name} must exist on disk", savedFile.exists())
                assertEquals("Saved video ${item.name} size must match source", item.sizeBytes, savedFile.length())
                assertEquals("Sender must sync COMPLETED status for ${item.id}", FileTransferStatus.COMPLETED, senderSyncedStates[item.id])
            }

            // =========================================================================
            // 2 & 3. Verify 1 Video Failing (Lost Source Permission) While Remaining 9 Continue & Succeed
            // =========================================================================
            val video4File = tenVideoFiles[3].localFile!!
            video4File.setReadable(false, false)
            assertFalse(
                "isFileReadableWithPermissions must detect revoked POSIX read permission",
                P2PChunkServer.isFileReadableWithPermissions(video4File)
            )

            val receiverItemsPartial = java.util.concurrent.CopyOnWriteArrayList(
                tenVideoFiles.map { it.copy(status = FileTransferStatus.QUEUED, transferredBytes = 0L, completedChunks = 0) }
            )
            val anyFailedPartial = P2PTransferViewModel.executeHighSpeedReceiveSession(
                hostIp = "127.0.0.1",
                hostPort = serverPort,
                sessionCode = sessionCode,
                chunkSizeBytes = chunkBytes,
                downloadDir = receiverDirPartialFail,
                itemsProvider = { receiverItemsPartial },
                isPausedProvider = { false },
                onFileUpdated = { fileId, _, _, transform ->
                    val idx = receiverItemsPartial.indexOfFirst { it.id == fileId }
                    if (idx >= 0) receiverItemsPartial[idx] = transform(receiverItemsPartial[idx])
                },
                onFileCompleted = { _, _ -> },
                onFileFailed = { _, _ -> }
            )
            assertTrue("Session must report anyFailed = true when video #4 fails", anyFailedPartial)

            val failedVideo4 = receiverItemsPartial.first { it.id == "vid_4" }
            val otherNineVideos = receiverItemsPartial.filter { it.id != "vid_4" }
            assertEquals(
                "Video #4 must have status FAILED (never CANCELLED when permission fails)",
                FileTransferStatus.FAILED,
                failedVideo4.status
            )
            assertEquals(
                "Video #4 diagnostic code must be SOURCE_PERMISSION_LOST",
                "SOURCE_PERMISSION_LOST",
                failedVideo4.failureDiagnosticCode
            )
            assertTrue(
                "Video #4 error message must instruct user to re-select the file on Sender",
                failedVideo4.errorMessage.orEmpty().contains("فُقدت صلاحية قراءة الملف لدى المرسِل")
            )
            assertEquals(
                "Sender must also sync FAILED status for video #4",
                FileTransferStatus.FAILED,
                senderSyncedStates["vid_4"]
            )
            assertEquals(
                "All other 9 videos must continue and complete despite video #4 failing",
                9,
                otherNineVideos.count { it.status == FileTransferStatus.COMPLETED && it.sha256Verified }
            )

            // =========================================================================
            // 6. Verify Retrying Only the Failed Video Without Re-transferring Completed Videos
            // =========================================================================
            video4File.setReadable(true, false)
            assertTrue(
                "isFileReadableWithPermissions must be true after restoring read permission",
                P2PChunkServer.isFileReadableWithPermissions(video4File)
            )
            val completedTimestampsBeforeRetry = otherNineVideos.associate { it.id to File(it.savedPath.orEmpty()).lastModified() }

            // Reset ONLY failed vid_4 to QUEUED (simulating retrySingleFailedFile("vid_4"))
            val idx4 = receiverItemsPartial.indexOfFirst { it.id == "vid_4" }
            receiverItemsPartial[idx4] = receiverItemsPartial[idx4].copy(
                status = FileTransferStatus.QUEUED,
                retryCount = receiverItemsPartial[idx4].retryCount + 1,
                errorMessage = null,
                failureDiagnosticCode = null
            )

            val anyFailedAfterRetry = P2PTransferViewModel.executeHighSpeedReceiveSession(
                hostIp = "127.0.0.1",
                hostPort = serverPort,
                sessionCode = sessionCode,
                chunkSizeBytes = chunkBytes,
                downloadDir = receiverDirPartialFail,
                itemsProvider = { receiverItemsPartial },
                isPausedProvider = { false },
                onFileUpdated = { fileId, _, _, transform ->
                    val idx = receiverItemsPartial.indexOfFirst { it.id == fileId }
                    if (idx >= 0) receiverItemsPartial[idx] = transform(receiverItemsPartial[idx])
                },
                onFileCompleted = { _, _ -> },
                onFileFailed = { _, _ -> }
            )
            assertFalse("Retrying video #4 must succeed with zero failures", anyFailedAfterRetry)
            assertEquals(
                "All 10 videos must now be COMPLETED",
                10,
                receiverItemsPartial.count { it.status == FileTransferStatus.COMPLETED && it.sha256Verified }
            )
            for ((completedId, prevModTime) in completedTimestampsBeforeRetry) {
                val itemAfter = receiverItemsPartial.first { it.id == completedId }
                assertEquals(
                    "Already-completed video $completedId must not be overwritten or re-downloaded during retry",
                    prevModTime,
                    File(itemAfter.savedPath.orEmpty()).lastModified()
                )
            }

            // =========================================================================
            // 4. Verify Loss of Destination Save Folder Permission During Transfer
            // =========================================================================
            receiverDirReadOnly.setWritable(false, false)
            assertFalse(
                "isDirectoryWritableWithPermissions must detect revoked write permission on destination folder",
                P2PTransferViewModel.isDirectoryWritableWithPermissions(receiverDirReadOnly)
            )
            val destFailItems = java.util.concurrent.CopyOnWriteArrayList(
                listOf(tenVideoFiles[0].copy(id = "vid_dest_perm", status = FileTransferStatus.QUEUED))
            )
            currentServerQueue.add(destFailItems[0])
            val destFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                hostIp = "127.0.0.1",
                hostPort = serverPort,
                sessionCode = sessionCode,
                chunkSizeBytes = chunkBytes,
                downloadDir = receiverDirReadOnly,
                itemsProvider = { destFailItems },
                isPausedProvider = { false },
                onFileUpdated = { fileId, _, _, transform ->
                    val idx = destFailItems.indexOfFirst { it.id == fileId }
                    if (idx >= 0) destFailItems[idx] = transform(destFailItems[idx])
                },
                onFileCompleted = { _, _ -> },
                onFileFailed = { _, _ -> }
            )
            receiverDirReadOnly.setWritable(true, false)
            assertTrue("Transfer to non-writable destination folder must fail gracefully", destFailed)
            assertEquals(
                "Destination folder permission loss must mark file as FAILED (not CANCELLED)",
                FileTransferStatus.FAILED,
                destFailItems[0].status
            )
            assertEquals(
                "Diagnostic code must be DEST_PERMISSION_LOST",
                "DEST_PERMISSION_LOST",
                destFailItems[0].failureDiagnosticCode
            )
            assertTrue(
                "Error message must instruct user to re-select save folder when necessary",
                destFailItems[0].errorMessage.orEmpty().contains("فُقدت صلاحية الكتابة في مجلد الحفظ")
            )

            // =========================================================================
            // 5 & 8. Verify Network Interruption + .part Resume + Post-Resume SHA-256 Integrity
            // =========================================================================
            val sourceResumeItem = tenVideoFiles[1].copy(id = "vid_resume_part", status = FileTransferStatus.QUEUED)
            currentServerQueue.add(sourceResumeItem)
            val fullSourceBytes = sourceResumeItem.localFile!!.readBytes()
            val halfBytesCount = fullSourceBytes.size / 2
            val partFileOnDisk = File(receiverDirResume, "${sourceResumeItem.name}.vid_resume_part.part")
            partFileOnDisk.writeBytes(fullSourceBytes.copyOfRange(0, halfBytesCount))
            assertEquals("Pre-existing .part file must have 50% of bytes", halfBytesCount.toLong(), partFileOnDisk.length())

            val resumeItems = java.util.concurrent.CopyOnWriteArrayList(listOf(sourceResumeItem))
            val resumeFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                hostIp = "127.0.0.1",
                hostPort = serverPort,
                sessionCode = sessionCode,
                chunkSizeBytes = chunkBytes,
                downloadDir = receiverDirResume,
                itemsProvider = { resumeItems },
                isPausedProvider = { false },
                onFileUpdated = { fileId, _, _, transform ->
                    val idx = resumeItems.indexOfFirst { it.id == fileId }
                    if (idx >= 0) resumeItems[idx] = transform(resumeItems[idx])
                },
                onFileCompleted = { _, _ -> },
                onFileFailed = { _, _ -> }
            )
            assertFalse("Resumed transfer from .part must succeed", resumeFailed)
            val completedResumeItem = resumeItems[0]
            assertEquals(FileTransferStatus.COMPLETED, completedResumeItem.status)
            assertTrue("Resumed file must pass SHA-256 verification", completedResumeItem.sha256Verified)
            assertEquals(
                "Resumed file SHA-256 must match source SHA-256 exactly",
                sourceResumeItem.sha256Expected,
                completedResumeItem.sha256Actual
            )
            assertFalse(".part file must be cleaned up/renamed upon completion", partFileOnDisk.exists())
            val finalResumedFile = File(completedResumeItem.savedPath.orEmpty())
            assertTrue("Final resumed video file must exist", finalResumedFile.exists())
            assertTrue(
                "Final resumed video bytes must match source byte-for-byte",
                fullSourceBytes.contentEquals(finalResumedFile.readBytes())
            )

            // =========================================================================
            // 7. Verify No Duplicate Overwrites When Two Videos Have Identical Names
            // =========================================================================
            val dupItem1 = tenVideoFiles[0].copy(id = "dup_1", name = "duplicate_clip.mp4", status = FileTransferStatus.QUEUED)
            val dupItem2 = tenVideoFiles[2].copy(id = "dup_2", name = "duplicate_clip.mp4", status = FileTransferStatus.QUEUED)
            currentServerQueue.add(dupItem1)
            currentServerQueue.add(dupItem2)
            val dupList = java.util.concurrent.CopyOnWriteArrayList(listOf(dupItem1, dupItem2))
            val dupFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                hostIp = "127.0.0.1",
                hostPort = serverPort,
                sessionCode = sessionCode,
                chunkSizeBytes = chunkBytes,
                downloadDir = receiverDirDedup,
                itemsProvider = { dupList },
                isPausedProvider = { false },
                onFileUpdated = { fileId, _, _, transform ->
                    val idx = dupList.indexOfFirst { it.id == fileId }
                    if (idx >= 0) dupList[idx] = transform(dupList[idx])
                },
                onFileCompleted = { _, _ -> },
                onFileFailed = { _, _ -> }
            )
            assertFalse("Duplicate-named files must both succeed without overwriting", dupFailed)
            assertTrue(
                "Two files with the same name must be saved to distinct paths",
                dupList[0].savedPath != dupList[1].savedPath
            )
            assertEquals(dupItem1.sizeBytes, File(dupList[0].savedPath.orEmpty()).length())
            assertEquals(dupItem2.sizeBytes, File(dupList[1].savedPath.orEmpty()).length())

            // =========================================================================
            // 9. Verify Full State Synchronization Between Sender & Receiver
            //    (WAITING/QUEUED, TRANSFERRING, PAUSED, RETRYING, VERIFYING, COMPLETED, FAILED, CANCELLED)
            // =========================================================================
            for (expectedState in listOf(
                FileTransferStatus.TRANSFERRING,
                FileTransferStatus.PAUSED,
                FileTransferStatus.RETRYING,
                FileTransferStatus.VERIFYING,
                FileTransferStatus.FAILED,
                FileTransferStatus.CANCELLED,
                FileTransferStatus.COMPLETED
            )) {
                val ackUrl = URL(
                    "http://127.0.0.1:$serverPort/api/ack?fileId=vid_1&status=${expectedState.name}&verified=${expectedState == FileTransferStatus.COMPLETED}&bytes=4096&code=$sessionCode"
                )
                val conn = (ackUrl.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 2000
                    readTimeout = 2000
                }
                assertEquals(200, conn.responseCode)
                conn.disconnect()
                assertEquals(
                    "Sender must synchronize state $expectedState from Receiver",
                    expectedState,
                    senderSyncedStates["vid_1"]
                )
            }

            // =========================================================================
            // 10 & 11. Verify UI Layout: Filenames Never Wrap Character-by-Character Vertically
            //          and Smooth Scrolling Performance with Large File Lists (60 files)
            // =========================================================================
            val activityVm = androidx.lifecycle.ViewModelProvider(composeTestRule.activity)[P2PTransferViewModel::class.java]
            val uiTempDir = File(tempRoot, "ui_large_files").apply { mkdirs() }
            val uiUris = (1..60).map { i ->
                val fileName = if (i % 2 == 0) {
                    "فيديو_عائلي_طويل_جدا_بدقة_عالية_2026_Barq_P2P_Transfer_Clip_$i.mp4"
                } else {
                    "Barq_Sher_Ultra_HD_4K_60FPS_Long_Recording_Session_Video_$i.mp4"
                }
                val f = File(uiTempDir, fileName).apply { writeBytes(ByteArray(1024) { (i and 0xFF).toByte() }) }
                android.net.Uri.fromFile(f)
            }

            composeTestRule.runOnUiThread {
                activityVm.clearAllFiles()
                activityVm.addPickedUris(uiUris)
            }
            composeTestRule.waitForIdle()

            val addedFiles = activityVm.uiState.value.files
            assertEquals("All 60 files must be added to the transfer queue", 60, addedFiles.size)
            val firstId = addedFiles.first().id
            val secondId = addedFiles[1].id
            val lastId = addedFiles.last().id

            composeTestRule.runOnUiThread {
                activityVm.onReceiverSyncedFileStatus(
                    fileId = firstId,
                    status = FileTransferStatus.FAILED,
                    verified = false,
                    transferredBytes = 512L,
                    errorMessage = "فُقدت صلاحية قراءة الملف لدى المرسِل — يرجى إعادة تحديد الملف"
                )
                activityVm.onReceiverSyncedFileStatus(
                    fileId = secondId,
                    status = FileTransferStatus.RETRYING,
                    verified = false,
                    transferredBytes = 256L,
                    errorMessage = "جاري إعادة المحاولة تلقائياً (1/5)..."
                )
                activityVm.navigateTo(com.example.model.AppScreen.LIVE_TRANSFER)
            }
            composeTestRule.waitForIdle()

            // Verify telemetry card and LazyColumn exist
            composeTestRule.onNodeWithTag("live_speed_telemetry_card").assertExists()
            composeTestRule.onNodeWithTag("live_files_lazy_column").assertExists()

            // Check that the filename node of the first item has a wide horizontal width (> 140.dp)
            // and a single-line height (< 40.dp), proving it NEVER wraps vertically character-by-character!
            val nameNode1 = composeTestRule.onNodeWithTag("live_file_name_$firstId").fetchSemanticsNode()
            val density = composeTestRule.density.density
            val nameWidthDp = maxOf(nameNode1.size.width / density, nameNode1.boundsInRoot.width / density)
            val nameHeightDp = maxOf(nameNode1.size.height / density, nameNode1.boundsInRoot.height / density)
            assertTrue(
                "Filename Text must utilize wide horizontal space (actual width=${nameWidthDp}dp, height=${nameHeightDp}dp) and never wrap character-by-character",
                nameWidthDp > 140f && nameHeightDp in 8f..40f
            )

            // Verify per-file Retry button is shown on the failed file card and resets it to QUEUED when clicked
            val retryButtonNode = composeTestRule.onNodeWithTag("retry_single_file_$firstId").assertExists().fetchSemanticsNode()
            composeTestRule.runOnIdle {
                retryButtonNode.config[androidx.compose.ui.semantics.SemanticsActions.OnClick].action?.invoke()
            }
            composeTestRule.waitForIdle()
            val retriedFirst = activityVm.uiState.value.files.first { it.id == firstId }
            assertEquals("Clicking retry button on failed file must reset status to QUEUED", FileTransferStatus.QUEUED, retriedFirst.status)
            assertTrue("Clicking retry button must increment retryCount", retriedFirst.retryCount >= 1)

            // Scroll smoothly to the bottom of the 60-item LazyColumn to verify zero lag or crash
            org.robolectric.shadows.ShadowTrace.reset()
            composeTestRule.onNodeWithTag("live_files_lazy_column")
                .performScrollToIndex(addedFiles.lastIndex)
            composeTestRule.waitForIdle()
            composeTestRule.onNodeWithTag("live_file_card_$lastId").assertExists()
            Unit
        } finally {
            runCatching { receiverDirReadOnly.setWritable(true, false) }
            tenVideoFilesCleanup(senderDir)
            runCatching { testServer?.stopServer() }
            runCatching { serverScope.cancel() }
            runCatching { tempRoot.deleteRecursively() }
            P2PTransferViewModel.resetRetainedEngineForTests()
        }
    }

    private fun tenVideoFilesCleanup(dir: File) {
        runCatching {
            dir.listFiles()?.forEach { it.setReadable(true, false); it.setWritable(true, false) }
        }
    }

    @Test
    fun testPhase7RealDevice3FixesVerification(): Unit = runBlocking {
        P2PTransferViewModel.resetRetainedEngineForTests()
        com.example.data.DeviceMediaRepository.clearFolderStatsCache()
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempRoot = java.nio.file.Files.createTempDirectory("barq_phase7_3fixes_test").toFile()
        val senderDir = File(tempRoot, "sender").apply { mkdirs() }
        val receiverDir = File(tempRoot, "receiver").apply { mkdirs() }
        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        var testServer: P2PChunkServer? = null

        fun sha256OfBytes(bytes: ByteArray): String =
            Sha256Util.bytesToHex(java.security.MessageDigest.getInstance("SHA-256").digest(bytes))

        try {
            // =========================================================================
            // ISSUE 1: Two videos with identical name ("24 END.mp4") and different sizes
            //          + .part resume stability for deduplicated filenames
            // =========================================================================
            val subA = File(senderDir, "camA").apply { mkdirs() }
            val subB = File(senderDir, "camB").apply { mkdirs() }
            val bytesA = ByteArray(180_000) { idx -> ((idx * 17 + 3) and 0xFF).toByte() }
            val bytesB = ByteArray(290_000) { idx -> ((idx * 29 + 11) and 0xFF).toByte() }
            val fileEndA = File(subA, "24 END.mp4").apply { writeBytes(bytesA) }
            val fileEndB = File(subB, "24 END.mp4").apply { writeBytes(bytesB) }

            val chunkBytes = ChunkSizeOption.CHUNK_256KB.bytes
            val itemEndA = TransferFileItem(
                id = "dup_end_1",
                name = "24 END.mp4",
                sizeBytes = bytesA.size.toLong(),
                category = FileCategory.VIDEO,
                localFile = fileEndA,
                totalChunks = com.example.model.computeTotalChunksForSize(bytesA.size.toLong(), chunkBytes),
                sha256Expected = sha256OfBytes(bytesA)
            )
            val itemEndB = TransferFileItem(
                id = "dup_end_2",
                name = "24 END.mp4",
                sizeBytes = bytesB.size.toLong(),
                category = FileCategory.VIDEO,
                localFile = fileEndB,
                totalChunks = com.example.model.computeTotalChunksForSize(bytesB.size.toLong(), chunkBytes),
                sha256Expected = sha256OfBytes(bytesB)
            )

            // Pre-complete itemEndA on disk ("24 END.mp4") and create a 50% .part file for itemEndB ("24 END_1.mp4.dup_end_2.part")
            val preSavedEndA = File(receiverDir, "24 END.mp4").apply { writeBytes(bytesA) }
            val halfB = bytesB.size / 2
            val partEndB = File(receiverDir, "24 END_1.mp4.dup_end_2.part").apply {
                writeBytes(bytesB.copyOfRange(0, halfB))
            }
            assertTrue(preSavedEndA.exists())
            assertEquals(halfB.toLong(), partEndB.length())

            val sessionCode = "BRQ-7777"
            val serverQueue = java.util.concurrent.CopyOnWriteArrayList(listOf(itemEndA, itemEndB))
            testServer = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { sessionCode },
                sessionIdProvider = { "SES-P7" },
                sessionExpiresAtProvider = { System.currentTimeMillis() + 600_000L },
                isSenderReadyProvider = { true },
                requireReceiverApprovalProvider = { false },
                chunkSizeProvider = { ChunkSizeOption.CHUNK_256KB },
                filesProvider = { serverQueue },
                onChunkServed = { _, _, _ -> },
                onPeerDiscovered = {}
            )
            val port = testServer.startServer(preferredPort = 0)

            val receiverList = java.util.concurrent.CopyOnWriteArrayList(
                listOf(
                    itemEndA.copy(
                        status = FileTransferStatus.COMPLETED,
                        completedChunks = itemEndA.totalChunks,
                        transferredBytes = itemEndA.sizeBytes,
                        savedPath = preSavedEndA.absolutePath,
                        sha256Actual = itemEndA.sha256Expected,
                        sha256Verified = true
                    ),
                    itemEndB.copy(status = FileTransferStatus.QUEUED)
                )
            )

            val anyFailedDup = P2PTransferViewModel.executeHighSpeedReceiveSession(
                hostIp = "127.0.0.1",
                hostPort = port,
                sessionCode = sessionCode,
                chunkSizeBytes = chunkBytes,
                downloadDir = receiverDir,
                itemsProvider = { receiverList },
                isPausedProvider = { false },
                onFileUpdated = { fileId, _, _, transform ->
                    val idx = receiverList.indexOfFirst { it.id == fileId }
                    if (idx >= 0) receiverList[idx] = transform(receiverList[idx])
                },
                onFileCompleted = { _, _ -> },
                onFileFailed = { _, _ -> }
            )
            assertFalse("Second '24 END.mp4' must resume from its .part file and complete without failing", anyFailedDup)
            val completedEndB = receiverList.first { it.id == "dup_end_2" }
            assertEquals(FileTransferStatus.COMPLETED, completedEndB.status)
            assertTrue(completedEndB.sha256Verified)
            assertEquals("Second '24 END.mp4' must reuse '24 END_1.mp4' target path", File(receiverDir, "24 END_1.mp4").absolutePath, completedEndB.savedPath)
            assertEquals(bytesB.size.toLong(), File(completedEndB.savedPath.orEmpty()).length())
            assertFalse("Part file for dup_end_2 must be renamed on completion", partEndB.exists())

            // =========================================================================
            // ISSUE 2: Lazy Folder Stats Calculation, Caching, and Cap Indicator
            // =========================================================================
            val statsRootDir = File(tempRoot, "mod_folder_test").apply { mkdirs() }
            val subMod1 = File(statsRootDir, "textures").apply { mkdirs() }
            File(statsRootDir, "empty_sub").apply { mkdirs() }
            for (i in 1..15) {
                File(subMod1, "tex_$i.tga").writeBytes(ByteArray(1000 * i) { 0x2A })
            }
            val expectedModBytes = (1..15).sumOf { 1000L * it }

            val uncalculatedFolder = com.example.model.StorageFolderItem(
                name = "mod_folder_test",
                path = statsRootDir.absolutePath,
                relativeDisplayPath = "Download/mod_folder_test",
                fileCount = 0,
                subfolderCount = 0,
                totalBytes = 0L,
                lastModifiedMillis = statsRootDir.lastModified(),
                statsStatus = com.example.model.FolderStatsStatus.CALCULATING
            )
            val computedFull = com.example.data.DeviceMediaRepository.computeFolderStatsLazy(
                folder = uncalculatedFolder,
                maxFilesCap = 5000
            )
            assertEquals(com.example.model.FolderStatsStatus.COMPLETED, computedFull.statsStatus)
            assertEquals(15, computedFull.fileCount)
            assertEquals(2, computedFull.subfolderCount)
            assertEquals(1, computedFull.emptySubfolderCount)
            assertEquals(expectedModBytes, computedFull.totalBytes)

            // Verify capped approximate status when maxFilesCap is smaller than total files
            com.example.data.DeviceMediaRepository.clearFolderStatsCache()
            val computedCapped = com.example.data.DeviceMediaRepository.computeFolderStatsLazy(
                folder = uncalculatedFolder,
                maxFilesCap = 5
            )
            assertEquals(com.example.model.FolderStatsStatus.APPROXIMATE_CAPPED, computedCapped.statsStatus)
            assertEquals(5, computedCapped.fileCount)
            assertTrue(computedCapped.totalBytes > 0L)

            // =========================================================================
            // ISSUE 3: Unreadable Folder Handling + .tga File vs Folder Classification & Sorting
            // =========================================================================
            val unreadableRoot = File(tempRoot, "unreadable_mod_dir").apply { mkdirs() }
            File(unreadableRoot, "secret.dat").writeBytes(ByteArray(512) { 1 })
            unreadableRoot.setReadable(false, false)
            val unreadableScan = com.example.data.DeviceMediaRepository.scanLocalFolderForTransfer(unreadableRoot, chunkBytes)
            unreadableRoot.setReadable(true, false)
            assertTrue("Unreadable root folder must return an explicit errorMessage", !unreadableScan.errorMessage.isNullOrBlank())
            assertEquals("Unreadable root folder must NOT produce an empty folder transfer item", 0, unreadableScan.transferItems.size)

            // Verify folder containing .tga files ("2v6 abadoned hope.tga", "thermopylae v5.tga"),
            // a readable subfolder, an empty subfolder, and an unreadable subfolder
            val mixedModDir = File(tempRoot, "maps_pack").apply { mkdirs() }
            val tga1Bytes = "TGA_DATA_ABANDONED_HOPE".toByteArray()
            val tga2Bytes = "TGA_DATA_THERMOPYLAE_V5_CONTENT".toByteArray()
            File(mixedModDir, "2v6 abadoned hope.tga").apply { writeBytes(tga1Bytes) }
            File(mixedModDir, "thermopylae v5.tga").apply { writeBytes(tga2Bytes) }
            val zFolder = File(mixedModDir, "z_sub_maps").apply { mkdirs() }
            File(zFolder, "sub_map.ini").writeBytes("INI=1".toByteArray())
            File(mixedModDir, "a_empty_dir").apply { mkdirs() }
            val lockedSub = File(mixedModDir, "locked_sub").apply {
                mkdirs()
                File(this, "hidden.bin").writeBytes(ByteArray(64))
                setReadable(false, false)
            }

            val mixedScan = com.example.data.DeviceMediaRepository.scanLocalFolderForTransfer(mixedModDir, chunkBytes)
            lockedSub.setReadable(true, false)

            assertEquals("Scan of readable folder must succeed", null, mixedScan.errorMessage)
            val scannedItems = mixedScan.transferItems
            // Verify locked_sub was NOT added as an empty directory!
            assertFalse(
                "Unreadable subfolder must never be added as an empty directory item",
                scannedItems.any { it.name == "locked_sub" && it.isDirectory }
            )
            // Verify genuinely empty subfolder WAS added as an empty directory
            assertTrue(
                "Genuinely empty subfolder must be preserved as isDirectory = true",
                scannedItems.any { it.name == "a_empty_dir" && it.isDirectory }
            )
            // Verify .tga files are classified strictly as files (isDirectory = false)
            val scannedTga1 = scannedItems.first { it.name == "2v6 abadoned hope.tga" }
            val scannedTga2 = scannedItems.first { it.name == "thermopylae v5.tga" }
            assertFalse("2v6 abadoned hope.tga must have isDirectory = false", scannedTga1.isDirectory)
            assertFalse("thermopylae v5.tga must have isDirectory = false", scannedTga2.isDirectory)
            assertEquals(tga1Bytes.size.toLong(), scannedTga1.sizeBytes)
            assertEquals(tga2Bytes.size.toLong(), scannedTga2.sizeBytes)

            // Verify folders are traversed/ordered before top-level files
            val firstSubfolderIdx = scannedItems.indexOfFirst { it.relativePath.contains("a_empty_dir") || it.relativePath.contains("z_sub_maps") }
            val firstRootTgaIdx = scannedItems.indexOfFirst { it.name == "2v6 abadoned hope.tga" }
            assertTrue("Subfolders must be ordered before root-level files", firstSubfolderIdx in 0 until firstRootTgaIdx)

            // Verify receiving the scanned folder creates real files (NOT folders) for .tga items
            val receiverModDir = File(tempRoot, "receiver_mods").apply { mkdirs() }
            val preparedModItems = scannedItems.map { item ->
                if (item.isDirectory) item
                else item.copy(sha256Expected = sha256OfBytes(item.localFile!!.readBytes()))
            }
            serverQueue.clear()
            serverQueue.addAll(preparedModItems)
            val modReceiveList = java.util.concurrent.CopyOnWriteArrayList(preparedModItems)

            val modReceiveFailed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                hostIp = "127.0.0.1",
                hostPort = port,
                sessionCode = sessionCode,
                chunkSizeBytes = chunkBytes,
                downloadDir = receiverModDir,
                itemsProvider = { modReceiveList },
                isPausedProvider = { false },
                onFileUpdated = { fileId, _, _, transform ->
                    val idx = modReceiveList.indexOfFirst { it.id == fileId }
                    if (idx >= 0) modReceiveList[idx] = transform(modReceiveList[idx])
                },
                onFileCompleted = { _, _ -> },
                onFileFailed = { _, _ -> }
            )
            assertFalse("Receiving maps_pack folder with .tga files must succeed", modReceiveFailed)
            val receivedTga1 = File(receiverModDir, "maps_pack/2v6 abadoned hope.tga")
            val receivedTga2 = File(receiverModDir, "maps_pack/thermopylae v5.tga")
            assertTrue("Received 2v6 abadoned hope.tga must be a regular file (isFile)", receivedTga1.isFile && !receivedTga1.isDirectory)
            assertTrue("Received thermopylae v5.tga must be a regular file (isFile)", receivedTga2.isFile && !receivedTga2.isDirectory)
            assertEquals(tga1Bytes.size.toLong(), receivedTga1.length())
            assertEquals(tga2Bytes.size.toLong(), receivedTga2.length())
        } finally {
            runCatching { testServer?.stopServer() }
            runCatching { serverScope.cancel() }
            runCatching {
                tempRoot.walkTopDown().forEach { it.setReadable(true, false); it.setWritable(true, false) }
                tempRoot.deleteRecursively()
            }
            com.example.data.DeviceMediaRepository.clearFolderStatsCache()
            P2PTransferViewModel.resetRetainedEngineForTests()
        }
    }

    @Test
    fun verifyAutomaticFileManagerDiscoveryRecursiveBrowsingAllFileTypesAndRestrictedStatus() {
        com.example.data.DeviceMediaRepository.clearFolderStatsCache()
        val tempRoot = java.nio.file.Files.createTempDirectory("barq_auto_fm_test").toFile()
        try {
            // Create a multi-level folder structure under Download/ropon_auto with .BIG, .DAT, .TGA, and extensionless files
            val roponDir = File(tempRoot, "Download/ropon_auto").apply { mkdirs() }
            val subLevel1 = File(roponDir, "Data").apply { mkdirs() }
            val subLevel2 = File(subLevel1, "INI").apply { mkdirs() }
            val subLevel3 = File(subLevel2, "Maps").apply { mkdirs() }
            val emptyReadableSub = File(roponDir, "EmptySub").apply { mkdirs() }
            val unreadableSub = File(roponDir, "LockedSub").apply { mkdirs() }

            val bigFile = File(roponDir, "Textures.BIG").apply {
                writeBytes(ByteArray(32_768) { (it * 3).toByte() })
            }
            val datFile = File(subLevel1, "GameEngine.DAT").apply {
                writeBytes(ByteArray(16_384) { (it * 5).toByte() })
            }
            val tgaFile = File(subLevel3, "desert_preview.TGA").apply {
                writeBytes(ByteArray(8_192) { (it * 7).toByte() })
            }
            val noExtFile = File(subLevel2, "README_MOD_INFO").apply {
                writeBytes(ByteArray(4_096) { (it * 11).toByte() })
            }
            // Secret file inside LockedSub before locking it
            File(unreadableSub, "hidden.dat").writeBytes(ByteArray(1024) { 1 })
            unreadableSub.setReadable(false, false)

            // Register Download as a known root folder in the internal file manager
            val downloadFolderItem = com.example.model.StorageFolderItem(
                name = "Download",
                path = File(tempRoot, "Download").absolutePath,
                relativeDisplayPath = "Download",
                parentFolderName = "",
                fileCount = 0,
                subfolderCount = 0,
                totalBytes = 0L,
                lastModifiedMillis = System.currentTimeMillis(),
                statsStatus = com.example.model.FolderStatsStatus.CALCULATING
            )

            // 1. Browse "Download" automatically without SAF
            val (dlFolders, _) = com.example.data.DeviceMediaRepository.browseLocalDirectoryChildren(
                browsingRelOrAbsPath = "Download",
                allKnownFolders = listOf(downloadFolderItem),
                allKnownFiles = emptyList()
            )
            val discoveredRopon = dlFolders.firstOrNull { it.name == "ropon_auto" }
            assertNotNull("ropon_auto must be automatically discovered inside Download without SAF", discoveredRopon)

            // 2. Compute true folder size of ropon_auto (must sum .BIG + .DAT + .TGA + extensionless file across all nested subfolders)
            val computedRopon = com.example.data.DeviceMediaRepository.computeFolderStatsLazy(
                folder = discoveredRopon!!,
                maxFilesCap = 25000
            )
            val expectedTotalBytes = bigFile.length() + datFile.length() + tgaFile.length() + noExtFile.length()
            assertEquals("True folder size must equal sum of all readable files across all nested subfolders", expectedTotalBytes, computedRopon.totalBytes)
            assertEquals("True file count must include .BIG, .DAT, .TGA, and extensionless files", 4, computedRopon.fileCount)
            assertTrue(
                "Folder with readable files and one locked subfolder should be PARTIALLY_READ or COMPLETED",
                computedRopon.statsStatus == com.example.model.FolderStatsStatus.PARTIALLY_READ ||
                    computedRopon.statsStatus == com.example.model.FolderStatsStatus.COMPLETED
            )

            // 3. Recursively browse into Download/ropon_auto -> Data -> INI -> Maps (3 levels deep)
            val (roponSubfolders, roponFiles) = com.example.data.DeviceMediaRepository.browseLocalDirectoryChildren(
                browsingRelOrAbsPath = "Download/ropon_auto",
                allKnownFolders = listOf(downloadFolderItem),
                allKnownFiles = emptyList()
            )
            assertTrue("Must list Textures.BIG at Download/ropon_auto", roponFiles.any { it.name == "Textures.BIG" && it.fileExtensionBadge == "BIG" })

            // Verify LockedSub is marked ACCESS_RESTRICTED (never COMPLETED with 0 files / "مجلد فارغ")
            val lockedItem = roponSubfolders.first { it.name == "LockedSub" }
            assertEquals(
                "Unreadable folder must have status ACCESS_RESTRICTED so it is never shown as empty",
                com.example.model.FolderStatsStatus.ACCESS_RESTRICTED,
                lockedItem.statsStatus
            )
            val computedLocked = com.example.data.DeviceMediaRepository.computeFolderStatsLazy(lockedItem)
            assertEquals(
                "computeFolderStatsLazy on unreadable folder must return ACCESS_RESTRICTED",
                com.example.model.FolderStatsStatus.ACCESS_RESTRICTED,
                computedLocked.statsStatus
            )

            // Verify EmptySub is genuinely empty and marked COMPLETED with 0 files
            val emptyItem = roponSubfolders.first { it.name == "EmptySub" }
            val computedEmpty = com.example.data.DeviceMediaRepository.computeFolderStatsLazy(emptyItem)
            assertEquals(com.example.model.FolderStatsStatus.COMPLETED, computedEmpty.statsStatus)
            assertEquals(0, computedEmpty.fileCount)

            // Browse level 1: Download/ropon_auto/Data
            val (dataSubfolders, dataFiles) = com.example.data.DeviceMediaRepository.browseLocalDirectoryChildren(
                browsingRelOrAbsPath = "Download/ropon_auto/Data",
                allKnownFolders = listOf(downloadFolderItem),
                allKnownFiles = emptyList()
            )
            assertEquals(1, dataSubfolders.size)
            assertEquals("INI", dataSubfolders.first().name)
            assertTrue("Must read GameEngine.DAT in Data subfolder", dataFiles.any { it.name == "GameEngine.DAT" && it.fileExtensionBadge == "DAT" })

            // Browse level 2: Download/ropon_auto/Data/INI (contains extensionless file README_MOD_INFO)
            val (iniSubfolders, iniFiles) = com.example.data.DeviceMediaRepository.browseLocalDirectoryChildren(
                browsingRelOrAbsPath = "Download/ropon_auto/Data/INI",
                allKnownFolders = listOf(downloadFolderItem),
                allKnownFiles = emptyList()
            )
            assertEquals("Maps", iniSubfolders.first().name)
            val readmeFound = iniFiles.firstOrNull { it.name == "README_MOD_INFO" }
            assertNotNull("Extensionless file README_MOD_INFO must be read and displayed", readmeFound)
            assertEquals("Extensionless file badge must be FILE", "FILE", readmeFound!!.fileExtensionBadge)
            assertEquals(noExtFile.length(), readmeFound.sizeBytes)

            // Browse level 3: Download/ropon_auto/Data/INI/Maps (contains desert_preview.TGA)
            val (mapsSubfolders, mapsFiles) = com.example.data.DeviceMediaRepository.browseLocalDirectoryChildren(
                browsingRelOrAbsPath = "Download/ropon_auto/Data/INI/Maps",
                allKnownFolders = listOf(downloadFolderItem),
                allKnownFiles = emptyList()
            )
            assertTrue(mapsSubfolders.isEmpty())
            val tgaFound = mapsFiles.firstOrNull { it.name == "desert_preview.TGA" }
            assertNotNull("desert_preview.TGA must be read at depth 3", tgaFound)
            assertEquals("TGA", tgaFound!!.fileExtensionBadge)
            assertEquals(tgaFile.length(), tgaFound.sizeBytes)
        } finally {
            runCatching {
                tempRoot.walkTopDown().forEach { it.setReadable(true, false); it.setWritable(true, false) }
                tempRoot.deleteRecursively()
            }
            com.example.data.DeviceMediaRepository.clearFolderStatsCache()
        }
    }

    @Test
    fun verifyAll12FileManagerScenariosModFilesArchivesIndexNestedThousandsAndSelection() {
        com.example.data.DeviceMediaRepository.clearFolderStatsCache()
        val tempRoot = java.nio.file.Files.createTempDirectory("barq_12_scenarios_fm").toFile()
        try {
            val downloadDir = File(tempRoot, "Download").apply { mkdirs() }
            val modRoot = File(downloadDir, "GeneralsModPack").apply { mkdirs() }

            // Scenario 2, 3, 4, 5: Mod folder with .BIG, .DAT, .TGA, .ZIP, .RAR, Index, extensionless files, and multi-level subfolders
            val l1 = File(modRoot, "Art").apply { mkdirs() }
            val l2 = File(l1, "Textures").apply { mkdirs() }
            val l3 = File(l2, "Terrain").apply { mkdirs() }
            val l4 = File(l3, "HighRes").apply { mkdirs() }
            val emptyFolder = File(modRoot, "TrulyEmptyFolder").apply { mkdirs() }
            val lockedFolder = File(modRoot, "RestrictedSystemSub").apply {
                mkdirs()
                File(this, "secret.bin").writeBytes(ByteArray(512))
                setReadable(false, false)
            }

            val fBig = File(modRoot, "Window.BIG").apply { writeBytes(ByteArray(12_000) { 1 }) }
            val fDat = File(l1, "WorldBuilder.DAT").apply { writeBytes(ByteArray(8_000) { 2 }) }
            val fTga = File(l4, "WaterRipple.TGA").apply { writeBytes(ByteArray(6_000) { 3 }) }
            val fZip = File(modRoot, "ModPatch.ZIP").apply { writeBytes(ByteArray(15_000) { 4 }) }
            val fRar = File(l2, "SoundPack.RAR").apply { writeBytes(ByteArray(10_000) { 5 }) }
            val fIdx1 = File(modRoot, "Index").apply { writeBytes(ByteArray(2_000) { 6 }) }
            val fIdx2 = File(l3, "asset_index.idx").apply { writeBytes(ByteArray(1_500) { 7 }) }
            val fNoExt = File(l4, "MANIFEST_BINARY").apply { writeBytes(ByteArray(3_500) { 8 }) }

            val dlFolderItem = com.example.model.StorageFolderItem(
                name = "Download",
                path = downloadDir.absolutePath,
                relativeDisplayPath = "Download",
                parentFolderName = "",
                statsStatus = com.example.model.FolderStatsStatus.CALCULATING
            )
            com.example.data.DeviceMediaRepository.registerFolderItem(dlFolderItem)

            // Verify badges and readable types for all special files
            val bigItem = com.example.model.DeviceMediaItem(id = "1", name = fBig.name, localFile = fBig, sizeBytes = fBig.length(), dateModifiedMillis = fBig.lastModified(), category = com.example.model.FileCategory.fromFileName(fBig.name))
            val datItem = com.example.model.DeviceMediaItem(id = "2", name = fDat.name, localFile = fDat, sizeBytes = fDat.length(), dateModifiedMillis = fDat.lastModified(), category = com.example.model.FileCategory.fromFileName(fDat.name))
            val tgaItem = com.example.model.DeviceMediaItem(id = "3", name = fTga.name, localFile = fTga, sizeBytes = fTga.length(), dateModifiedMillis = fTga.lastModified(), category = com.example.model.FileCategory.fromFileName(fTga.name))
            val zipItem = com.example.model.DeviceMediaItem(id = "4", name = fZip.name, localFile = fZip, sizeBytes = fZip.length(), dateModifiedMillis = fZip.lastModified(), category = com.example.model.FileCategory.fromFileName(fZip.name))
            val rarItem = com.example.model.DeviceMediaItem(id = "5", name = fRar.name, localFile = fRar, sizeBytes = fRar.length(), dateModifiedMillis = fRar.lastModified(), category = com.example.model.FileCategory.fromFileName(fRar.name))
            val idxItem = com.example.model.DeviceMediaItem(id = "6", name = fIdx1.name, localFile = fIdx1, sizeBytes = fIdx1.length(), dateModifiedMillis = fIdx1.lastModified(), category = com.example.model.FileCategory.fromFileName(fIdx1.name))
            val noExtItem = com.example.model.DeviceMediaItem(id = "7", name = fNoExt.name, localFile = fNoExt, sizeBytes = fNoExt.length(), dateModifiedMillis = fNoExt.lastModified(), category = com.example.model.FileCategory.fromFileName(fNoExt.name))

            assertEquals("BIG", bigItem.fileExtensionBadge)
            assertEquals("ملف موارد ومودات (BIG)", bigItem.readableFileTypeLabel)
            assertEquals("DAT", datItem.fileExtensionBadge)
            assertEquals("ملف بيانات (DAT)", datItem.readableFileTypeLabel)
            assertEquals("TGA", tgaItem.fileExtensionBadge)
            assertEquals("ملف رسوميات وتكستشر (TGA)", tgaItem.readableFileTypeLabel)
            assertEquals("ZIP", zipItem.fileExtensionBadge)
            assertEquals("RAR", rarItem.fileExtensionBadge)
            assertEquals("INDEX", idxItem.fileExtensionBadge)
            assertEquals("ملف فهرسة (Index)", idxItem.readableFileTypeLabel)
            assertEquals("FILE", noExtItem.fileExtensionBadge)
            assertEquals("ملف بدون امتداد", noExtItem.readableFileTypeLabel)

            // Scenario 8, 9, 10: Check empty vs unreadable vs partially read folder stats
            val (modChildrenFolders, _) = com.example.data.DeviceMediaRepository.browseLocalDirectoryChildren(
                browsingRelOrAbsPath = "Download/GeneralsModPack",
                allKnownFolders = listOf(dlFolderItem),
                allKnownFiles = emptyList()
            )
            val emptySubItem = modChildrenFolders.first { it.name == "TrulyEmptyFolder" }
            val lockedSubItem = modChildrenFolders.first { it.name == "RestrictedSystemSub" }
            assertEquals(com.example.model.FolderStatsStatus.COMPLETED, com.example.data.DeviceMediaRepository.computeFolderStatsLazy(emptySubItem).statsStatus)
            assertEquals(com.example.model.FolderStatsStatus.ACCESS_RESTRICTED, lockedSubItem.statsStatus)

            val modFolderItem = com.example.model.StorageFolderItem(
                name = "GeneralsModPack",
                path = modRoot.absolutePath,
                relativeDisplayPath = "Download/GeneralsModPack",
                parentFolderName = "Download",
                statsStatus = com.example.model.FolderStatsStatus.CALCULATING
            )
            val computedModStats = com.example.data.DeviceMediaRepository.computeFolderStatsLazy(modFolderItem)
            val expectedModBytes = fBig.length() + fDat.length() + fTga.length() + fZip.length() + fRar.length() + fIdx1.length() + fIdx2.length() + fNoExt.length()
            assertEquals("Total size of mod folder must equal sum of all 8 files across all nested levels", expectedModBytes, computedModStats.totalBytes)
            assertEquals("Total file count of mod folder must be 8", 8, computedModStats.fileCount)
            assertEquals("Status must be PARTIALLY_READ when 1 subfolder is locked", com.example.model.FolderStatsStatus.PARTIALLY_READ, computedModStats.statsStatus)

            // Unlock lockedFolder and verify full scan for transfer does NOT decompress ZIP/RAR and preserves all 9 files + empty folder
            lockedFolder.setReadable(true, false)
            val scanResult = com.example.data.DeviceMediaRepository.scanLocalFolderForTransfer(modRoot, 256 * 1024)
            assertEquals(null, scanResult.errorMessage)
            assertEquals(9, scanResult.batchInfo!!.totalFilesCount)
            assertTrue("ZIP file must be transferred as-is without decompression", scanResult.transferItems.any { it.name == "ModPatch.ZIP" && !it.isDirectory && it.sizeBytes == fZip.length() })
            assertTrue("RAR file must be transferred as-is without decompression", scanResult.transferItems.any { it.name == "SoundPack.RAR" && !it.isDirectory && it.sizeBytes == fRar.length() })
            assertTrue("Index file must be transferred as-is", scanResult.transferItems.any { it.name == "Index" && !it.isDirectory })
            assertTrue("Extensionless file must be transferred as-is", scanResult.transferItems.any { it.name == "MANIFEST_BINARY" && !it.isDirectory })

            // Scenario 11: Deep search inside folder for nested .TGA, .BIG, Index, and extensionless files
            val (_, searchedTga) = com.example.data.DeviceMediaRepository.searchFilesAndFoldersInPath(
                query = "WaterRipple",
                activeBrowsingPath = "Download/GeneralsModPack",
                allKnownFolders = listOf(dlFolderItem, modFolderItem),
                allKnownFiles = emptyList()
            )
            assertEquals("Deep search inside GeneralsModPack must find nested WaterRipple.TGA at level 4", 1, searchedTga.size)
            assertEquals("WaterRipple.TGA", searchedTga.first().name)

            // Scenario 1, 6, 7: Folder with 1,200 files and multi-GB Long size calculation without overflow
            val thousandDir = File(downloadDir, "ThousandFilesMod").apply { mkdirs() }
            val subThousand = File(thousandDir, "NestedBatch").apply { mkdirs() }
            for (i in 1..1200) {
                val targetParent = if (i <= 600) thousandDir else subThousand
                val ext = when (i % 5) {
                    0 -> ".BIG"
                    1 -> ".DAT"
                    2 -> ".TGA"
                    3 -> ".ZIP"
                    else -> "" // extensionless
                }
                File(targetParent, "mod_asset_${i}$ext").writeBytes(ByteArray(100))
            }
            val thousandFolderItem = com.example.model.StorageFolderItem(
                name = "ThousandFilesMod",
                path = thousandDir.absolutePath,
                relativeDisplayPath = "Download/ThousandFilesMod",
                parentFolderName = "Download",
                statsStatus = com.example.model.FolderStatsStatus.CALCULATING
            )
            val computedThousand = com.example.data.DeviceMediaRepository.computeFolderStatsLazy(thousandFolderItem)
            assertEquals("Must accurately count all 1,200 files across subfolders", 1200, computedThousand.fileCount)
            assertEquals("Must accurately sum all 1,200 * 100 bytes", 120_000L, computedThousand.totalBytes)
            assertEquals(com.example.model.FolderStatsStatus.COMPLETED, computedThousand.statsStatus)

            // Multi-GB Long arithmetic verification (e.g., 6.5 GB folder via MediaStore fallback items)
            val multiGbItem1 = com.example.model.DeviceMediaItem(
                id = "gb_1",
                name = "MoviesPack1.BIG",
                sizeBytes = 3_500_000_000L, // 3.5 GB
                dateModifiedMillis = System.currentTimeMillis(),
                bucketOrFolderName = "Download/HugeMod",
                relativePathInStorage = "Download/HugeMod/MoviesPack1.BIG",
                category = com.example.model.FileCategory.fromFileName("MoviesPack1.BIG")
            )
            val multiGbItem2 = com.example.model.DeviceMediaItem(
                id = "gb_2",
                name = "MoviesPack2.DAT",
                sizeBytes = 3_200_000_000L, // 3.2 GB
                dateModifiedMillis = System.currentTimeMillis(),
                bucketOrFolderName = "Download/HugeMod/Sub",
                relativePathInStorage = "Download/HugeMod/Sub/MoviesPack2.DAT",
                category = com.example.model.FileCategory.fromFileName("MoviesPack2.DAT")
            )
            val hugeFolder = com.example.model.StorageFolderItem(
                name = "HugeMod",
                path = File(downloadDir, "HugeMod_Virtual").absolutePath,
                relativeDisplayPath = "Download/HugeMod",
                parentFolderName = "Download",
                mediaStoreFallbackItems = listOf(multiGbItem1, multiGbItem2),
                statsStatus = com.example.model.FolderStatsStatus.CALCULATING
            )
            val computedHuge = com.example.data.DeviceMediaRepository.computeFolderStatsLazy(hugeFolder)
            assertEquals("6.7 GB folder size must be calculated in Long without 32-bit overflow", 6_700_000_000L, computedHuge.totalBytes)
            assertEquals(2, computedHuge.fileCount)
            assertEquals(1, computedHuge.subfolderCount)
        } finally {
            runCatching {
                tempRoot.walkTopDown().forEach { it.setReadable(true, false); it.setWritable(true, false) }
                tempRoot.deleteRecursively()
            }
            com.example.data.DeviceMediaRepository.clearFolderStatsCache()
        }
    }

    @Test
    fun verifySaeedrponShockWaveFolderListingClassificationStatsAndCacheInvalidation() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val extRoot = android.os.Environment.getExternalStorageDirectory()
        val downloadDir = File(extRoot, "Download").apply { mkdirs() }
        val saeedDir = File(downloadDir, "saeedrpon").apply { mkdirs() }
        val shockWaveDir = File(saeedDir, "ShockWave").apply { mkdirs() }

        try {
            com.example.data.DeviceMediaRepository.clearFolderStatsCache()

            // Create 4 subfolders inside Download/saeedrpon/ShockWave
            val subData = File(shockWaveDir, "Data").apply { mkdirs() }
            val subArt = File(shockWaveDir, "Art").apply { mkdirs() }
            val subIni = File(shockWaveDir, "INI").apply { mkdirs() }
            val subEmpty = File(shockWaveDir, "EmptyMaps").apply { mkdirs() }

            // Create files of all requested types in Download/saeedrpon and Download/saeedrpon/ShockWave
            val tgaWithSpaces = File(saeedDir, "last stand_8.tga").apply { writeBytes(ByteArray(4_096) { 0x11 }) }
            val icoFile = File(saeedDir, "ShockWaveIcon.ico").apply { writeBytes(ByteArray(2_048) { 0x22 }) }
            val zipFile = File(saeedDir, "ShockWave_Patch.zip").apply { writeBytes(ByteArray(8_192) { 0x33 }) }
            val rarFile = File(saeedDir, "ShockWave_Addon.rar").apply { writeBytes(ByteArray(6_144) { 0x44 }) }
            val apkFile = File(saeedDir, "ModLauncher.apk").apply { writeBytes(ByteArray(10_240) { 0x55 }) }

            val swBig = File(shockWaveDir, "!ShockWave_Main.big").apply { writeBytes(ByteArray(16_384) { 0x66 }) }
            val swDat = File(subData, "GenTool.dat").apply { writeBytes(ByteArray(3_072) { 0x77 }) }
            val swTga = File(subArt, "SW_Logo 2.tga").apply { writeBytes(ByteArray(5_120) { 0x12 }) }
            val swNoExt = File(subIni, "Index").apply { writeBytes(ByteArray(1_024) { 0x34 }) }

            // Simulate a malformed MediaStore fallback item where bucketOrFolderName mistakenly includes the file name "last stand_8.tga"
            val malformedFallbackTga = com.example.model.DeviceMediaItem(
                id = "ms_tga_1",
                name = "last stand_8.tga",
                sizeBytes = tgaWithSpaces.length(),
                dateModifiedMillis = tgaWithSpaces.lastModified(),
                bucketOrFolderName = "Download/saeedrpon/last stand_8.tga",
                relativePathInStorage = "Download/saeedrpon/last stand_8.tga",
                localFile = tgaWithSpaces,
                category = com.example.model.FileCategory.fromFileName("last stand_8.tga")
            )
            val malformedFolderEntryForFile = com.example.model.StorageFolderItem(
                name = "last stand_8.tga",
                path = tgaWithSpaces.absolutePath,
                relativeDisplayPath = "Download/saeedrpon/last stand_8.tga",
                parentFolderName = "Download/saeedrpon",
                fileCount = 1,
                totalBytes = tgaWithSpaces.length()
            )

            // 1. Browse "Download/saeedrpon" and verify:
            // - Only "ShockWave" is classified as a folder (1 folder)
            // - "last stand_8.tga", ".ico", ".zip", ".rar", ".apk" are strictly classified as files (5 immediate files)
            // - "last stand_8.tga" NEVER appears in childFolders even if passed in allKnownFolders or allKnownFiles
            val (saeedFolders, saeedFiles) = com.example.data.DeviceMediaRepository.browseLocalDirectoryChildren(
                browsingRelOrAbsPath = "Download/saeedrpon",
                allKnownFolders = listOf(malformedFolderEntryForFile),
                allKnownFiles = listOf(malformedFallbackTga),
                context = context
            )

            assertEquals("Download/saeedrpon must contain exactly 1 subfolder (ShockWave)", 1, saeedFolders.size)
            assertEquals("ShockWave", saeedFolders.first().name)
            assertFalse("last stand_8.tga must NEVER be classified as a folder", saeedFolders.any { it.name.endsWith(".tga", ignoreCase = true) })

            val saeedFileNames = saeedFiles.map { it.name }.toSet()
            assertEquals("Download/saeedrpon must contain exactly 5 immediate files", 5, saeedFiles.size)
            assertTrue(saeedFileNames.containsAll( listOf("last stand_8.tga", "ShockWaveIcon.ico", "ShockWave_Patch.zip", "ShockWave_Addon.rar", "ModLauncher.apk") ))

            // 2. Browse "Download/saeedrpon/ShockWave" and verify:
            // - 4 immediate subfolders (Data, Art, INI, EmptyMaps)
            // - 1 immediate file (!ShockWave_Main.big)
            val (swFolders, swFiles) = com.example.data.DeviceMediaRepository.browseLocalDirectoryChildren(
                browsingRelOrAbsPath = "Download/saeedrpon/ShockWave",
                allKnownFolders = emptyList(),
                allKnownFiles = emptyList(),
                context = context
            )
            assertEquals("ShockWave must list all 4 immediate subfolders", 4, swFolders.size)
            assertEquals("ShockWave must list its immediate .big file", 1, swFiles.size)
            assertEquals("!ShockWave_Main.big", swFiles.first().name)

            // 3. Verify recursive folder statistics on ShockWave (4 files total across root + 4 subfolders, no duplicate counting)
            val duplicateMediaFallback = com.example.model.DeviceMediaItem(
                id = "dup_sw_big",
                name = "!ShockWave_Main.big",
                sizeBytes = swBig.length(),
                dateModifiedMillis = swBig.lastModified(),
                bucketOrFolderName = "Download/saeedrpon/ShockWave",
                relativePathInStorage = "Download/saeedrpon/ShockWave/!ShockWave_Main.big",
                localFile = swBig,
                category = com.example.model.FileCategory.fromFileName("!ShockWave_Main.big")
            )
            val swFolderItem = com.example.model.StorageFolderItem(
                name = "ShockWave",
                path = shockWaveDir.absolutePath,
                relativeDisplayPath = "Download/saeedrpon/ShockWave",
                parentFolderName = "Download/saeedrpon",
                mediaStoreFallbackItems = listOf(duplicateMediaFallback),
                statsStatus = com.example.model.FolderStatsStatus.CALCULATING
            )
            val swStats = com.example.data.DeviceMediaRepository.computeFolderStatsLazy(swFolderItem, context = context)
            val expectedSwBytes = swBig.length() + swDat.length() + swTga.length() + swNoExt.length()
            assertEquals("ShockWave recursive fileCount must be 4 without double-counting MediaStore items", 4, swStats.fileCount)
            assertEquals("ShockWave recursive subfolderCount must be 4", 4, swStats.subfolderCount)
            assertEquals("ShockWave recursive totalBytes must equal sum of all 4 files", expectedSwBytes, swStats.totalBytes)

            // 4. Verify cache invalidation when new files are added or permissions change
            val extraFile = File(shockWaveDir, "NewPatch.tga").apply { writeBytes(ByteArray(2_000)) }
            com.example.data.DeviceMediaRepository.clearFolderStatsCache()
            val refreshedStats = com.example.data.DeviceMediaRepository.computeFolderStatsLazy(swFolderItem, context = context)
            assertEquals("After clearFolderStatsCache, newly revealed files must be counted", 5, refreshedStats.fileCount)
            assertEquals(expectedSwBytes + extraFile.length(), refreshedStats.totalBytes)
        } finally {
            runCatching { saeedDir.deleteRecursively() }
            com.example.data.DeviceMediaRepository.clearFolderStatsCache()
        }
    }

    @Test
    fun verifyStage3And4PerformanceMetricsCacheValidationAndTransferNotifications() = runBlocking {
        P2PTransferViewModel.resetRetainedEngineForTests()
        val context = ApplicationProvider.getApplicationContext<Context>()
        @Suppress("DEPRECATION")
        val extRoot = android.os.Environment.getExternalStorageDirectory()
        val downloadDir = File(extRoot, "Download").apply { mkdirs() }
        val megaDir = File(downloadDir, "MegaPerfBench").apply {
            deleteRecursively()
            mkdirs()
        }

        try {
            com.example.data.DeviceMediaRepository.clearFolderStatsCache()

            // 1. Populate a realistic multi-folder hierarchy (15 subfolders + 20 immediate files + 1,200 nested files + empty folders)
            val immediateExts = listOf("tga", "ico", "zip", "rar", "apk", "big", "dat", "")
            for (i in 1..20) {
                val ext = immediateExts[i % immediateExts.size]
                val name = if (ext.isEmpty()) "RootIndex_$i" else "root_asset_$i.$ext"
                File(megaDir, name).writeBytes(ByteArray(512) { (i and 0xFF).toByte() })
            }
            for (s in 1..15) {
                val sub = File(megaDir, "ModPack_$s").apply { mkdirs() }
                if (s == 15) {
                    // Keep ModPack_15 as an empty folder to verify empty folder preservation
                    continue
                }
                val nestedArt = File(sub, "Art_TGA").apply { mkdirs() }
                for (f in 1..80) {
                    val fileTarget = if (f % 2 == 0) nestedArt else sub
                    val ext = immediateExts[(s + f) % immediateExts.size]
                    val fileName = if (ext.isEmpty()) "Manifest_${s}_$f" else "chunk_${s}_$f.$ext"
                    File(fileTarget, fileName).writeBytes(ByteArray(256) { ((s + f) and 0xFF).toByte() })
                }
            }

            // 2. Measure immediate folder open time (Depth = 1 only, zero inline recursive crawl)
            com.example.data.DeviceMediaRepository.resetFileReadOperationCount()
            val runtime = Runtime.getRuntime()
            val memBeforeBytes = (runtime.totalMemory() - runtime.freeMemory()).coerceAtLeast(0L)
            val openStartNano = System.nanoTime()

            val (immediateFolders, immediateFiles) = com.example.data.DeviceMediaRepository.browseLocalDirectoryChildren(
                browsingRelOrAbsPath = "Download/MegaPerfBench",
                allKnownFolders = emptyList(),
                allKnownFiles = emptyList(),
                context = context
            )

            val openElapsedMs = (System.nanoTime() - openStartNano) / 1_000_000L
            val openReadOps = com.example.data.DeviceMediaRepository.fileReadOperationCount.get()

            assertEquals("Must list all 15 immediate subfolders", 15, immediateFolders.size)
            assertEquals("Must list all 20 immediate files including TGA/ICO/ZIP/RAR/APK/BIG/DAT/extensionless", 20, immediateFiles.size)
            assertTrue(
                "Immediate folder open must complete in under 500ms without inline recursive blocking (took ${openElapsedMs}ms)",
                openElapsedMs < 500L
            )
            assertTrue(
                "Non-empty subfolders must start in CALCULATING state before lazy stats finish, never falsely marked 0 READY",
                immediateFolders.filter { it.name != "ModPack_15" }.all {
                    it.statsStatus == com.example.model.FolderStatsStatus.CALCULATING
                }
            )

            // 3. Measure lazy background stats calculation & verify multi-factor cache stamp invalidation
            val statsStartNano = System.nanoTime()
            val computedSubfolders = immediateFolders.map { folder ->
                com.example.data.DeviceMediaRepository.computeFolderStatsLazy(folder, context = context)
            }
            val statsElapsedMs = (System.nanoTime() - statsStartNano) / 1_000_000L
            val totalReadOpsAfterStats = com.example.data.DeviceMediaRepository.fileReadOperationCount.get()
            val memAfterBytes = (runtime.totalMemory() - runtime.freeMemory()).coerceAtLeast(0L)
            val memDeltaMb = (memAfterBytes - memBeforeBytes).coerceAtLeast(0L) / (1024.0 * 1024.0)

            val modPack1 = computedSubfolders.first { it.name == "ModPack_1" }
            val modPack15Empty = computedSubfolders.first { it.name == "ModPack_15" }
            assertEquals("Each populated ModPack subfolder must count 80 nested files", 80, modPack1.fileCount)
            assertEquals("Empty ModPack_15 folder must be preserved with 0 files", 0, modPack15Empty.fileCount)

            // Multi-factor cache hit check
            val cachedHit = com.example.data.DeviceMediaRepository.getValidCachedFolderStats(
                path = modPack1.path,
                context = context,
                currentDir = File(modPack1.path)
            )
            assertTrue("Multi-factor cache must hit when folder is unchanged", cachedHit != null && cachedHit.fileCount == 80)

            // Add a new immediate file to ModPack_1 -> immediate entry count changes -> cache stamp must auto-invalidate!
            File(megaDir, "ModPack_1/NewExpansion.big").writeBytes(ByteArray(1024))
            val cachedAfterMutation = com.example.data.DeviceMediaRepository.getValidCachedFolderStats(
                path = modPack1.path,
                context = context,
                currentDir = File(modPack1.path)
            )
            assertEquals("Multi-factor cache stamp must auto-invalidate when immediate entry count changes", null, cachedAfterMutation)

            println(
                "BENCHMARK_METRICS: openMs=$openElapsedMs, statsMs=$statsElapsedMs, openReadOps=$openReadOps, totalReadOps=$totalReadOpsAfterStats, memDeltaMb=${String.format(java.util.Locale.US, "%.2f", memDeltaMb)}"
            )

            // 4. Verify BarqTransferForegroundService Sending, Receiving, Pause/Resume, Cancel, and Terminal Notifications
            var pauseResumeInvoked = 0
            var cancelInvoked = 0
            com.example.service.BarqTransferForegroundService.bindTransferControlCallbacks(
                onPauseResume = { pauseResumeInvoked++ },
                onCancel = { cancelInvoked++ }
            )

            // 4a. Sending notification
            com.example.service.BarqTransferForegroundService.startOrUpdateTransfer(
                context = context,
                direction = com.example.model.TransferDirection.SENDING,
                currentFileName = "ShockWave_Mod_v2.zip",
                completedFiles = 3,
                totalFiles = 10,
                transferredBytes = 300L * 1024L * 1024L,
                totalBytes = 1000L * 1024L * 1024L,
                speedBytesPerSec = 45L * 1024L * 1024L,
                isPaused = false,
                forceUpdate = true
            )
            assertTrue(com.example.service.BarqTransferForegroundService.isServiceActive)
            assertTrue(com.example.service.BarqTransferForegroundService.lastNotificationTitle.contains("جاري الإرسال"))
            assertTrue(com.example.service.BarqTransferForegroundService.lastNotificationTitle.contains("30%"))
            assertTrue(com.example.service.BarqTransferForegroundService.lastNotificationBody.contains("ShockWave_Mod_v2.zip"))
            assertTrue(com.example.service.BarqTransferForegroundService.lastNotificationBody.contains("3/10"))
            assertEquals(300, com.example.service.BarqTransferForegroundService.lastProgressPermille)

            // 4b. Pause state update
            com.example.service.BarqTransferForegroundService.startOrUpdateTransfer(
                context = context,
                direction = com.example.model.TransferDirection.SENDING,
                currentFileName = "ShockWave_Mod_v2.zip",
                completedFiles = 3,
                totalFiles = 10,
                transferredBytes = 300L * 1024L * 1024L,
                totalBytes = 1000L * 1024L * 1024L,
                speedBytesPerSec = 0L,
                isPaused = true,
                forceUpdate = true
            )
            assertTrue(com.example.service.BarqTransferForegroundService.lastNotificationTitle.contains("متوقف مؤقتاً"))

            // 4c. Receiving notification
            com.example.service.BarqTransferForegroundService.startOrUpdateTransfer(
                context = context,
                direction = com.example.model.TransferDirection.RECEIVING,
                currentFileName = "ZeroHour_Maps.big",
                completedFiles = 7,
                totalFiles = 10,
                transferredBytes = 750L * 1024L * 1024L,
                totalBytes = 1000L * 1024L * 1024L,
                speedBytesPerSec = 52L * 1024L * 1024L,
                isPaused = false,
                forceUpdate = true
            )
            assertTrue(com.example.service.BarqTransferForegroundService.lastNotificationTitle.contains("جاري الاستلام"))
            assertTrue(com.example.service.BarqTransferForegroundService.lastNotificationTitle.contains("75%"))
            assertEquals(750, com.example.service.BarqTransferForegroundService.lastProgressPermille)

            // 4d. Service intent actions (Pause/Resume & Cancel)
            val serviceController = org.robolectric.Robolectric.buildService(com.example.service.BarqTransferForegroundService::class.java).create()
            serviceController.get().onStartCommand(
                android.content.Intent(context, com.example.service.BarqTransferForegroundService::class.java).apply {
                    action = com.example.service.BarqTransferForegroundService.ACTION_PAUSE_RESUME
                },
                0,
                1
            )
            assertEquals("ACTION_PAUSE_RESUME must invoke bound pause/resume callback", 1, pauseResumeInvoked)

            serviceController.get().onStartCommand(
                android.content.Intent(context, com.example.service.BarqTransferForegroundService::class.java).apply {
                    action = com.example.service.BarqTransferForegroundService.ACTION_CANCEL
                },
                0,
                2
            )
            assertEquals("ACTION_CANCEL must invoke bound cancel callback", 1, cancelInvoked)
            assertFalse("ACTION_CANCEL must stop foreground service", com.example.service.BarqTransferForegroundService.isServiceActive)

            // 4e. Terminal Success Notification (NOTIFICATION_ID_RESULT = 8990)
            com.example.service.BarqTransferForegroundService.postTerminalTransferNotification(
                context = context,
                direction = com.example.model.TransferDirection.RECEIVING,
                completedFiles = 10,
                totalFiles = 10,
                transferredBytes = 1000L * 1024L * 1024L,
                totalBytes = 1000L * 1024L * 1024L,
                failedFilesCount = 0,
                errorMessage = null
            )
            assertTrue(com.example.service.BarqTransferForegroundService.lastResultIsSuccess)
            assertTrue(com.example.service.BarqTransferForegroundService.lastResultNotificationTitle.contains("اكتمل استلام الملفات بنجاح"))
            assertFalse(com.example.service.BarqTransferForegroundService.isServiceActive)
            assertFalse(com.example.service.BarqTransferForegroundService.isWakeLockHeld)
            assertFalse(com.example.service.BarqTransferForegroundService.isWifiLockHeld)

            // 4f. Terminal Failure Notification (NOTIFICATION_ID_RESULT = 8990)
            com.example.service.BarqTransferForegroundService.postTerminalTransferNotification(
                context = context,
                direction = com.example.model.TransferDirection.SENDING,
                completedFiles = 8,
                totalFiles = 10,
                transferredBytes = 800L * 1024L * 1024L,
                totalBytes = 1000L * 1024L * 1024L,
                failedFilesCount = 2,
                errorMessage = "انقطع الاتصال بجهاز المستلم"
            )
            assertFalse(com.example.service.BarqTransferForegroundService.lastResultIsSuccess)
            assertTrue(com.example.service.BarqTransferForegroundService.lastResultNotificationTitle.contains("تعذر إكمال إرسال بعض الملفات"))
            assertTrue(com.example.service.BarqTransferForegroundService.lastResultNotificationBody.contains("8/10"))

            com.example.service.BarqTransferForegroundService.unbindTransferControlCallbacks()
        } finally {
            runCatching { megaDir.deleteRecursively() }
            com.example.data.DeviceMediaRepository.clearFolderStatsCache()
        }
    }

    @Test
    fun verifyNavigationDrawerScreensAndNineThemesContrastAndPersistence() {
        val context = ApplicationProvider.getApplicationContext<Context>()

        // 1. Verify Top Bar ☰ button exists and opens the Navigation Drawer
        composeTestRule.onNodeWithTag("top_bar_drawer_menu_button").assertExists().performClick()
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("barq_navigation_drawer_sheet").assertExists()

        // Verify all 8 required drawer items exist in the Navigation Drawer
        val requiredDrawerIds = listOf(
            "drawer_item_HOME",
            "drawer_item_FILES",
            "drawer_item_SEND_RECEIVE",
            "drawer_item_DEVICES_SESSIONS",
            "drawer_item_HISTORY",
            "drawer_item_THEMES",
            "drawer_item_SETTINGS",
            "drawer_item_ABOUT"
        )
        for (drawerTag in requiredDrawerIds) {
            composeTestRule.onNodeWithTag(drawerTag)
                .performScrollTo()
                .assertExists()
        }

        // Verify extensibility of buildDefaultBarqDrawerItems with extraItems
        val baseDrawerItems = com.example.ui.screens.buildDefaultBarqDrawerItems(
            uiState = com.example.viewmodel.P2PUiState(),
            onNavigateScreen = {},
            onOpenSettings = {},
            onOpenAbout = {}
        )
        assertEquals("Default drawer must have 8 standard items", 8, baseDrawerItems.size)
        val customExtraList = com.example.ui.screens.buildDefaultBarqDrawerItems(
            uiState = com.example.viewmodel.P2PUiState(),
            onNavigateScreen = {},
            onOpenSettings = {},
            onOpenAbout = {},
            extraItems = listOf(
                com.example.ui.screens.BarqDrawerMenuItem(
                    id = "FUTURE_CLOUD",
                    title = "ميزة مستقبلية",
                    subtitle = "عنصر إضافي قابل للتوسعة",
                    icon = baseDrawerItems.first().icon,
                    accentColor = com.example.ui.theme.ElectricCyan,
                    onCustomClick = {}
                )
            )
        )
        assertEquals("8 standard items + 1 extensible item = 9", 9, customExtraList.size)

        // 2. Navigate via Drawer to File Manager (مدير الملفات), then open Drawer and navigate to Themes & Colors (الثيمات والألوان)
        composeTestRule.onNodeWithTag("drawer_item_FILES")
            .performScrollTo()
            .performClick()
        composeTestRule.waitForIdle()

        // Re-open drawer and navigate to Themes & Colors screen
        composeTestRule.onNodeWithTag("top_bar_drawer_menu_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("drawer_item_THEMES")
            .performScrollTo()
            .performClick()
        composeTestRule.waitForIdle()

        // Verify Themes & Colors screen is displayed with Live Preview Card, Auto System Switch, and Reset Button
        composeTestRule.onNodeWithTag("themes_and_colors_screen").assertExists()
        composeTestRule.onNodeWithTag("theme_live_preview_card").performScrollTo().assertExists()
        composeTestRule.onNodeWithTag("auto_system_theme_switch").performScrollTo().assertExists()
        composeTestRule.onNodeWithTag("reset_default_theme_button").performScrollTo().assertExists()

        // 3. Test all 27 themes (9 original + 18 new), verify contrast ratios >= 4.5:1, and verify app-wide reactive color updates
        val allThemeIds = com.example.ui.theme.BarqThemeId.entries
        assertEquals("Must support all 27 themes (9 original + 18 new)", 27, allThemeIds.size)

        for (themeId in allThemeIds) {
            // Preview before applying
            val previewPalette = com.example.ui.theme.BarqThemePalettes.forThemeId(themeId)
            assertTrue(
                "Primary text contrast ratio for ${themeId.englishTitle} must be >= 4.5 (got ${previewPalette.contrastRatioPrimaryText})",
                previewPalette.contrastRatioPrimaryText >= 4.5
            )
            val buttonTextContrast = com.example.ui.theme.calculateContrastRatio(
                previewPalette.onPrimaryAccent,
                previewPalette.primaryAccent
            )
            assertTrue(
                "Button text contrast on primary accent for ${themeId.englishTitle} must be >= 4.5 (got $buttonTextContrast)",
                buttonTextContrast >= 4.5
            )

            // Verify both Dark and Light brightness adaptation maintain >= 4.5 contrast
            val adaptedDark = com.example.ui.theme.adaptPaletteForBrightness(
                previewPalette,
                targetIsLight = false
            )
            val adaptedLight = com.example.ui.theme.adaptPaletteForBrightness(
                previewPalette,
                targetIsLight = true
            )
            assertFalse("Forced DARK mode for ${themeId.englishTitle} must have isLight=false", adaptedDark.isLight)
            assertTrue("Forced LIGHT mode for ${themeId.englishTitle} must have isLight=true", adaptedLight.isLight)
            assertTrue(
                "Forced DARK text contrast for ${themeId.englishTitle} must be >= 4.5",
                adaptedDark.contrastRatioPrimaryText >= 4.5
            )
            assertTrue(
                "Forced LIGHT text contrast for ${themeId.englishTitle} must be >= 4.5",
                adaptedLight.contrastRatioPrimaryText >= 4.5
            )

            // Apply theme and verify persistence in SharedPreferences
            com.example.ui.theme.BarqThemeState.applyTheme(context, themeId)
            assertEquals(themeId, com.example.ui.theme.BarqThemeState.selectedThemeId)
            assertEquals(previewPalette.background, com.example.ui.theme.MidnightBg)
            assertEquals(previewPalette.card, com.example.ui.theme.MidnightCard)
            assertEquals(previewPalette.primaryAccent, com.example.ui.theme.ElectricCyan)
            assertEquals(previewPalette.textPrimary, com.example.ui.theme.TextPrimary)
        }

        // Verify Pure Light, Arctic Ice, Silver, Lavender, Cherry Blossom, Desert Sand have light background and dark primary text
        val lightThemeIds = listOf(
            com.example.ui.theme.BarqThemeId.PURE_LIGHT,
            com.example.ui.theme.BarqThemeId.ARCTIC_ICE,
            com.example.ui.theme.BarqThemeId.SILVER,
            com.example.ui.theme.BarqThemeId.LAVENDER,
            com.example.ui.theme.BarqThemeId.CHERRY_BLOSSOM,
            com.example.ui.theme.BarqThemeId.DESERT_SAND
        )
        for (lightId in lightThemeIds) {
            com.example.ui.theme.BarqThemeState.applyTheme(context, lightId)
            assertTrue("${lightId.englishTitle} must have isLight = true", com.example.ui.theme.BarqThemeState.activePalette.isLight)
            assertTrue(
                "${lightId.englishTitle} primary text contrast must be >= 7.0",
                com.example.ui.theme.BarqThemeState.activePalette.contrastRatioPrimaryText >= 7.0
            )
        }

        // 4. Test all 10 Animated Themes, keyframe interpolation, speed settings, background pause, and persistence
        val animatedItems = com.example.ui.theme.BarqAnimatedThemeId.animatedPresets
        assertEquals("Must support exactly 10 animated themes", 10, animatedItems.size)
        for (animId in animatedItems) {
            for (phase in listOf(0f, 0.25f, 0.5f, 0.75f, 0.99f)) {
                val framePalette = com.example.ui.theme.BarqAnimatedThemes.resolveAnimatedPalette(animId, phase)
                assertTrue(
                    "Animated theme ${animId.englishTitle} at phase $phase must have text contrast >= 4.5 (got ${framePalette.contrastRatioPrimaryText})",
                    framePalette.contrastRatioPrimaryText >= 4.5
                )
            }
            com.example.ui.theme.BarqThemeState.applyAnimatedTheme(context, animId)
            assertEquals(animId, com.example.ui.theme.BarqThemeState.selectedAnimatedThemeId)
            assertTrue(com.example.ui.theme.BarqThemeState.isThemeAnimationEnabled)
        }

        // Verify animation speeds and background pause
        for (speed in com.example.ui.theme.BarqAnimationSpeed.entries) {
            com.example.ui.theme.BarqThemeState.setThemeAnimationSpeed(context, speed)
            assertEquals(speed, com.example.ui.theme.BarqThemeState.animationSpeed)
        }
        com.example.ui.theme.BarqThemeState.setRespectReduceMotion(context, false)
        com.example.ui.theme.BarqThemeState.setAppForegroundState(true)
        assertTrue(
            "Animation must run when foregrounded and enabled",
            com.example.ui.theme.BarqThemeState.shouldAnimateActiveTheme(context)
        )
        com.example.ui.theme.BarqThemeState.setAppForegroundState(false)
        assertFalse(
            "Animation must pause when app is in background",
            com.example.ui.theme.BarqThemeState.shouldAnimateActiveTheme(context)
        )
        com.example.ui.theme.BarqThemeState.setAppForegroundState(true)
        com.example.ui.theme.BarqThemeState.setThemeAnimationEnabled(context, false)
        assertFalse(
            "Animation must stop when disabled by user",
            com.example.ui.theme.BarqThemeState.shouldAnimateActiveTheme(context)
        )

        // 5. Test 7-channel Custom Theme and verify persistence across simulated app restart without startup flash
        val customPrimary = androidx.compose.ui.graphics.Color(0xFFEC4899)
        val customSecondary = androidx.compose.ui.graphics.Color(0xFF06B6D4)
        val customBg = androidx.compose.ui.graphics.Color(0xFF0B0719)
        val customCard = androidx.compose.ui.graphics.Color(0xFF16102C)
        val customButton = androidx.compose.ui.graphics.Color(0xFFF43F5E)
        val customText = androidx.compose.ui.graphics.Color(0xFFFDF2F8)
        val customBorder = androidx.compose.ui.graphics.Color(0xFF8B5CF6)
        com.example.ui.theme.BarqThemeState.updateCustomTheme(
            context = context,
            primary = customPrimary,
            secondary = customSecondary,
            background = customBg,
            card = customCard,
            button = customButton,
            text = customText,
            border = customBorder,
            isLight = false,
            applyImmediately = true
        )
        assertEquals(com.example.ui.theme.BarqThemeId.CUSTOM, com.example.ui.theme.BarqThemeState.selectedThemeId)
        assertEquals(customPrimary, com.example.ui.theme.BarqThemeState.customPrimaryColor)
        assertEquals(customSecondary, com.example.ui.theme.BarqThemeState.customSecondaryColor)
        assertEquals(customBg, com.example.ui.theme.BarqThemeState.customBackgroundColor)
        assertEquals(customCard, com.example.ui.theme.BarqThemeState.customCardColor)
        assertEquals(customButton, com.example.ui.theme.BarqThemeState.customButtonColor)
        assertEquals(customText, com.example.ui.theme.BarqThemeState.customTextColor)
        assertEquals(customBorder, com.example.ui.theme.BarqThemeState.customBorderColor)

        // Simulate cold start: reset initialization flag, set memory state to default MIDNIGHT_BLUE,
        // and verify synchronous ensureInitialized loads saved theme BEFORE first frame
        val prefs = context.getSharedPreferences("barq_theme_prefs", Context.MODE_PRIVATE)
        assertEquals(
            com.example.ui.theme.BarqThemeId.CUSTOM.storageKey,
            prefs.getString("selected_theme_id", null)
        )
        com.example.ui.theme.BarqThemeState.resetInitializationFlagForTesting()
        assertEquals(
            com.example.ui.theme.BarqThemeId.MIDNIGHT_BLUE,
            com.example.ui.theme.BarqThemeState.selectedThemeId
        )
        com.example.ui.theme.BarqThemeState.ensureInitialized(context)
        assertEquals(
            "Saved CUSTOM theme must be synchronously restored before first frame on cold start",
            com.example.ui.theme.BarqThemeId.CUSTOM,
            com.example.ui.theme.BarqThemeState.selectedThemeId
        )
        assertEquals(customPrimary, com.example.ui.theme.BarqThemeState.customPrimaryColor)
        assertEquals(customCard, com.example.ui.theme.BarqThemeState.customCardColor)
        assertEquals(customButton, com.example.ui.theme.BarqThemeState.customButtonColor)
        assertEquals(customText, com.example.ui.theme.BarqThemeState.customTextColor)
        assertEquals(customBorder, com.example.ui.theme.BarqThemeState.customBorderColor)

        // 6. Test Auto System Light/Dark Mode switch
        com.example.ui.theme.BarqThemeState.setAutoSystemMode(context, enabled = true, isSystemDarkNow = false)
        assertTrue(com.example.ui.theme.BarqThemeState.autoSystemDarkLightMode)
        assertEquals(
            "When system is in light mode and autoSystemDarkLightMode is true, activePalette must be Pure Light",
            com.example.ui.theme.BarqThemeId.PURE_LIGHT,
            com.example.ui.theme.BarqThemeState.activePalette.themeId
        )
        com.example.ui.theme.BarqThemeState.setAutoSystemMode(context, enabled = true, isSystemDarkNow = true)
        assertFalse(
            "When system is in dark mode, activePalette must be dark",
            com.example.ui.theme.BarqThemeState.activePalette.isLight
        )

        // 7. Test RTL (Arabic) and LTR (English) direction support for Navigation Drawer
        com.example.ui.theme.BarqThemeState.setLayoutDirectionMode(
            context,
            androidx.compose.ui.unit.LayoutDirection.Ltr
        )
        assertEquals(
            androidx.compose.ui.unit.LayoutDirection.Ltr,
            com.example.ui.theme.BarqThemeState.layoutDirection
        )
        com.example.ui.theme.BarqThemeState.setLayoutDirectionMode(
            context,
            androidx.compose.ui.unit.LayoutDirection.Rtl
        )
        assertEquals(
            androidx.compose.ui.unit.LayoutDirection.Rtl,
            com.example.ui.theme.BarqThemeState.layoutDirection
        )

        // 8. Test Reset to Default Theme button logic
        com.example.ui.theme.BarqThemeState.resetToDefaultTheme(context)
        assertEquals(
            com.example.ui.theme.BarqThemeId.MIDNIGHT_BLUE,
            com.example.ui.theme.BarqThemeState.selectedThemeId
        )
        assertEquals(
            com.example.ui.theme.BarqAnimatedThemeId.NONE,
            com.example.ui.theme.BarqThemeState.selectedAnimatedThemeId
        )
        assertFalse(com.example.ui.theme.BarqThemeState.autoSystemDarkLightMode)
    }

    @Test
    fun verifyInternalUiPerformanceOptimizationFrameMetricsAndMemoryStability(): Unit = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()

        // 0. Verify NO FPS counter, frame rate overlay, or technical telemetry is exposed in the user UI
        composeTestRule.waitForIdle()
        assertEquals(
            "No FPS counter or telemetry text may be visible to the user",
            0,
            composeTestRule.onAllNodesWithText("FPS", substring = true, ignoreCase = false)
                .fetchSemanticsNodes().size
        )

        // 1. Verify configureAdaptiveDisplayRefreshRate respects device display settings & Power Save Mode
        //    without forcing a specific display mode ID or refresh rate override
        val winAttrs = composeTestRule.activity.window.attributes
        assertEquals(
            "Window must not force a hardware display mode override (preferredDisplayModeId must be 0)",
            0,
            winAttrs.preferredDisplayModeId
        )
        assertEquals(
            "Window must not force a fixed refresh rate override (preferredRefreshRate must be 0f)",
            0f,
            winAttrs.preferredRefreshRate,
            0.001f
        )

        // 2. Verify P2PUiState derived properties ALWAYS update immediately when files, progress, or statuses change (zero stale values)
        val mb = 1024L * 1024L
        val file1 = TransferFileItem(
            id = "f1",
            name = "Video_1.mp4",
            sizeBytes = 10L * mb,
            transferredBytes = 0L,
            category = FileCategory.VIDEO,
            status = FileTransferStatus.QUEUED,
            totalChunks = 10,
            completedChunks = 0,
            rootFolderName = "MediaPack"
        )
        val file2 = TransferFileItem(
            id = "f2",
            name = "Archive_2.zip",
            sizeBytes = 20L * mb,
            transferredBytes = 0L,
            category = FileCategory.ARCHIVE,
            status = FileTransferStatus.QUEUED,
            totalChunks = 20,
            completedChunks = 0,
            rootFolderName = "MediaPack"
        )
        val file3 = TransferFileItem(
            id = "f3",
            name = "Game_3.apk",
            sizeBytes = 30L * mb,
            transferredBytes = 0L,
            category = FileCategory.GAME_APK,
            status = FileTransferStatus.QUEUED,
            totalChunks = 30,
            completedChunks = 0
        )
        val emptyDir = TransferFileItem(
            id = "dir1",
            name = "EmptySubfolder",
            sizeBytes = 0L,
            transferredBytes = 0L,
            category = FileCategory.FOLDER,
            isDirectory = true,
            status = FileTransferStatus.COMPLETED,
            totalChunks = 1,
            completedChunks = 1,
            rootFolderName = "MediaPack"
        )

        // Stage A: Initial queued state (60 MB across 3 files + 1 empty dir)
        val stateStageA = com.example.viewmodel.P2PUiState(
            files = listOf(file1, file2, file3, emptyDir),
            pendingIncomingFiles = listOf(file1, file2)
        )
        assertEquals(60L * mb, stateStageA.totalBytes)
        assertEquals(0L, stateStageA.transferredBytes)
        assertEquals(60L * mb, stateStageA.remainingBytes)
        assertEquals(0f, stateStageA.overallProgressFraction, 0.0001f)
        assertEquals(61, stateStageA.totalChunksCount)
        assertEquals(1, stateStageA.completedChunksCount)
        assertEquals(3, stateStageA.totalFilesOnlyCount)
        assertEquals(0, stateStageA.completedFilesOnlyCount)
        assertEquals(3, stateStageA.remainingFilesOnlyCount)
        assertEquals(0, stateStageA.failedFilesOnlyCount)
        assertEquals(1, stateStageA.totalEmptyDirsCount)
        assertEquals("f1", stateStageA.activeTransferringFile?.id)
        assertEquals(listOf("MediaPack"), stateStageA.activeFolderNames)
        assertEquals(30L * mb, stateStageA.pendingTotalBytes)
        assertEquals(listOf("MediaPack"), stateStageA.pendingFolderNames)

        // Stage B: File 1 transfers 5 MB (50%), verify new snapshot reflects updated progress immediately
        val stateStageB = stateStageA.copy(
            files = stateStageA.files.map {
                if (it.id == "f1") it.copy(
                    transferredBytes = 5L * mb,
                    completedChunks = 5,
                    status = FileTransferStatus.TRANSFERRING
                ) else it
            }
        )
        assertEquals(60L * mb, stateStageB.totalBytes)
        assertEquals(5L * mb, stateStageB.transferredBytes)
        assertEquals(55L * mb, stateStageB.remainingBytes)
        assertEquals((5.0 / 60.0).toFloat(), stateStageB.overallProgressFraction, 0.001f)
        assertEquals(6, stateStageB.completedChunksCount)
        assertEquals(0, stateStageB.completedFilesOnlyCount)
        assertEquals(3, stateStageB.remainingFilesOnlyCount)
        assertEquals("f1", stateStageB.activeTransferringFile?.id)

        // Stage C: File 1 completes (10 MB), File 2 is transferring at 10 MB (50%)
        val stateStageC = stateStageB.copy(
            files = stateStageB.files.map {
                when (it.id) {
                    "f1" -> it.copy(
                        transferredBytes = 10L * mb,
                        completedChunks = 10,
                        status = FileTransferStatus.COMPLETED
                    )
                    "f2" -> it.copy(
                        transferredBytes = 10L * mb,
                        completedChunks = 10,
                        status = FileTransferStatus.TRANSFERRING
                    )
                    else -> it
                }
            }
        )
        assertEquals(60L * mb, stateStageC.totalBytes)
        assertEquals(20L * mb, stateStageC.transferredBytes)
        assertEquals((20.0 / 60.0).toFloat(), stateStageC.overallProgressFraction, 0.001f)
        assertEquals(1, stateStageC.completedFilesOnlyCount)
        assertEquals(2, stateStageC.remainingFilesOnlyCount)
        assertEquals("f2", stateStageC.activeTransferringFile?.id)

        // Stage D: Add File 4 (40 MB) dynamically mid-session -> totalBytes must jump to 100 MB
        val file4 = TransferFileItem(
            id = "f4",
            name = "Dataset_4.tar",
            sizeBytes = 40L * mb,
            transferredBytes = 0L,
            category = FileCategory.ARCHIVE,
            status = FileTransferStatus.QUEUED,
            totalChunks = 40,
            completedChunks = 0,
            rootFolderName = "ExtraBatch"
        )
        val stateStageD = stateStageC.copy(files = stateStageC.files + file4)
        assertEquals(100L * mb, stateStageD.totalBytes)
        assertEquals(20L * mb, stateStageD.transferredBytes)
        assertEquals(0.20f, stateStageD.overallProgressFraction, 0.001f)
        assertEquals(4, stateStageD.totalFilesOnlyCount)
        assertEquals(1, stateStageD.completedFilesOnlyCount)
        assertEquals(3, stateStageD.remainingFilesOnlyCount)
        assertEquals(listOf("MediaPack", "ExtraBatch"), stateStageD.activeFolderNames)

        // Stage E: File 2 is cancelled, File 3 & File 4 complete -> active totalBytes becomes 80 MB and progress reaches 100% (1.0f)
        val stateStageE = stateStageD.copy(
            files = stateStageD.files.map {
                when (it.id) {
                    "f2" -> it.copy(status = FileTransferStatus.CANCELLED, transferredBytes = 0L, completedChunks = 0)
                    "f3" -> it.copy(status = FileTransferStatus.COMPLETED, transferredBytes = 30L * mb, completedChunks = 30)
                    "f4" -> it.copy(status = FileTransferStatus.COMPLETED, transferredBytes = 40L * mb, completedChunks = 40)
                    else -> it
                }
            }
        )
        assertEquals(80L * mb, stateStageE.totalBytes)
        assertEquals(80L * mb, stateStageE.transferredBytes)
        assertEquals(0L, stateStageE.remainingBytes)
        assertEquals(1.0f, stateStageE.overallProgressFraction, 0.0001f)
        assertEquals(3, stateStageE.totalFilesOnlyCount)
        assertEquals(3, stateStageE.completedFilesOnlyCount)
        assertEquals(0, stateStageE.remainingFilesOnlyCount)
        assertEquals(1, stateStageE.failedFilesOnlyCount)
        assertEquals(null, stateStageE.activeTransferringFile)

        // 3. Real Live Transfer End-to-End Progress Verification over HTTP P2PChunkServer
        val tempTransferDir = File(context.cacheDir, "perf_live_verify_${System.currentTimeMillis()}").apply { mkdirs() }
        val recvOutDir = File(tempTransferDir, "out").apply { mkdirs() }
        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        try {
            val payload1 = Random(501).nextBytes(512 * 1024) // 512 KB
            val payload2 = Random(502).nextBytes(768 * 1024) // 768 KB
            val srcFile1 = File(tempTransferDir, "live_part_1.bin").apply { writeBytes(payload1) }
            val srcFile2 = File(tempTransferDir, "live_part_2.bin").apply { writeBytes(payload2) }
            val liveItems = listOf(
                TransferFileItem(
                    id = "live_1",
                    name = srcFile1.name,
                    sizeBytes = srcFile1.length(),
                    category = FileCategory.DOCUMENT,
                    localFile = srcFile1,
                    totalChunks = 8,
                    sha256Expected = Sha256Util.computeFileSha256(srcFile1)
                ),
                TransferFileItem(
                    id = "live_2",
                    name = srcFile2.name,
                    sizeBytes = srcFile2.length(),
                    category = FileCategory.DOCUMENT,
                    localFile = srcFile2,
                    totalChunks = 12,
                    sha256Expected = Sha256Util.computeFileSha256(srcFile2)
                )
            )
            var liveUiState = com.example.viewmodel.P2PUiState(files = liveItems, isTransferRunning = true)
            val observedProgressSnapshots = java.util.Collections.synchronizedList(mutableListOf<Pair<Long, Float>>())
            observedProgressSnapshots.add(liveUiState.transferredBytes to liveUiState.overallProgressFraction)

            val liveServer = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { "BRQ-5500" },
                isSenderReadyProvider = { true },
                chunkSizeProvider = { ChunkSizeOption.CHUNK_64KB },
                filesProvider = { liveItems },
                onChunkServed = { _, _, _ -> }
            )
            val livePort = liveServer.startServer(0)
            try {
                Thread.sleep(60)
                val failed = P2PTransferViewModel.executeHighSpeedReceiveSession(
                    hostIp = "127.0.0.1",
                    hostPort = livePort,
                    sessionCode = "BRQ-5500",
                    chunkSizeBytes = ChunkSizeOption.CHUNK_64KB.bytes,
                    downloadDir = recvOutDir,
                    itemsProvider = { liveUiState.files },
                    isPausedProvider = { false },
                    onFileUpdated = { fileId, fSpeed, sSpeed, transform ->
                        synchronized(observedProgressSnapshots) {
                            liveUiState = liveUiState.copy(
                                files = liveUiState.files.map { if (it.id == fileId) transform(it) else it },
                                liveOverallSpeedBytesPerSec = maxOf(fSpeed, sSpeed)
                            )
                            observedProgressSnapshots.add(liveUiState.transferredBytes to liveUiState.overallProgressFraction)
                        }
                    },
                    onFileCompleted = { _, _ -> },
                    onFileFailed = { _, _ -> }
                )
                assertFalse("Live transfer must complete without errors", failed)
                assertEquals(payload1.size.toLong() + payload2.size.toLong(), liveUiState.transferredBytes)
                assertEquals(1.0f, liveUiState.overallProgressFraction, 0.0001f)
                assertEquals(2, liveUiState.completedFilesOnlyCount)
                assertEquals(0, liveUiState.remainingFilesOnlyCount)
                assertTrue(
                    "Multiple progressive P2PUiState snapshots must be recorded from 0 bytes to full completion",
                    observedProgressSnapshots.size >= 3 &&
                        observedProgressSnapshots.first().first == 0L &&
                        observedProgressSnapshots.last().first == liveUiState.totalBytes
                )
            } finally {
                liveServer.stopServer()
            }
        } finally {
            serverScope.cancel()
            tempTransferDir.deleteRecursively()
        }

        // 4. Real Benchmark: Uncached O(N) vs Single-Pass Cached P2PUiState across 120 frames (250 files x 14 reads/frame)
        val largeQueue = (1..250).map { idx ->
            TransferFileItem(
                id = "perf_file_$idx",
                name = "Archive_Part_$idx.zip",
                relativePath = if (idx % 3 == 0) "ProjectBackup/Sub_$idx/Archive_Part_$idx.zip" else "Archive_Part_$idx.zip",
                sizeBytes = 10L * mb,
                transferredBytes = if (idx <= 120) 10L * mb else 4L * mb,
                category = FileCategory.ARCHIVE,
                status = when {
                    idx <= 120 -> FileTransferStatus.COMPLETED
                    idx == 121 -> FileTransferStatus.TRANSFERRING
                    else -> FileTransferStatus.QUEUED
                },
                totalChunks = 20,
                completedChunks = if (idx <= 120) 20 else 8
            )
        }

        // Measure legacy uncached O(N) per-property access over 120 frames
        val uncachedStartNs = System.nanoTime()
        var uncachedChecksum = 0L
        repeat(120) {
            val active = largeQueue.filterNot { it.status == FileTransferStatus.CANCELLED }.ifEmpty { largeQueue }
            val tBytes = active.sumOf { it.sizeBytes }
            val xBytes = active.sumOf { it.transferredBytes }
            val prog = (xBytes.toDouble() / tBytes.toDouble()).toFloat()
            val tChunks = active.sumOf { it.totalChunks.toLong() }.toInt()
            val cChunks = active.sumOf { it.completedChunks.toLong() }.toInt()
            val tFiles = active.count { !it.isDirectory }
            val cFiles = largeQueue.count { !it.isDirectory && it.status == FileTransferStatus.COMPLETED }
            val rFiles = largeQueue.count { !it.isDirectory && it.status != FileTransferStatus.COMPLETED && it.status != FileTransferStatus.CANCELLED }
            val fFiles = largeQueue.count { !it.isDirectory && (it.status == FileTransferStatus.FAILED || it.status == FileTransferStatus.CANCELLED) }
            val curFile = largeQueue.firstOrNull { !it.isDirectory && it.status == FileTransferStatus.TRANSFERRING }
            val standalone = largeQueue.filter { it.folderBatchId.isBlank() }
            val folders = largeQueue.mapNotNull { it.rootFolderName.takeIf { n -> n.isNotBlank() } }.distinct()
            uncachedChecksum += tBytes + xBytes + (prog * 1000).toLong() + tChunks + cChunks + tFiles + cFiles + rFiles + fFiles + (curFile?.sizeBytes ?: 0L) + standalone.size + folders.size
        }
        val uncachedTotalMs = (System.nanoTime() - uncachedStartNs) / 1_000_000.0
        val uncachedAvgPerFrameMs = uncachedTotalMs / 120.0

        val stateSnapshot = com.example.viewmodel.P2PUiState(
            files = largeQueue,
            selectedMediaIds = (1..150).map { "media_$it" }.toSet(),
            deviceImages = (1..200).map { idx ->
                com.example.model.DeviceMediaItem(
                    id = "media_$idx",
                    name = "Photo_$idx.jpg",
                    sizeBytes = 3_500_000L,
                    category = FileCategory.IMAGE,
                    dateModifiedMillis = 1_700_000_000_000L + idx
                )
            }
        )

        val stateBenchStartNs = System.nanoTime()
        var checksumAccumulator = 0L
        repeat(120) {
            checksumAccumulator += stateSnapshot.totalBytes
            checksumAccumulator += stateSnapshot.transferredBytes
            checksumAccumulator += (stateSnapshot.overallProgressFraction * 1000).toLong()
            checksumAccumulator += stateSnapshot.totalChunksCount
            checksumAccumulator += stateSnapshot.completedChunksCount
            checksumAccumulator += stateSnapshot.totalFilesOnlyCount
            checksumAccumulator += stateSnapshot.completedFilesOnlyCount
            checksumAccumulator += stateSnapshot.remainingFilesOnlyCount
            checksumAccumulator += stateSnapshot.failedFilesOnlyCount
            checksumAccumulator += (stateSnapshot.activeTransferringFile?.sizeBytes ?: 0L)
            checksumAccumulator += stateSnapshot.standaloneFilesInQueue.size
            checksumAccumulator += stateSnapshot.activeFolderNames.size
            checksumAccumulator += stateSnapshot.pendingTotalBytes
            checksumAccumulator += stateSnapshot.totalSelectedBytesInManager
        }
        val stateBenchTotalMs = (System.nanoTime() - stateBenchStartNs) / 1_000_000.0
        val avgStateReadPer120HzFrameMs = stateBenchTotalMs / 120.0
        assertTrue("Checksums must be positive", checksumAccumulator > 0L && uncachedChecksum > 0L)
        assertTrue(
            "120 frames of derived P2PUiState reads must average well under 1.0ms per frame (actual avg=${String.format(java.util.Locale.US, "%.4f", avgStateReadPer120HzFrameMs)}ms)",
            avgStateReadPer120HzFrameMs < 1.0
        )

        // 5. Real Benchmark: Legacy Lowercase Allocation vs Zero-Allocation Search & Sort on 3,200 files
        val syntheticFiles = (1..3200).map { idx ->
            com.example.model.DeviceMediaItem(
                id = "bench_item_$idx",
                name = if (idx % 25 == 0) "Barq_Release_Package_$idx.apk" else "Document_Report_${3200 - idx}.pdf",
                sizeBytes = (idx * 4096L),
                category = if (idx % 25 == 0) FileCategory.GAME_APK else FileCategory.DOCUMENT,
                dateModifiedMillis = 1_710_000_000_000L + idx * 500L,
                bucketOrFolderName = if (idx % 2 == 0) "Download" else "Documents"
            )
        }
        val query = "Barq_Release"
        val legacyFilterStartNs = System.nanoTime()
        val qLower = query.lowercase(java.util.Locale.ROOT)
        val legacyFiltered = syntheticFiles
            .filter { item ->
                item.name.lowercase(java.util.Locale.ROOT).contains(qLower) ||
                    item.bucketOrFolderName.lowercase(java.util.Locale.ROOT).contains(qLower)
            }
            .sortedBy { it.name.lowercase(java.util.Locale.ROOT) }
        val legacyFilterSortMs = (System.nanoTime() - legacyFilterStartNs) / 1_000_000.0

        val filterSortStartNs = System.nanoTime()
        val filteredAndSorted = syntheticFiles
            .filter { item ->
                item.name.contains(query, ignoreCase = true) ||
                    item.bucketOrFolderName.contains(query, ignoreCase = true)
            }
            .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
        val filterSortMs = (System.nanoTime() - filterSortStartNs) / 1_000_000.0
        assertEquals(legacyFiltered.size, filteredAndSorted.size)
        assertTrue(
            "Zero-allocation search + sort across 3,200 items must complete in < 25ms (actual=${String.format(java.util.Locale.US, "%.2f", filterSortMs)}ms)",
            filterSortMs < 25.0
        )

        // 6. Benchmark Navigation Drawer open/close and multi-screen navigation latency
        val navFrameTimesMs = mutableListOf<Double>()
        val drawerOpenStartNs = System.nanoTime()
        composeTestRule.onNodeWithTag("top_bar_drawer_menu_button").performClick()
        composeTestRule.waitForIdle()
        val drawerOpenMs = (System.nanoTime() - drawerOpenStartNs) / 1_000_000.0
        navFrameTimesMs.add(drawerOpenMs)

        // Navigate to Themes screen from Drawer
        val toThemesStartNs = System.nanoTime()
        composeTestRule.onNodeWithTag("drawer_item_THEMES").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        val toThemesMs = (System.nanoTime() - toThemesStartNs) / 1_000_000.0
        navFrameTimesMs.add(toThemesMs)
        composeTestRule.onNodeWithTag("themes_and_colors_screen").assertExists()

        // 7. Verify Animated Themes switching, background pause, AND foreground resume
        com.example.ui.theme.BarqThemeState.setRespectReduceMotion(context, false)
        com.example.ui.theme.BarqThemeState.setAppForegroundState(true)
        val animSwitchStartNs = System.nanoTime()
        com.example.ui.theme.BarqThemeState.applyAnimatedTheme(
            context,
            com.example.ui.theme.BarqAnimatedThemeId.CYBER_PULSE,
            enableAnimation = true
        )
        composeTestRule.waitForIdle()
        val animSwitchMs = (System.nanoTime() - animSwitchStartNs) / 1_000_000.0
        assertTrue(
            "Animated theme must be active in foreground",
            com.example.ui.theme.BarqThemeState.shouldAnimateActiveTheme(context)
        )
        assertNotNull(
            "liveAnimationPhaseState must be attached when animated theme is running in foreground",
            com.example.ui.theme.BarqThemeState.liveAnimationPhaseState
        )

        // Move app to background -> animations MUST pause immediately and release liveAnimationPhaseState
        com.example.ui.theme.BarqThemeState.setAppForegroundState(false)
        composeTestRule.waitForIdle()
        assertFalse(
            "Theme animation must pause when app moves to background",
            com.example.ui.theme.BarqThemeState.shouldAnimateActiveTheme(context)
        )
        assertEquals(
            "liveAnimationPhaseState must be cleared when app is in background",
            null,
            com.example.ui.theme.BarqThemeState.liveAnimationPhaseState
        )

        // Return app to foreground -> animations MUST resume automatically
        com.example.ui.theme.BarqThemeState.setAppForegroundState(true)
        composeTestRule.waitForIdle()
        assertTrue(
            "Theme animation must resume automatically when app returns to foreground",
            com.example.ui.theme.BarqThemeState.shouldAnimateActiveTheme(context)
        )
        assertNotNull(
            "liveAnimationPhaseState must re-attach automatically upon returning to foreground",
            com.example.ui.theme.BarqThemeState.liveAnimationPhaseState
        )

        com.example.ui.theme.BarqThemeState.resetToDefaultTheme(context)
        composeTestRule.waitForIdle()

        // Navigate back to Home and cycle across bottom tabs (FILES -> IMAGES -> VIDEOS -> APPS -> HOME)
        composeTestRule.onNodeWithTag("navigate_back_button").performClick()
        composeTestRule.waitForIdle()

        val tabsToCycle = listOf("bottom_nav_FILES", "bottom_nav_IMAGES", "bottom_nav_VIDEOS", "bottom_nav_APPS", "bottom_nav_HOME")
        for (tabTag in tabsToCycle) {
            val t0 = System.nanoTime()
            composeTestRule.onNodeWithTag("main_bottom_tabs_row")
                .performScrollToNode(hasTestTag(tabTag))
            composeTestRule.onNodeWithTag(tabTag).performClick()
            composeTestRule.waitForIdle()
            val dtMs = (System.nanoTime() - t0) / 1_000_000.0
            navFrameTimesMs.add(dtMs)
        }

        // 8. Verify memory stability after repeated navigation & theme transitions
        val runtime = Runtime.getRuntime()
        val usedMemMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
        println(
            "BARQ_INTERNAL_PERF_METRICS: " +
                "uncachedState120FramesTotalMs=${String.format(java.util.Locale.US, "%.2f", uncachedTotalMs)}, " +
                "uncachedStateAvgPerFrameMs=${String.format(java.util.Locale.US, "%.4f", uncachedAvgPerFrameMs)}, " +
                "cachedState120FramesTotalMs=${String.format(java.util.Locale.US, "%.2f", stateBenchTotalMs)}, " +
                "cachedStateAvgPerFrameMs=${String.format(java.util.Locale.US, "%.4f", avgStateReadPer120HzFrameMs)}, " +
                "legacySearchSort3200ItemsMs=${String.format(java.util.Locale.US, "%.2f", legacyFilterSortMs)}, " +
                "optimizedSearchSort3200ItemsMs=${String.format(java.util.Locale.US, "%.2f", filterSortMs)}, " +
                "drawerOpenMs=${String.format(java.util.Locale.US, "%.2f", drawerOpenMs)}, " +
                "toThemesMs=${String.format(java.util.Locale.US, "%.2f", toThemesMs)}, " +
                "animSwitchMs=${String.format(java.util.Locale.US, "%.2f", animSwitchMs)}, " +
                "usedMemoryMb=${usedMemMb}MB"
        )
        assertTrue("Heap memory usage must remain bounded and leak-free", usedMemMb < 1024L)
    }
}






