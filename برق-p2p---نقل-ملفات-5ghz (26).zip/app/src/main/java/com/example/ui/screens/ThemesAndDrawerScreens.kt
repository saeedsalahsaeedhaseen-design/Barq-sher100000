package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MotionPhotosOn
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SortByAlpha
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppScreen
import com.example.model.ChunkSizeOption
import com.example.model.TransportMode
import com.example.ui.components.CopyrightFooter
import com.example.ui.theme.AnimatedThemeAmbientOverlay
import com.example.ui.theme.BarqAnimatedThemeId
import com.example.ui.theme.BarqAnimatedThemes
import com.example.ui.theme.BarqAnimationSpeed
import com.example.ui.theme.BarqThemeBrightnessMode
import com.example.ui.theme.BarqThemeId
import com.example.ui.theme.BarqThemePalette
import com.example.ui.theme.BarqThemePalettes
import com.example.ui.theme.BarqThemeState
import com.example.ui.theme.CoralRose
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.HotspotAmber
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightCard
import com.example.ui.theme.MidnightCardElevated
import com.example.ui.theme.MidnightSurface
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.OnPrimaryAccent
import com.example.ui.theme.RoyalViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.adaptPaletteForBrightness
import com.example.ui.theme.blendColors
import com.example.ui.theme.highContrastTextFor
import com.example.viewmodel.P2PUiState
import java.util.Locale

/**
 * Extensible Navigation Drawer Item model so future drawer items can be appended
 * without redesigning or rewriting the drawer layout.
 */
@Immutable
data class BarqDrawerMenuItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accentColor: Color,
    val badgeText: String? = null,
    val targetScreen: AppScreen? = null,
    val onCustomClick: (() -> Unit)? = null
)

fun buildDefaultBarqDrawerItems(
    uiState: P2PUiState,
    onNavigateScreen: (AppScreen) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenAbout: () -> Unit,
    extraItems: List<BarqDrawerMenuItem> = emptyList()
): List<BarqDrawerMenuItem> {
    val activePeersCount = uiState.discoveredPeers.size + uiState.bluetoothPeers.count { it.isPaired }
    val activeThemeBadge = if (BarqThemeState.selectedAnimatedThemeId != BarqAnimatedThemeId.NONE) {
        BarqThemeState.selectedAnimatedThemeId.englishTitle
    } else {
        BarqThemeState.selectedThemeId.englishTitle
    }

    val coreItems = listOf(
        BarqDrawerMenuItem(
            id = "HOME",
            title = "الرئيسية",
            subtitle = "لوحة التحكم السريعة وحالة الشبكة",
            icon = Icons.Filled.Home,
            accentColor = ElectricCyan,
            targetScreen = AppScreen.HOME,
            onCustomClick = { onNavigateScreen(AppScreen.HOME) }
        ),
        BarqDrawerMenuItem(
            id = "FILES",
            title = "مدير الملفات",
            subtitle = "المجلدات والملفات بجميع الصيغ والأحجام",
            icon = Icons.Filled.Folder,
            accentColor = HotspotAmber,
            badgeText = "${uiState.storageFolders.size} مجلد",
            targetScreen = AppScreen.FILES,
            onCustomClick = { onNavigateScreen(AppScreen.FILES) }
        ),
        BarqDrawerMenuItem(
            id = "SEND_RECEIVE",
            title = "إرسال واستقبال",
            subtitle = "نقل الملفات والمجلدات والتطبيقات بسرعة فائقة",
            icon = Icons.Filled.SwapHoriz,
            accentColor = NeonEmerald,
            badgeText = if (uiState.files.isNotEmpty()) "${uiState.files.size} ملف" else null,
            targetScreen = AppScreen.SEND,
            onCustomClick = { onNavigateScreen(AppScreen.SEND) }
        ),
        BarqDrawerMenuItem(
            id = "DEVICES_SESSIONS",
            title = "الأجهزة والجلسات",
            subtitle = if (uiState.isTransferRunning || uiState.isSenderReady) {
                "جلسة نشطة (${uiState.connectionCode}) • إدارة الاتصال والأجهزة"
            } else {
                "اكتشاف الأجهزة القريبة، البلوتوث، وربط الجلسات"
            },
            icon = Icons.Filled.Devices,
            accentColor = RoyalViolet,
            badgeText = when {
                uiState.isTransferRunning -> "نقل حي"
                activePeersCount > 0 -> "$activePeersCount جهاز"
                else -> uiState.connectionCode
            },
            targetScreen = if (uiState.isTransferRunning) AppScreen.LIVE_TRANSFER else AppScreen.RECEIVE,
            onCustomClick = {
                if (uiState.isTransferRunning) {
                    onNavigateScreen(AppScreen.LIVE_TRANSFER)
                } else {
                    onNavigateScreen(AppScreen.RECEIVE)
                }
            }
        ),
        BarqDrawerMenuItem(
            id = "HISTORY",
            title = "سجل النقل",
            subtitle = "الملفات المرسلة والمستلمة مع التحقق SHA-256",
            icon = Icons.Filled.History,
            accentColor = ElectricCyan,
            badgeText = if (uiState.transferHistory.isNotEmpty()) "${uiState.transferHistory.size}" else null,
            targetScreen = AppScreen.HISTORY,
            onCustomClick = { onNavigateScreen(AppScreen.HISTORY) }
        ),
        BarqDrawerMenuItem(
            id = "THEMES",
            title = "الثيمات والألوان",
            subtitle = "27 ثيماً ثابتاً ومخصصاً + 10 ثيمات متحركة احترافية",
            icon = Icons.Filled.Palette,
            accentColor = CoralRose,
            badgeText = activeThemeBadge,
            targetScreen = AppScreen.THEMES,
            onCustomClick = { onNavigateScreen(AppScreen.THEMES) }
        ),
        BarqDrawerMenuItem(
            id = "SETTINGS",
            title = "الإعدادات",
            subtitle = "حجم الدفعات، وضع النقل، الصلاحيات، واتجاه الواجهة",
            icon = Icons.Filled.Settings,
            accentColor = HotspotAmber,
            targetScreen = null,
            onCustomClick = onOpenSettings
        ),
        BarqDrawerMenuItem(
            id = "ABOUT",
            title = "حول برق",
            subtitle = "معلومات النظام، البروتوكول، ومشاركة حزمة التطبيق",
            icon = Icons.Filled.Info,
            accentColor = NeonEmerald,
            targetScreen = null,
            onCustomClick = onOpenAbout
        )
    )
    return coreItems + extraItems
}

/**
 * Top Application Bar with Single Hamburger Menu Button (☰), Current Screen Title,
 * Active Session Badge, and Quick Theme Switcher Button.
 * Automatically adapts to RTL (Arabic) and LTR (English) via LocalLayoutDirection.
 */
@Composable
fun BarqMainTopAppBar(
    uiState: P2PUiState,
    onOpenDrawer: () -> Unit,
    onOpenThemes: () -> Unit,
    onOpenLiveTransfer: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MidnightSurface,
        tonalElevation = 4.dp,
        modifier = modifier
            .fillMaxWidth()
            .border(width = 0.5.dp, color = GlassBorder.copy(alpha = 0.6f))
            .testTag("barq_main_top_app_bar")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                IconButton(
                    onClick = onOpenDrawer,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MidnightCard)
                        .border(1.dp, ElectricCyan.copy(alpha = 0.55f), RoundedCornerShape(14.dp))
                        .testTag("top_bar_drawer_menu_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Menu,
                        contentDescription = "فتح القائمة الجانبية ☰",
                        tint = ElectricCyan,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Bolt,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "برق P2P • ${uiState.currentScreen.arabicTabTitle}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = "الكود: ${uiState.connectionCode} • ${uiState.networkStatus.localIp}:${uiState.networkStatus.port}",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 11.sp,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (uiState.isTransferRunning || uiState.isSenderReady) {
                    Surface(
                        color = NeonEmerald.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(999.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .clickable { onOpenLiveTransfer() }
                            .border(1.dp, NeonEmerald, RoundedCornerShape(999.dp))
                            .testTag("top_bar_active_session_pill")
                    ) {
                        Text(
                            text = if (uiState.isTransferRunning) "⚡ نقل جارٍ" else "📡 جلسة نشطة",
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonEmerald,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                IconButton(
                    onClick = onOpenThemes,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MidnightCard)
                        .border(1.dp, GlassBorder, RoundedCornerShape(14.dp))
                        .testTag("top_bar_themes_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Palette,
                        contentDescription = "الثيمات والألوان",
                        tint = HotspotAmber,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}

/**
 * Professional Navigation Drawer Sheet supporting RTL (opens from right in Arabic)
 * and LTR (opens from left in English), linked directly to real screens in Barq P2P.
 */
@Composable
fun BarqNavigationDrawerSheet(
    uiState: P2PUiState,
    drawerItems: List<BarqDrawerMenuItem>,
    onCloseDrawer: () -> Unit,
    onNavigateToScreen: (AppScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val activeThemeLabel = if (BarqThemeState.selectedAnimatedThemeId != BarqAnimatedThemeId.NONE) {
        "${BarqThemeState.selectedAnimatedThemeId.englishTitle} (متحرك)"
    } else {
        BarqThemeState.selectedThemeId.englishTitle
    }

    ModalDrawerSheet(
        drawerContainerColor = MidnightSurface,
        drawerContentColor = TextPrimary,
        modifier = modifier
            .widthIn(min = 290.dp, max = 340.dp)
            .fillMaxHeight()
            .testTag("barq_navigation_drawer_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 14.dp, vertical = 14.dp)
        ) {
            // Drawer Header Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                ElectricCyan.copy(alpha = 0.22f),
                                MidnightCard,
                                NeonEmerald.copy(alpha = 0.18f)
                            )
                        )
                    )
                    .border(1.2.dp, ElectricCyan.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(ElectricCyan.copy(alpha = 0.2f))
                                    .border(1.dp, ElectricCyan, RoundedCornerShape(14.dp))
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Bolt,
                                    contentDescription = "شعار برق",
                                    tint = ElectricCyan,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "برق P2P • Barq sher",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "الثيم النشط: $activeThemeLabel",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ElectricCyan
                                )
                            }
                        }

                        IconButton(
                            onClick = onCloseDrawer,
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(MidnightCardElevated)
                                .testTag("close_drawer_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "إغلاق القائمة الجانبية",
                                tint = TextPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "IP: ${uiState.networkStatus.localIp}:${uiState.networkStatus.port}",
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                        Surface(
                            color = NeonEmerald.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(999.dp)
                        ) {
                            Text(
                                text = uiState.connectionCode,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = NeonEmerald,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Extensible Drawer Items List
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                drawerItems.forEach { item ->
                    val isSelected = item.targetScreen != null && (
                        uiState.currentScreen == item.targetScreen ||
                            (item.id == "SEND_RECEIVE" && (uiState.currentScreen == AppScreen.SEND || uiState.currentScreen == AppScreen.RECEIVE))
                        )

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                if (isSelected) item.accentColor.copy(alpha = 0.16f) else MidnightCard
                            )
                            .border(
                                width = if (isSelected) 1.4.dp else 1.dp,
                                color = if (isSelected) item.accentColor else GlassBorder.copy(alpha = 0.7f),
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable {
                                item.onCustomClick?.invoke() ?: item.targetScreen?.let { onNavigateToScreen(it) }
                            }
                            .padding(horizontal = 12.dp, vertical = 11.dp)
                            .testTag("drawer_item_${item.id}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(11.dp))
                                        .background(item.accentColor.copy(alpha = 0.18f))
                                ) {
                                    Icon(
                                        imageVector = item.icon,
                                        contentDescription = item.title,
                                        tint = item.accentColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) item.accentColor else TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = item.subtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontSize = 11.sp,
                                        color = TextSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            item.badgeText?.let { badge ->
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = item.accentColor.copy(alpha = 0.18f),
                                    shape = RoundedCornerShape(999.dp)
                                ) {
                                    Text(
                                        text = badge,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = item.accentColor,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }

                        if (item.id == "SEND_RECEIVE") {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedButton(
                                    onClick = { onNavigateToScreen(AppScreen.SEND) },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(34.dp)
                                        .testTag("drawer_sub_send_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.CloudUpload,
                                        contentDescription = null,
                                        tint = ElectricCyan,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "شاشة الإرسال",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                OutlinedButton(
                                    onClick = { onNavigateToScreen(AppScreen.RECEIVE) },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(34.dp)
                                        .testTag("drawer_sub_receive_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.CloudDownload,
                                        contentDescription = null,
                                        tint = NeonEmerald,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "شاشة الاستلام",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = GlassBorder.copy(alpha = 0.6f))
            Spacer(modifier = Modifier.height(10.dp))

            // Quick RTL / LTR Direction Toggle in Drawer Footer
            val context = LocalContext.current
            val isRtl = BarqThemeState.layoutDirection == LayoutDirection.Rtl
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MidnightCard)
                    .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
                    .clickable {
                        val nextDir = if (isRtl) LayoutDirection.Ltr else LayoutDirection.Rtl
                        BarqThemeState.setLayoutDirectionMode(context, nextDir)
                    }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .testTag("drawer_toggle_direction_button")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Language,
                        contentDescription = null,
                        tint = ElectricCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isRtl) "اتجاه الواجهة: العربية (RTL - يمين)" else "Direction: English (LTR - Left)",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextPrimary
                    )
                }
                Text(
                    text = if (isRtl) "تبديل LTR" else "Switch RTL",
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricCyan,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

private enum class ThemeBrowserSection(val arabicLabel: String, val englishLabel: String) {
    ALL("الكل", "All"),
    STATIC("ثابتة (26)", "Static"),
    ANIMATED("متحركة (10)", "Animated"),
    CUSTOM("مخصص", "Custom")
}

private enum class StaticThemeFilter(val arabicLabel: String) {
    ALL("جميع الثيمات"),
    DARK("الداكنة فقط"),
    LIGHT("الفاتحة فقط")
}

/**
 * Comprehensive "الثيمات والألوان" (Themes & Colors) Screen supporting:
 * - 26 Static Themes (8 original + 18 new)
 * - 10 Animated Themes with Speed Control (Slow, Medium, Fast), Enable/Disable, and Reduce Motion support
 * - Full 7-Channel Custom Theme Studio (Primary, Secondary, Background, Cards, Buttons, Text, Borders)
 * - Real-time Live Preview before applying, Search, Filtering, Sorting, and Light/Dark/Auto modes.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ThemesAndColorsScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val systemDark = isSystemInDarkTheme()
    val scrollState = rememberScrollState()

    var selectedSection by remember { mutableStateOf(ThemeBrowserSection.ALL) }
    var staticFilter by remember { mutableStateOf(StaticThemeFilter.ALL) }
    var sortAlphabetically by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    var previewedThemeId by remember(BarqThemeState.selectedThemeId) {
        mutableStateOf(BarqThemeState.selectedThemeId)
    }
    var previewedAnimatedId by remember(BarqThemeState.selectedAnimatedThemeId) {
        mutableStateOf(BarqThemeState.selectedAnimatedThemeId)
    }

    var customPrimaryDraft by remember(BarqThemeState.customPrimaryColor) {
        mutableStateOf(BarqThemeState.customPrimaryColor)
    }
    var customSecondaryDraft by remember(BarqThemeState.customSecondaryColor) {
        mutableStateOf(BarqThemeState.customSecondaryColor)
    }
    var customBgDraft by remember(BarqThemeState.customBackgroundColor) {
        mutableStateOf(BarqThemeState.customBackgroundColor)
    }
    var customCardDraft by remember(BarqThemeState.customCardColor) {
        mutableStateOf(BarqThemeState.customCardColor)
    }
    var customButtonDraft by remember(BarqThemeState.customButtonColor) {
        mutableStateOf(BarqThemeState.customButtonColor)
    }
    var customTextDraft by remember(BarqThemeState.customTextColor) {
        mutableStateOf(BarqThemeState.customTextColor)
    }
    var customBorderDraft by remember(BarqThemeState.customBorderColor) {
        mutableStateOf(BarqThemeState.customBorderColor)
    }
    var customIsLightDraft by remember(BarqThemeState.customIsLight) {
        mutableStateOf(BarqThemeState.customIsLight)
    }

    // Local preview animation phase when previewing an animated theme before applying
    val isPreviewingAnimated = previewedAnimatedId != BarqAnimatedThemeId.NONE
    val isSystemReduceMotion = remember(context) {
        BarqThemeState.isSystemReduceMotionActive(context)
    }
    val canRunPreviewAnim = isPreviewingAnimated &&
        BarqThemeState.isThemeAnimationEnabled &&
        BarqThemeState.isAppInForeground &&
        !(BarqThemeState.respectSystemReduceMotion && isSystemReduceMotion)

    val previewPhaseState: State<Float> = if (canRunPreviewAnim) {
        val previewTransition = rememberInfiniteTransition(label = "preview_anim_transition")
        previewTransition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(
                    durationMillis = BarqThemeState.animationSpeed.cycleDurationMillis,
                    easing = LinearEasing
                ),
                repeatMode = RepeatMode.Restart
            ),
            label = "preview_phase_float"
        )
    } else {
        remember { mutableFloatStateOf(0f) }
    }

    val quantizedPreviewPhase by remember(canRunPreviewAnim) {
        derivedStateOf {
            if (!canRunPreviewAnim) {
                0f
            } else {
                val p = previewPhaseState.value
                ((p * 20f).toInt().coerceIn(0, 20)) / 20f
            }
        }
    }

    val rawPreviewPalette: BarqThemePalette = remember(
        previewedThemeId,
        previewedAnimatedId,
        quantizedPreviewPhase,
        customPrimaryDraft,
        customSecondaryDraft,
        customBgDraft,
        customCardDraft,
        customButtonDraft,
        customTextDraft,
        customBorderDraft,
        customIsLightDraft
    ) {
        if (previewedAnimatedId != BarqAnimatedThemeId.NONE) {
            BarqAnimatedThemes.resolveAnimatedPalette(previewedAnimatedId, quantizedPreviewPhase)
        } else {
            BarqThemePalettes.forThemeId(
                themeId = previewedThemeId,
                customPrimary = customPrimaryDraft,
                customSecondary = customSecondaryDraft,
                customBackground = customBgDraft,
                customIsLight = customIsLightDraft,
                customCard = customCardDraft,
                customButton = customButtonDraft,
                customText = customTextDraft,
                customBorder = customBorderDraft
            )
        }
    }

    val previewPalette = remember(rawPreviewPalette, BarqThemeState.brightnessMode) {
        when (BarqThemeState.brightnessMode) {
            BarqThemeBrightnessMode.THEME_DEFAULT -> rawPreviewPalette
            BarqThemeBrightnessMode.DARK -> adaptPaletteForBrightness(rawPreviewPalette, targetIsLight = false)
            BarqThemeBrightnessMode.LIGHT -> adaptPaletteForBrightness(rawPreviewPalette, targetIsLight = true)
        }
    }

    val filteredAnimatedThemes = remember(searchQuery, sortAlphabetically) {
        val q = searchQuery.trim()
        val base = if (q.isEmpty()) {
            BarqAnimatedThemeId.animatedPresets
        } else {
            BarqAnimatedThemeId.animatedPresets.filter { item ->
                item.englishTitle.contains(q, ignoreCase = true) ||
                    item.arabicTitle.contains(q, ignoreCase = true) ||
                    item.subtitle.contains(q, ignoreCase = true)
            }
        }
        if (sortAlphabetically) base.sortedBy { it.englishTitle } else base
    }

    val filteredStaticThemes = remember(searchQuery, staticFilter, sortAlphabetically) {
        val q = searchQuery.trim()
        val base = BarqThemeId.entries.filter { item ->
            val matchesQuery = q.isEmpty() ||
                item.englishTitle.contains(q, ignoreCase = true) ||
                item.arabicTitle.contains(q, ignoreCase = true) ||
                item.subtitle.contains(q, ignoreCase = true)
            val matchesBrightness = when (staticFilter) {
                StaticThemeFilter.ALL -> true
                StaticThemeFilter.DARK -> !item.isLightByDefault
                StaticThemeFilter.LIGHT -> item.isLightByDefault
            }
            matchesQuery && matchesBrightness
        }
        if (sortAlphabetically) base.sortedBy { it.englishTitle } else base
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("themes_and_colors_screen")
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            ScreenTopBar(
                title = "الثيمات والألوان • Themes",
                subtitle = "26 ثيماً ثابتاً + 10 ثيمات متحركة + استوديو تخصيص كامل",
                accentColor = ElectricCyan,
                onBack = onBack
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 1. Live Interactive Preview Card (معاينة الثيم المباشرة قبل اعتماده)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(previewPalette.background)
                    .border(2.dp, previewPalette.primaryAccent, RoundedCornerShape(22.dp))
                    .testTag("theme_live_preview_card")
            ) {
                if (previewedAnimatedId != BarqAnimatedThemeId.NONE) {
                    AnimatedThemeAmbientOverlay(
                        animatedThemeId = previewedAnimatedId,
                        phase = 0f,
                        palette = previewPalette,
                        modifier = Modifier.matchParentSize(),
                        intensityAlpha = 0.30f,
                        phaseProvider = { previewPhaseState.value }
                    )
                }

                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (isPreviewingAnimated) Icons.Filled.AutoAwesome else Icons.Filled.Visibility,
                                contentDescription = null,
                                tint = previewPalette.primaryAccent,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            val previewTitle = if (isPreviewingAnimated) {
                                "معاينة متحركة: ${previewedAnimatedId.englishTitle} (${previewedAnimatedId.arabicTitle})"
                            } else {
                                "معاينة الثيم: ${previewedThemeId.englishTitle} (${previewedThemeId.arabicTitle})"
                            }
                            Text(
                                text = previewTitle,
                                style = MaterialTheme.typography.labelLarge,
                                color = previewPalette.textPrimary,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.testTag("previewed_theme_title_text")
                            )
                        }

                        Surface(
                            color = previewPalette.secondaryAccent.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(999.dp)
                        ) {
                            val ratioStr = String.format(Locale.US, "%.1f:1", previewPalette.contrastRatioPrimaryText)
                            Text(
                                text = "تباين $ratioStr ✓",
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = previewPalette.secondaryAccent,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Simulated App Surface & Card inside Preview
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(previewPalette.card)
                            .border(1.dp, previewPalette.border, RoundedCornerShape(16.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(previewPalette.primaryAccent.copy(alpha = 0.18f))
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Bolt,
                                            contentDescription = null,
                                            tint = previewPalette.primaryAccent,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "نقل ملفات برق المباشر (P2P)",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = previewPalette.textPrimary
                                        )
                                        Text(
                                            text = "السرعة: 48.5 MB/s • التحقق SHA-256 نشط",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = previewPalette.textSecondary
                                        )
                                    }
                                }

                                Surface(
                                    color = previewPalette.tertiaryAccent,
                                    shape = RoundedCornerShape(999.dp)
                                ) {
                                    Text(
                                        text = if (isPreviewingAnimated) "Animated" else "5GHz Turbo",
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        color = previewPalette.onTertiaryAccent,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            LinearProgressIndicator(
                                progress = { 0.72f },
                                color = previewPalette.primaryAccent,
                                trackColor = previewPalette.surface,
                                strokeCap = StrokeCap.Round,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            val isAlreadyApplied = if (isPreviewingAnimated) {
                                BarqThemeState.selectedAnimatedThemeId == previewedAnimatedId
                            } else {
                                BarqThemeState.selectedAnimatedThemeId == BarqAnimatedThemeId.NONE &&
                                    BarqThemeState.selectedThemeId == previewedThemeId &&
                                    !BarqThemeState.autoSystemDarkLightMode
                            }

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Button(
                                    onClick = {
                                        if (isPreviewingAnimated) {
                                            BarqThemeState.applyAnimatedTheme(context, previewedAnimatedId)
                                        } else if (previewedThemeId == BarqThemeId.CUSTOM) {
                                            BarqThemeState.updateCustomTheme(
                                                context = context,
                                                primary = customPrimaryDraft,
                                                secondary = customSecondaryDraft,
                                                background = customBgDraft,
                                                isLight = customIsLightDraft,
                                                card = customCardDraft,
                                                button = customButtonDraft,
                                                text = customTextDraft,
                                                border = customBorderDraft,
                                                applyImmediately = true
                                            )
                                        } else {
                                            BarqThemeState.applyTheme(context, previewedThemeId)
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = previewPalette.buttonColor),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(42.dp)
                                        .testTag("apply_previewed_theme_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.CheckCircle,
                                        contentDescription = null,
                                        tint = previewPalette.onButtonColor,
                                        modifier = Modifier.size(17.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    val btnTitle = when {
                                        isAlreadyApplied -> "الثيم مطبق حالياً ✓"
                                        isPreviewingAnimated -> "تطبيق الثيم المتحرك (${previewedAnimatedId.englishTitle})"
                                        else -> "تطبيق هذا الثيم (${previewedThemeId.englishTitle})"
                                    }
                                    Text(
                                        text = btnTitle,
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = previewPalette.onButtonColor,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 2. Auto System Mode Toggle + Reset to Default Theme Row
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .weight(1.35f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MidnightCard)
                        .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = if (systemDark) Icons.Filled.DarkMode else Icons.Filled.LightMode,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "وضع تلقائي مع الهاتف",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "يتبع الوضع الفاتح والداكن للنظام",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                color = TextSecondary
                            )
                        }
                    }
                    Switch(
                        checked = BarqThemeState.autoSystemDarkLightMode,
                        onCheckedChange = { enabled ->
                            BarqThemeState.setAutoSystemMode(context, enabled, systemDark)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = OnPrimaryAccent,
                            checkedTrackColor = ElectricCyan
                        ),
                        modifier = Modifier.testTag("auto_system_theme_switch")
                    )
                }

                OutlinedButton(
                    onClick = {
                        BarqThemeState.resetToDefaultTheme(context)
                        previewedThemeId = BarqThemeId.MIDNIGHT_BLUE
                        previewedAnimatedId = BarqAnimatedThemeId.NONE
                        customPrimaryDraft = BarqThemeState.customPrimaryColor
                        customSecondaryDraft = BarqThemeState.customSecondaryColor
                        customBgDraft = BarqThemeState.customBackgroundColor
                        customCardDraft = BarqThemeState.customCardColor
                        customButtonDraft = BarqThemeState.customButtonColor
                        customTextDraft = BarqThemeState.customTextColor
                        customBorderDraft = BarqThemeState.customBorderColor
                        customIsLightDraft = BarqThemeState.customIsLight
                    },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(58.dp)
                        .testTag("reset_default_theme_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Restore,
                        contentDescription = "استعادة الافتراضي",
                        tint = HotspotAmber,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "استعادة الافتراضي",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 2b. Light / Dark / Default Brightness Mode Selector Row
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                BarqThemeBrightnessMode.entries.forEach { mode ->
                    val isSelected = !BarqThemeState.autoSystemDarkLightMode && BarqThemeState.brightnessMode == mode
                    Surface(
                        color = if (isSelected) ElectricCyan.copy(alpha = 0.2f) else MidnightCard,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) ElectricCyan else GlassBorder
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                BarqThemeState.setThemeBrightnessMode(context, mode, systemDark)
                            }
                            .testTag("brightness_mode_${mode.storageKey}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp)
                        ) {
                            Icon(
                                imageVector = when (mode) {
                                    BarqThemeBrightnessMode.THEME_DEFAULT -> Icons.Filled.Palette
                                    BarqThemeBrightnessMode.DARK -> Icons.Filled.DarkMode
                                    BarqThemeBrightnessMode.LIGHT -> Icons.Filled.LightMode
                                },
                                contentDescription = null,
                                tint = if (isSelected) ElectricCyan else TextSecondary,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = mode.arabicLabel,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) ElectricCyan else TextPrimary,
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 3. Search Bar + Sort & Category Filter Tabs
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            text = "ابحث عن ثيم بالاسم أو اللون (مثل Arctic, Galaxy, شفق, ذهبي)...",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Filled.Search,
                            contentDescription = "بحث",
                            tint = ElectricCyan
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Filled.Close,
                                    contentDescription = "مسح البحث",
                                    tint = TextSecondary
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricCyan,
                        unfocusedBorderColor = GlassBorder,
                        focusedContainerColor = MidnightCard,
                        unfocusedContainerColor = MidnightCard,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("theme_search_input")
                )

                IconButton(
                    onClick = { sortAlphabetically = !sortAlphabetically },
                    modifier = Modifier
                        .size(50.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (sortAlphabetically) ElectricCyan.copy(alpha = 0.2f) else MidnightCard)
                        .border(
                            1.dp,
                            if (sortAlphabetically) ElectricCyan else GlassBorder,
                            RoundedCornerShape(14.dp)
                        )
                        .testTag("theme_sort_toggle_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.SortByAlpha,
                        contentDescription = "ترتيب أبجدي",
                        tint = if (sortAlphabetically) ElectricCyan else TextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Section Selector Tabs (ALL / STATIC / ANIMATED / CUSTOM)
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("theme_category_filter_row")
            ) {
                ThemeBrowserSection.entries.forEach { sec ->
                    val selected = selectedSection == sec
                    Surface(
                        color = if (selected) ElectricCyan.copy(alpha = 0.2f) else MidnightCard,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            width = if (selected) 1.5.dp else 1.dp,
                            color = if (selected) ElectricCyan else GlassBorder
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { selectedSection = sec }
                            .testTag("theme_category_${sec.name}")
                    ) {
                        Text(
                            text = sec.arabicLabel,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            color = if (selected) ElectricCyan else TextPrimary,
                            maxLines = 1,
                            modifier = Modifier
                                .padding(vertical = 8.dp, horizontal = 6.dp)
                                .align(Alignment.CenterVertically)
                        )
                    }
                }
            }

            // =========================================================================
            // SECTION A: ANIMATED THEMES (الثيمات المتحركة) + ANIMATION CONTROLS
            // =========================================================================
            if (selectedSection == ThemeBrowserSection.ALL || selectedSection == ThemeBrowserSection.ANIMATED) {
                Spacer(modifier = Modifier.height(16.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("animated_themes_section")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.MotionPhotosOn,
                                contentDescription = null,
                                tint = ElectricCyan,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "الثيمات المتحركة • Animated Themes (${filteredAnimatedThemes.size})",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "تدرجات وحركات لونية ناعمة مع توقف تلقائي بالخلفية لتوفير البطارية",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Animated Theme Control Panel (Enable/Disable, Speed, Reduce Motion)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(MidnightCard)
                            .border(1.dp, ElectricCyan.copy(alpha = 0.5f), RoundedCornerShape(18.dp))
                            .padding(12.dp)
                            .testTag("animated_theme_controls_card")
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.AutoAwesome,
                                        contentDescription = null,
                                        tint = NeonEmerald,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "تفعيل حركة الثيمات المتحركة",
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        )
                                        Text(
                                            text = if (BarqThemeState.isThemeAnimationEnabled) {
                                                "الحركة نشطة في الواجهة وتتوقف تلقائياً بالخلفية"
                                            } else {
                                                "الحركة متوقفة حالياً (توفير أقصى للطاقة)"
                                            },
                                            style = MaterialTheme.typography.labelSmall,
                                            fontSize = 10.sp,
                                            color = TextSecondary
                                        )
                                    }
                                }
                                Switch(
                                    checked = BarqThemeState.isThemeAnimationEnabled,
                                    onCheckedChange = { enabled ->
                                        BarqThemeState.setThemeAnimationEnabled(context, enabled)
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = OnPrimaryAccent,
                                        checkedTrackColor = NeonEmerald
                                    ),
                                    modifier = Modifier.testTag("animated_theme_enable_switch")
                                )
                            }

                            // Speed Selector (Slow / Medium / Fast)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Filled.Speed,
                                        contentDescription = null,
                                        tint = HotspotAmber,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "سرعة الحركة:",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    BarqAnimationSpeed.entries.forEach { spd ->
                                        val isSpdSelected = BarqThemeState.animationSpeed == spd
                                        Surface(
                                            color = if (isSpdSelected) HotspotAmber.copy(alpha = 0.22f) else MidnightSurface,
                                            shape = RoundedCornerShape(10.dp),
                                            border = androidx.compose.foundation.BorderStroke(
                                                width = if (isSpdSelected) 1.5.dp else 1.dp,
                                                color = if (isSpdSelected) HotspotAmber else GlassBorder
                                            ),
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(10.dp))
                                                .clickable {
                                                    BarqThemeState.setThemeAnimationSpeed(context, spd)
                                                }
                                                .testTag("anim_speed_${spd.storageKey}")
                                        ) {
                                            Text(
                                                text = "${spd.arabicLabel} (${spd.englishLabel})",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = if (isSpdSelected) FontWeight.Bold else FontWeight.Normal,
                                                color = if (isSpdSelected) HotspotAmber else TextPrimary,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            // Respect System Reduce Motion Toggle
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "احترام إعداد تقليل الحركة في النظام (Reduce Motion)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                    modifier = Modifier.weight(1f)
                                )
                                Switch(
                                    checked = BarqThemeState.respectSystemReduceMotion,
                                    onCheckedChange = { respect ->
                                        BarqThemeState.setRespectReduceMotion(context, respect)
                                    },
                                    modifier = Modifier.testTag("respect_reduce_motion_switch")
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        filteredAnimatedThemes.forEach { animTheme ->
                            val isApplied = BarqThemeState.selectedAnimatedThemeId == animTheme
                            val isPreviewed = previewedAnimatedId == animTheme
                            val keyframes = remember(animTheme) {
                                BarqAnimatedThemes.keyframesFor(animTheme)
                            }

                            AnimatedThemeOptionCard(
                                animatedThemeId = animTheme,
                                keyframes = keyframes,
                                isApplied = isApplied,
                                isPreviewed = isPreviewed,
                                onPreview = {
                                    previewedAnimatedId = animTheme
                                    previewedThemeId = animTheme.baseThemeId
                                },
                                onApply = {
                                    previewedAnimatedId = animTheme
                                    previewedThemeId = animTheme.baseThemeId
                                    BarqThemeState.applyAnimatedTheme(context, animTheme, enableAnimation = true)
                                }
                            )
                        }
                    }
                }
            }

            // =========================================================================
            // SECTION B: STATIC THEMES (الثيمات الثابتة والمخصصة - 27 ثيماً)
            // =========================================================================
            if (selectedSection == ThemeBrowserSection.ALL || selectedSection == ThemeBrowserSection.STATIC) {
                Spacer(modifier = Modifier.height(16.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("static_themes_section")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    ) {
                        Text(
                            text = "الثيمات الاحترافية المتوفرة (${filteredStaticThemes.size} ثيم)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            StaticThemeFilter.entries.forEach { filterOption ->
                                val selected = staticFilter == filterOption
                                Surface(
                                    color = if (selected) ElectricCyan.copy(alpha = 0.18f) else MidnightCard,
                                    shape = RoundedCornerShape(8.dp),
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (selected) ElectricCyan else GlassBorder
                                    ),
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { staticFilter = filterOption }
                                        .testTag("static_filter_${filterOption.name}")
                                ) {
                                    Text(
                                        text = filterOption.arabicLabel,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 10.sp,
                                        color = if (selected) ElectricCyan else TextSecondary,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        filteredStaticThemes.forEach { themeItem ->
                            key(themeItem) {
                                val itemPalette = if (themeItem == BarqThemeId.CUSTOM) {
                                    remember(
                                        customPrimaryDraft,
                                        customSecondaryDraft,
                                        customBgDraft,
                                        customIsLightDraft,
                                        customCardDraft,
                                        customButtonDraft,
                                        customTextDraft,
                                        customBorderDraft
                                    ) {
                                        BarqThemePalettes.forThemeId(
                                            themeId = themeItem,
                                            customPrimary = customPrimaryDraft,
                                            customSecondary = customSecondaryDraft,
                                            customBackground = customBgDraft,
                                            customIsLight = customIsLightDraft,
                                            customCard = customCardDraft,
                                            customButton = customButtonDraft,
                                            customText = customTextDraft,
                                            customBorder = customBorderDraft
                                        )
                                    }
                                } else {
                                    remember(themeItem) {
                                        BarqThemePalettes.forThemeId(themeId = themeItem)
                                    }
                                }
                                val isCurrentlyApplied =
                                    BarqThemeState.selectedAnimatedThemeId == BarqAnimatedThemeId.NONE &&
                                        BarqThemeState.selectedThemeId == themeItem &&
                                        !BarqThemeState.autoSystemDarkLightMode
                                val isCurrentlyPreviewed =
                                    previewedAnimatedId == BarqAnimatedThemeId.NONE &&
                                        previewedThemeId == themeItem

                                ThemeOptionCard(
                                    themeId = themeItem,
                                    palette = itemPalette,
                                    isApplied = isCurrentlyApplied,
                                    isPreviewed = isCurrentlyPreviewed,
                                    onPreview = {
                                        previewedAnimatedId = BarqAnimatedThemeId.NONE
                                        previewedThemeId = themeItem
                                    },
                                    onApply = {
                                        previewedAnimatedId = BarqAnimatedThemeId.NONE
                                        previewedThemeId = themeItem
                                        if (themeItem == BarqThemeId.CUSTOM) {
                                            BarqThemeState.updateCustomTheme(
                                                context = context,
                                                primary = customPrimaryDraft,
                                                secondary = customSecondaryDraft,
                                                background = customBgDraft,
                                                isLight = customIsLightDraft,
                                                card = customCardDraft,
                                                button = customButtonDraft,
                                                text = customTextDraft,
                                                border = customBorderDraft,
                                                applyImmediately = true
                                            )
                                        } else {
                                            BarqThemeState.applyTheme(context, themeItem)
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // =========================================================================
            // SECTION C: FULL 7-CHANNEL CUSTOM THEME STUDIO (تطوير الثيم المخصص)
            // =========================================================================
            if (selectedSection == ThemeBrowserSection.ALL || selectedSection == ThemeBrowserSection.CUSTOM) {
                Spacer(modifier = Modifier.height(16.dp))

                CustomColorPickerPanel(
                    primaryColor = customPrimaryDraft,
                    secondaryColor = customSecondaryDraft,
                    backgroundColor = customBgDraft,
                    cardColor = customCardDraft,
                    buttonColor = customButtonDraft,
                    textColor = customTextDraft,
                    borderColor = customBorderDraft,
                    isLightMode = customIsLightDraft,
                    onColorsChanged = { newPrim, newSec, newBg, newCard, newBtn, newTxt, newBrd, newLight ->
                        customPrimaryDraft = newPrim
                        customSecondaryDraft = newSec
                        customBgDraft = newBg
                        customCardDraft = newCard
                        customButtonDraft = newBtn
                        customTextDraft = newTxt
                        customBorderDraft = newBrd
                        customIsLightDraft = newLight
                        previewedAnimatedId = BarqAnimatedThemeId.NONE
                        previewedThemeId = BarqThemeId.CUSTOM
                    },
                    onApplyCustomTheme = {
                        previewedAnimatedId = BarqAnimatedThemeId.NONE
                        previewedThemeId = BarqThemeId.CUSTOM
                        BarqThemeState.updateCustomTheme(
                            context = context,
                            primary = customPrimaryDraft,
                            secondary = customSecondaryDraft,
                            background = customBgDraft,
                            isLight = customIsLightDraft,
                            card = customCardDraft,
                            button = customButtonDraft,
                            text = customTextDraft,
                            border = customBorderDraft,
                            applyImmediately = true
                        )
                    },
                    onRestoreSavedCustom = {
                        BarqThemeState.loadFromPreferences(context)
                        customPrimaryDraft = BarqThemeState.customPrimaryColor
                        customSecondaryDraft = BarqThemeState.customSecondaryColor
                        customBgDraft = BarqThemeState.customBackgroundColor
                        customCardDraft = BarqThemeState.customCardColor
                        customButtonDraft = BarqThemeState.customButtonColor
                        customTextDraft = BarqThemeState.customTextColor
                        customBorderDraft = BarqThemeState.customBorderColor
                        customIsLightDraft = BarqThemeState.customIsLight
                        previewedAnimatedId = BarqAnimatedThemeId.NONE
                        previewedThemeId = BarqThemeId.CUSTOM
                    },
                    onResetCustomDefaults = {
                        BarqThemeState.resetCustomThemeDefaults(context, applyNow = true)
                        customPrimaryDraft = BarqThemeState.customPrimaryColor
                        customSecondaryDraft = BarqThemeState.customSecondaryColor
                        customBgDraft = BarqThemeState.customBackgroundColor
                        customCardDraft = BarqThemeState.customCardColor
                        customButtonDraft = BarqThemeState.customButtonColor
                        customTextDraft = BarqThemeState.customTextColor
                        customBorderDraft = BarqThemeState.customBorderColor
                        customIsLightDraft = BarqThemeState.customIsLight
                        previewedAnimatedId = BarqAnimatedThemeId.NONE
                        previewedThemeId = BarqThemeId.CUSTOM
                    }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))
        }

        CopyrightFooter()
    }
}

@Composable
private fun AnimatedThemeOptionCard(
    animatedThemeId: BarqAnimatedThemeId,
    keyframes: List<BarqThemePalette>,
    isApplied: Boolean,
    isPreviewed: Boolean,
    onPreview: () -> Unit,
    onApply: () -> Unit
) {
    val firstFrame = keyframes.firstOrNull() ?: BarqThemePalettes.MidnightBlue
    val gradientColors = remember(keyframes) {
        if (keyframes.size >= 3) {
            listOf(
                keyframes[0].primaryAccent,
                keyframes[1].primaryAccent,
                keyframes[2].primaryAccent
            )
        } else {
            listOf(firstFrame.primaryAccent, firstFrame.secondaryAccent)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MidnightCard)
            .border(
                width = when {
                    isApplied -> 2.dp
                    isPreviewed -> 1.5.dp
                    else -> 1.dp
                },
                brush = Brush.horizontalGradient(
                    if (isApplied || isPreviewed) gradientColors
                    else listOf(GlassBorder, firstFrame.primaryAccent.copy(alpha = 0.5f))
                ),
                shape = RoundedCornerShape(18.dp)
            )
            .clickable { onPreview() }
            .padding(14.dp)
            .testTag("animated_theme_card_${animatedThemeId.storageKey}")
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Brush.linearGradient(gradientColors))
                            .border(1.5.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = highContrastTextFor(gradientColors.first()),
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = animatedThemeId.englishTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "• ${animatedThemeId.arabicTitle}",
                                style = MaterialTheme.typography.labelMedium,
                                color = firstFrame.primaryAccent,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(
                            text = animatedThemeId.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = TextSecondary,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    keyframes.forEach { frame ->
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(frame.primaryAccent)
                                .border(1.dp, GlassBorder, CircleShape)
                        )
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(frame.secondaryAccent)
                                .border(1.dp, GlassBorder, CircleShape)
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onPreview,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("animated_theme_preview_${animatedThemeId.storageKey}")
                    ) {
                        Text(
                            text = if (isPreviewed) "قيد المعاينة" else "معاينة حية",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isPreviewed) ElectricCyan else TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = onApply,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isApplied) NeonEmerald else firstFrame.primaryAccent
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("animated_theme_apply_${animatedThemeId.storageKey}")
                    ) {
                        if (isApplied) {
                            Icon(
                                imageVector = Icons.Filled.Check,
                                contentDescription = null,
                                tint = highContrastTextFor(NeonEmerald),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Text(
                            text = if (isApplied) "مطبّق" else "تطبيق",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isApplied) highContrastTextFor(NeonEmerald) else firstFrame.onPrimaryAccent
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ThemeOptionCard(
    themeId: BarqThemeId,
    palette: BarqThemePalette,
    isApplied: Boolean,
    isPreviewed: Boolean,
    onPreview: () -> Unit,
    onApply: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MidnightCard)
            .border(
                width = when {
                    isApplied -> 2.dp
                    isPreviewed -> 1.5.dp
                    else -> 1.dp
                },
                color = when {
                    isApplied -> NeonEmerald
                    isPreviewed -> ElectricCyan
                    else -> GlassBorder
                },
                shape = RoundedCornerShape(18.dp)
            )
            .clickable { onPreview() }
            .padding(14.dp)
            .testTag("theme_card_${themeId.storageKey}")
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Miniature Color Swatch Preview Box
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(palette.background)
                            .border(1.5.dp, palette.primaryAccent, RoundedCornerShape(14.dp))
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .background(palette.primaryAccent)
                            )
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .background(palette.secondaryAccent)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = themeId.englishTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "• ${themeId.arabicTitle}",
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.primaryAccent,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(
                            text = themeId.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = TextSecondary,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Swatch Pills (Background, Card, Border, Primary, Secondary, Button/Tertiary)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf(
                        palette.background,
                        palette.card,
                        palette.border,
                        palette.primaryAccent,
                        palette.secondaryAccent,
                        palette.buttonColor
                    ).forEach { swatch ->
                        Box(
                            modifier = Modifier
                                .size(17.dp)
                                .clip(CircleShape)
                                .background(swatch)
                                .border(1.dp, GlassBorder, CircleShape)
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (palette.isLight) "فاتح" else "داكن",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 9.sp,
                        color = TextMuted
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onPreview,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("theme_preview_${themeId.storageKey}")
                    ) {
                        Text(
                            text = if (isPreviewed) "قيد المعاينة" else "معاينة",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isPreviewed) ElectricCyan else TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = onApply,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isApplied) NeonEmerald else palette.primaryAccent
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("theme_apply_${themeId.storageKey}")
                    ) {
                        if (isApplied) {
                            Icon(
                                imageVector = Icons.Filled.Check,
                                contentDescription = null,
                                tint = highContrastTextFor(NeonEmerald),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Text(
                            text = if (isApplied) "مطبّق" else "تطبيق",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isApplied) highContrastTextFor(NeonEmerald) else palette.onPrimaryAccent
                        )
                    }
                }
            }
        }
    }
}

/**
 * Full 7-Channel Custom Theme Studio allowing the user to customize:
 * 0 = اللون الأساسي (Primary)
 * 1 = اللون الثانوي (Secondary)
 * 2 = لون الخلفية (Background)
 * 3 = لون البطاقات (Cards)
 * 4 = لون الأزرار (Buttons)
 * 5 = لون النصوص (Text)
 * 6 = ألوان الحدود والتفاصيل (Borders)
 * With live preview, save & apply, restore saved settings, and reset to defaults.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CustomColorPickerPanel(
    primaryColor: Color,
    secondaryColor: Color,
    backgroundColor: Color,
    cardColor: Color,
    buttonColor: Color,
    textColor: Color,
    borderColor: Color,
    isLightMode: Boolean,
    onColorsChanged: (
        primary: Color,
        secondary: Color,
        bg: Color,
        card: Color,
        button: Color,
        text: Color,
        border: Color,
        isLight: Boolean
    ) -> Unit,
    onApplyCustomTheme: () -> Unit,
    onRestoreSavedCustom: () -> Unit,
    onResetCustomDefaults: () -> Unit
) {
    var selectedTargetChannel by remember { mutableIntStateOf(0) }
    val activeColor = when (selectedTargetChannel) {
        0 -> primaryColor
        1 -> secondaryColor
        2 -> backgroundColor
        3 -> cardColor
        4 -> buttonColor
        5 -> textColor
        else -> borderColor
    }

    var redVal by remember(activeColor) { mutableFloatStateOf(activeColor.red) }
    var greenVal by remember(activeColor) { mutableFloatStateOf(activeColor.green) }
    var blueVal by remember(activeColor) { mutableFloatStateOf(activeColor.blue) }

    fun updateActiveChannelColor(newColor: Color) {
        redVal = newColor.red
        greenVal = newColor.green
        blueVal = newColor.blue
        when (selectedTargetChannel) {
            0 -> onColorsChanged(newColor, secondaryColor, backgroundColor, cardColor, buttonColor, textColor, borderColor, isLightMode)
            1 -> onColorsChanged(primaryColor, newColor, backgroundColor, cardColor, buttonColor, textColor, borderColor, isLightMode)
            2 -> onColorsChanged(primaryColor, secondaryColor, newColor, cardColor, buttonColor, textColor, borderColor, isLightMode)
            3 -> onColorsChanged(primaryColor, secondaryColor, backgroundColor, newColor, buttonColor, textColor, borderColor, isLightMode)
            4 -> onColorsChanged(primaryColor, secondaryColor, backgroundColor, cardColor, newColor, textColor, borderColor, isLightMode)
            5 -> onColorsChanged(primaryColor, secondaryColor, backgroundColor, cardColor, buttonColor, newColor, borderColor, isLightMode)
            else -> onColorsChanged(primaryColor, secondaryColor, backgroundColor, cardColor, buttonColor, textColor, newColor, isLightMode)
        }
    }

    val presetPaletteColors = remember {
        listOf(
            Color(0xFF00E5FF), Color(0xFF38BDF8), Color(0xFF3B82F6), Color(0xFF6366F1),
            Color(0xFF8B5CF6), Color(0xFFD946EF), Color(0xFFFF2A85), Color(0xFFF43F5E),
            Color(0xFFEF4444), Color(0xFFF97316), Color(0xFFF59E0B), Color(0xFFEAB308),
            Color(0xFF10B981), Color(0xFF14B8A6), Color(0xFF0F172A), Color(0xFFF8FAFC)
        )
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MidnightCard)
            .border(1.5.dp, ElectricCyan.copy(alpha = 0.7f), RoundedCornerShape(20.dp))
            .padding(16.dp)
            .testTag("custom_color_picker_panel")
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.ColorLens,
                        contentDescription = null,
                        tint = ElectricCyan,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "تخصيص الثيم اليدوي الشامل (Custom Theme Studio)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "تحكم كامل في 7 قنوات لونية: الأساسي، الثانوي، الخلفية، البطاقات، الأزرار، النصوص، والحدود",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 7 Channel Selector Chips
            val channels = listOf(
                Triple(0, "اللون الأساسي", primaryColor),
                Triple(1, "اللون الثانوي", secondaryColor),
                Triple(2, "لون الخلفية", backgroundColor),
                Triple(3, "لون البطاقات", cardColor),
                Triple(4, "لون الأزرار", buttonColor),
                Triple(5, "لون النصوص", textColor),
                Triple(6, "الحدود والتفاصيل", borderColor)
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                channels.forEach { (idx, label, col) ->
                    val selected = selectedTargetChannel == idx
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (selected) ElectricCyan.copy(alpha = 0.18f) else MidnightSurface)
                            .border(
                                width = if (selected) 1.5.dp else 1.dp,
                                color = if (selected) ElectricCyan else GlassBorder,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { selectedTargetChannel = idx }
                            .padding(vertical = 7.dp, horizontal = 10.dp)
                            .testTag("custom_channel_tab_$idx")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(col)
                                .border(1.dp, TextPrimary.copy(alpha = 0.5f), CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            color = TextPrimary,
                            maxLines = 1
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Full Interactive Hue Spectrum Bar
            Text(
                text = "شريط الطيف اللوني الكامل (اضغط لاختيار الدرجة اللونية):",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(6.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(34.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
                    .pointerInput(selectedTargetChannel, isLightMode) {
                        detectTapGestures { offset ->
                            val fraction = (offset.x / size.width.toFloat()).coerceIn(0f, 1f)
                            val hue = fraction * 360f
                            val saturation = when (selectedTargetChannel) {
                                2, 3 -> if (isLightMode) 0.08f else 0.48f
                                5 -> if (isLightMode) 0.65f else 0.12f
                                else -> 0.88f
                            }
                            val value = when (selectedTargetChannel) {
                                2 -> if (isLightMode) 0.97f else 0.14f
                                3 -> if (isLightMode) 1.0f else 0.22f
                                5 -> if (isLightMode) 0.18f else 0.98f
                                else -> 0.95f
                            }
                            val picked = Color.hsv(hue, saturation, value)
                            updateActiveChannelColor(picked)
                        }
                    }
                    .testTag("custom_hue_spectrum_bar")
            ) {
                val rainbowColors = listOf(
                    Color.Red,
                    Color.Yellow,
                    Color.Green,
                    Color.Cyan,
                    Color.Blue,
                    Color.Magenta,
                    Color.Red
                )
                drawRect(
                    brush = Brush.horizontalGradient(rainbowColors)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Curated Quick Swatches Grid
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                presetPaletteColors.forEachIndexed { index, swatchColor ->
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(swatchColor)
                            .border(
                                width = if (activeColor == swatchColor) 2.5.dp else 1.dp,
                                color = if (activeColor == swatchColor) TextPrimary else GlassBorder,
                                shape = CircleShape
                            )
                            .clickable { updateActiveChannelColor(swatchColor) }
                            .testTag("custom_swatch_$index")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Fine-grained RGB Sliders + Hex Code Readout
            val hexCode = String.format(
                Locale.US,
                "#%02X%02X%02X",
                (redVal * 255).toInt().coerceIn(0, 255),
                (greenVal * 255).toInt().coerceIn(0, 255),
                (blueVal * 255).toInt().coerceIn(0, 255)
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "ضبط دقيق (RGB) للقناة المختارة:",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "HEX: $hexCode",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElectricCyan,
                    modifier = Modifier.testTag("custom_color_hex_text")
                )
            }

            Slider(
                value = redVal,
                onValueChange = { r ->
                    redVal = r
                    updateActiveChannelColor(Color(r, greenVal, blueVal, 1f))
                },
                colors = SliderDefaults.colors(thumbColor = Color(0xFFEF4444), activeTrackColor = Color(0xFFEF4444)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp)
                    .testTag("custom_red_slider")
            )
            Slider(
                value = greenVal,
                onValueChange = { g ->
                    greenVal = g
                    updateActiveChannelColor(Color(redVal, g, blueVal, 1f))
                },
                colors = SliderDefaults.colors(thumbColor = Color(0xFF10B981), activeTrackColor = Color(0xFF10B981)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp)
                    .testTag("custom_green_slider")
            )
            Slider(
                value = blueVal,
                onValueChange = { b ->
                    blueVal = b
                    updateActiveChannelColor(Color(redVal, greenVal, b, 1f))
                },
                colors = SliderDefaults.colors(thumbColor = Color(0xFF3B82F6), activeTrackColor = Color(0xFF3B82F6)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp)
                    .testTag("custom_blue_slider")
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Custom Mode Light/Dark Surface Toggle + Apply Custom Theme Button
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = isLightMode,
                        onCheckedChange = { light ->
                            val suggestedBg = if (light) Color(0xFFF8FAFC) else Color(0xFF081020)
                            val suggestedCard = if (light) Color(0xFFFFFFFF) else blendColors(suggestedBg, primaryColor, 0.12f)
                            val suggestedText = if (light) Color(0xFF0F172A) else Color(0xFFF8FAFC)
                            val suggestedBorder = if (light) blendColors(Color(0xFFCBD5E1), primaryColor, 0.28f) else blendColors(suggestedCard, primaryColor, 0.38f)
                            onColorsChanged(
                                primaryColor,
                                secondaryColor,
                                suggestedBg,
                                suggestedCard,
                                buttonColor,
                                suggestedText,
                                suggestedBorder,
                                light
                            )
                        },
                        modifier = Modifier.testTag("custom_is_light_switch")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isLightMode) "نمط مخصص فاتح" else "نمط مخصص داكن",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextPrimary
                    )
                }

                Button(
                    onClick = onApplyCustomTheme,
                    colors = ButtonDefaults.buttonColors(containerColor = buttonColor),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("apply_custom_theme_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = highContrastTextFor(buttonColor),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "حفظ وتطبيق الثيم المخصص",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = highContrastTextFor(buttonColor)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Restore Saved Custom Settings & Reset Custom Defaults Row
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = onRestoreSavedCustom,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("restore_saved_custom_theme_button")
                ) {
                    Text(
                        text = "استعادة المحفوظ",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = onResetCustomDefaults,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("reset_custom_theme_defaults_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Restore,
                        contentDescription = null,
                        tint = HotspotAmber,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "إعادة تعيين المخصص للافتراضي",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

/**
 * Settings Bottom Sheet connected directly to existing P2PTransferViewModel settings
 * (Chunk size, Transport Mode, Receiver Approval, Battery Optimization, Theme & Direction).
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun BarqSettingsModalSheet(
    uiState: P2PUiState,
    onDismiss: () -> Unit,
    onSelectChunkSize: (ChunkSizeOption) -> Unit,
    onSelectTransportMode: (TransportMode) -> Unit,
    onOpenBatterySettings: () -> Unit,
    onOpenThemesScreen: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MidnightCardElevated,
        modifier = Modifier.testTag("barq_settings_modal_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(horizontal = 18.dp, vertical = 10.dp)
        ) {
            Text(
                text = "⚙️ إعدادات برق P2P",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = "ضبط تدفق النقل، وضع الاتصال، البطارية، والواجهة",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "حجم دفعة النقل (Chunk Size):",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = ElectricCyan
            )
            Spacer(modifier = Modifier.height(6.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                ChunkSizeOption.entries.forEach { option ->
                    val selected = uiState.selectedChunkSize == option
                    Surface(
                        color = if (selected) ElectricCyan.copy(alpha = 0.2f) else MidnightCard,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            width = 1.dp,
                            color = if (selected) ElectricCyan else GlassBorder
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onSelectChunkSize(option) }
                    ) {
                        Text(
                            text = option.label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            color = if (selected) ElectricCyan else TextPrimary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "وضع النقل الافتراضي:",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = NeonEmerald
            )
            Spacer(modifier = Modifier.height(6.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                TransportMode.entries.forEach { mode ->
                    val selected = uiState.transportMode == mode
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (selected) NeonEmerald.copy(alpha = 0.16f) else MidnightCard)
                            .border(
                                width = 1.dp,
                                color = if (selected) NeonEmerald else GlassBorder,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { onSelectTransportMode(mode) }
                            .padding(10.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = mode.arabicTitle,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = if (selected) NeonEmerald else TextPrimary
                            )
                            Text(
                                text = mode.arabicDescription,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = onOpenBatterySettings,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "استثناء توفير البطارية",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextPrimary
                    )
                }

                Button(
                    onClick = {
                        onDismiss()
                        onOpenThemesScreen()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "الثيمات والألوان",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = OnPrimaryAccent
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            val isRtl = BarqThemeState.layoutDirection == LayoutDirection.Rtl
            OutlinedButton(
                onClick = {
                    val nextDir = if (isRtl) LayoutDirection.Ltr else LayoutDirection.Rtl
                    BarqThemeState.setLayoutDirectionMode(context, nextDir)
                },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (isRtl) "اتجاه الواجهة: العربية (RTL) — اضغط للتبديل إلى LTR" else "Layout Direction: English (LTR) — Tap for RTL",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextPrimary
                )
            }

            Spacer(modifier = Modifier.height(18.dp))
        }
    }
}

/**
 * About Barq P2P Bottom Sheet displaying real protocol specs, active network telemetry,
 * and direct APK export/sharing.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BarqAboutModalSheet(
    uiState: P2PUiState,
    onDismiss: () -> Unit,
    onExportApk: () -> Unit,
    onOpenWebPortal: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MidnightCardElevated,
        modifier = Modifier.testTag("barq_about_modal_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(ElectricCyan.copy(alpha = 0.2f))
                        .border(1.dp, ElectricCyan, RoundedCornerShape(14.dp))
                ) {
                    Icon(
                        imageVector = Icons.Filled.Bolt,
                        contentDescription = null,
                        tint = ElectricCyan,
                        modifier = Modifier.size(28.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "حول تطبيق برق P2P (Barq sher)",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "نظام نقل ومشاركة الملفات والمجلدات النظير للنظير بدون إنترنت",
                        style = MaterialTheme.typography.labelMedium,
                        color = ElectricCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(MidnightCard)
                    .border(1.dp, GlassBorder, RoundedCornerShape(14.dp))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "• نقل مباشر فائق السرعة عبر Wi-Fi 2.4/5GHz ونقاط الاتصال (Hotspot) والبلوتوث.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary
                    )
                    Text(
                        text = "• مدير ملفات متكامل يدعم جميع الامتدادات (APK, OBB, ZIP, RAR, BIG, DAT, TGA, ICO) والمجلدات المتداخلة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary
                    )
                    Text(
                        text = "• تحقق رقمي صارم SHA-256 واستئناف ذكي للدفعات المتوقفة (.part) وإشعارات تقدم حية.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary
                    )
                    Text(
                        text = "• بوابة المتصفح المحلية: ${uiState.networkStatus.webPortalUrl}",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 11.sp,
                        color = NeonEmerald
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = {
                        onDismiss()
                        onOpenWebPortal()
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("فتح بوابة الويب", color = TextPrimary)
                }

                Button(
                    onClick = {
                        onExportApk()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HotspotAmber),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "استخراج Barq-Sher.apk",
                        fontWeight = FontWeight.Bold,
                        color = highContrastTextFor(HotspotAmber)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
