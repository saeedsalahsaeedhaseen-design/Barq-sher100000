package com.example.ui.theme

import android.app.Activity
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    // Synchronous initialization BEFORE the very first composition frame — eliminates startup theme flash
    remember(context) {
        BarqThemeState.ensureInitialized(context)
        true
    }

    val systemDark = isSystemInDarkTheme()
    val lifecycleOwner = LocalLifecycleOwner.current

    // Pause animated themes automatically when the app moves to background to save CPU & battery
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START, Lifecycle.Event.ON_RESUME -> {
                    BarqThemeState.setAppForegroundState(true)
                }
                Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> {
                    BarqThemeState.setAppForegroundState(false)
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val shouldAnimate = BarqThemeState.shouldAnimateActiveTheme(context)
    val animatedPhaseState: androidx.compose.runtime.State<Float>? = if (shouldAnimate) {
        val infiniteTransition = rememberInfiniteTransition(label = "barq_animated_theme_engine")
        infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(
                    durationMillis = BarqThemeState.animationSpeed.cycleDurationMillis,
                    easing = LinearEasing
                ),
                repeatMode = RepeatMode.Restart
            ),
            label = "barq_theme_phase"
        )
    } else {
        null
    }
    SideEffect {
        BarqThemeState.liveAnimationPhaseState = animatedPhaseState
    }
    val quantizedPhase by remember(animatedPhaseState) {
        androidx.compose.runtime.derivedStateOf {
            val rawPhase = animatedPhaseState?.value ?: BarqThemeState.animationPhase
            ((rawPhase * 24f).toInt() / 24f).coerceIn(0f, 1f)
        }
    }
    SideEffect {
        if (shouldAnimate) {
            BarqThemeState.animationPhase = quantizedPhase
        }
    }

    val targetPalette = remember(
        BarqThemeState.selectedThemeId,
        BarqThemeState.selectedAnimatedThemeId,
        BarqThemeState.isThemeAnimationEnabled,
        BarqThemeState.autoSystemDarkLightMode,
        BarqThemeState.brightnessMode,
        BarqThemeState.customPrimaryColor,
        BarqThemeState.customSecondaryColor,
        BarqThemeState.customBackgroundColor,
        BarqThemeState.customCardColor,
        BarqThemeState.customButtonColor,
        BarqThemeState.customTextColor,
        BarqThemeState.customBorderColor,
        BarqThemeState.customIsLight,
        systemDark,
        quantizedPhase
    ) {
        BarqThemeState.resolvePalette(
            systemInDarkTheme = systemDark,
            phase = quantizedPhase
        )
    }

    val animatedPalette = if (shouldAnimate) {
        // Already smoothly interpolated via keyframe phase; avoid 17 separate animateColorAsState coroutines
        targetPalette
    } else {
        val animSpec = tween<Color>(durationMillis = 200)
        val animBg by animateColorAsState(targetPalette.background, animSpec, label = "theme_bg")
        val animSurface by animateColorAsState(targetPalette.surface, animSpec, label = "theme_surface")
        val animCard by animateColorAsState(targetPalette.card, animSpec, label = "theme_card")
        val animCardElevated by animateColorAsState(targetPalette.cardElevated, animSpec, label = "theme_card_elev")
        val animBorder by animateColorAsState(targetPalette.border, animSpec, label = "theme_border")
        val animPrimary by animateColorAsState(targetPalette.primaryAccent, animSpec, label = "theme_primary")
        val animPrimaryDim by animateColorAsState(targetPalette.primaryAccentDim, animSpec, label = "theme_primary_dim")
        val animSecondary by animateColorAsState(targetPalette.secondaryAccent, animSpec, label = "theme_secondary")
        val animSecondaryDim by animateColorAsState(targetPalette.secondaryAccentDim, animSpec, label = "theme_secondary_dim")
        val animTertiary by animateColorAsState(targetPalette.tertiaryAccent, animSpec, label = "theme_tertiary")
        val animTertiarySoft by animateColorAsState(targetPalette.tertiarySoft, animSpec, label = "theme_tertiary_soft")
        val animDanger by animateColorAsState(targetPalette.dangerAccent, animSpec, label = "theme_danger")
        val animHighlight by animateColorAsState(targetPalette.highlightAccent, animSpec, label = "theme_highlight")
        val animTextPrimary by animateColorAsState(targetPalette.textPrimary, animSpec, label = "theme_text_primary")
        val animTextSecondary by animateColorAsState(targetPalette.textSecondary, animSpec, label = "theme_text_secondary")
        val animTextMuted by animateColorAsState(targetPalette.textMuted, animSpec, label = "theme_text_muted")
        val animButton by animateColorAsState(targetPalette.buttonColor, animSpec, label = "theme_button")

        remember(
            targetPalette,
            animBg, animSurface, animCard, animCardElevated, animBorder,
            animPrimary, animPrimaryDim, animSecondary, animSecondaryDim,
            animTertiary, animTertiarySoft, animDanger, animHighlight,
            animTextPrimary, animTextSecondary, animTextMuted, animButton
        ) {
            targetPalette.copy(
                background = animBg,
                surface = animSurface,
                card = animCard,
                cardElevated = animCardElevated,
                border = animBorder,
                primaryAccent = animPrimary,
                primaryAccentDim = animPrimaryDim,
                secondaryAccent = animSecondary,
                secondaryAccentDim = animSecondaryDim,
                tertiaryAccent = animTertiary,
                tertiarySoft = animTertiarySoft,
                dangerAccent = animDanger,
                highlightAccent = animHighlight,
                textPrimary = animTextPrimary,
                textSecondary = animTextSecondary,
                textMuted = animTextMuted,
                buttonColor = animButton
            )
        }
    }
    BarqThemeState.activePalette = animatedPalette

    val view = LocalView.current
    if (!view.isInEditMode) {
        val lastWindowState = remember { IntArray(2) { Int.MIN_VALUE } }
        val bgArgb = animatedPalette.background.toArgb()
        val isLightInt = if (targetPalette.isLight) 1 else 0
        SideEffect {
            if (lastWindowState[0] != bgArgb || lastWindowState[1] != isLightInt) {
                val activity = view.context as? Activity
                activity?.window?.let { window ->
                    if (lastWindowState[0] != bgArgb) {
                        window.decorView.setBackgroundColor(bgArgb)
                        lastWindowState[0] = bgArgb
                    }
                    if (lastWindowState[1] != isLightInt) {
                        val controller = WindowCompat.getInsetsController(window, view)
                        controller.isAppearanceLightStatusBars = targetPalette.isLight
                        controller.isAppearanceLightNavigationBars = targetPalette.isLight
                        lastWindowState[1] = isLightInt
                    }
                }
            }
        }
    }

    val colorScheme = remember(animatedPalette) {
        if (animatedPalette.isLight) {
            lightColorScheme(
                primary = animatedPalette.primaryAccent,
                onPrimary = highContrastTextFor(animatedPalette.primaryAccent),
                primaryContainer = animatedPalette.cardElevated,
                onPrimaryContainer = animatedPalette.textPrimary,
                secondary = animatedPalette.secondaryAccent,
                onSecondary = highContrastTextFor(animatedPalette.secondaryAccent),
                secondaryContainer = animatedPalette.cardElevated,
                onSecondaryContainer = animatedPalette.textPrimary,
                tertiary = animatedPalette.tertiaryAccent,
                onTertiary = highContrastTextFor(animatedPalette.tertiaryAccent),
                tertiaryContainer = animatedPalette.tertiarySoft,
                onTertiaryContainer = animatedPalette.textPrimary,
                background = animatedPalette.background,
                onBackground = animatedPalette.textPrimary,
                surface = animatedPalette.surface,
                onSurface = animatedPalette.textPrimary,
                surfaceVariant = animatedPalette.card,
                onSurfaceVariant = animatedPalette.textSecondary,
                outline = animatedPalette.border,
                error = animatedPalette.dangerAccent,
                onError = Color.White
            )
        } else {
            darkColorScheme(
                primary = animatedPalette.primaryAccent,
                onPrimary = highContrastTextFor(animatedPalette.primaryAccent),
                primaryContainer = animatedPalette.cardElevated,
                onPrimaryContainer = animatedPalette.textPrimary,
                secondary = animatedPalette.secondaryAccent,
                onSecondary = highContrastTextFor(animatedPalette.secondaryAccent),
                secondaryContainer = animatedPalette.cardElevated,
                onSecondaryContainer = animatedPalette.textPrimary,
                tertiary = animatedPalette.tertiaryAccent,
                onTertiary = highContrastTextFor(animatedPalette.tertiaryAccent),
                tertiaryContainer = animatedPalette.tertiarySoft,
                onTertiaryContainer = animatedPalette.textPrimary,
                background = animatedPalette.background,
                onBackground = animatedPalette.textPrimary,
                surface = animatedPalette.surface,
                onSurface = animatedPalette.textPrimary,
                surfaceVariant = animatedPalette.card,
                onSurfaceVariant = animatedPalette.textSecondary,
                outline = animatedPalette.border,
                error = animatedPalette.dangerAccent,
                onError = Color.White
            )
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides BarqThemeState.layoutDirection) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AppTypography,
            content = content
        )
    }
}

/**
 * Subtle, non-intrusive ambient canvas overlay for the 10 Animated Themes.
 * Renders smooth motion graphics (Aurora ribbons, Galaxy stars, Cyber pulse rings,
 * Ocean waves, Golden luxury shimmer, Flame glow, etc.) without reducing text legibility.
 * Reads animation phase inside the Canvas draw scope and reuses Path allocations to avoid GC churn.
 */
@Composable
fun AnimatedThemeAmbientOverlay(
    animatedThemeId: BarqAnimatedThemeId,
    phase: Float = 0f,
    palette: BarqThemePalette,
    modifier: Modifier = Modifier,
    intensityAlpha: Float = 0.22f,
    phaseProvider: (() -> Float)? = null
) {
    if (animatedThemeId == BarqAnimatedThemeId.NONE) return

    val reusableWavePath = remember { Path() }

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        if (w <= 0f || h <= 0f) return@Canvas
        val effectivePhase = phaseProvider?.invoke() ?: phase
        val angle = effectivePhase * 2f * PI.toFloat()

        when (animatedThemeId) {
            BarqAnimatedThemeId.AURORA_FLOW,
            BarqAnimatedThemeId.RAINBOW_FLOW,
            BarqAnimatedThemeId.NEON_SPECTRUM -> {
                val cx1 = w * (0.3f + 0.25f * sin(angle))
                val cy1 = h * (0.25f + 0.15f * cos(angle))
                val cx2 = w * (0.7f + 0.25f * cos(angle * 0.8f))
                val cy2 = h * (0.65f + 0.18f * sin(angle * 0.8f))

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            palette.primaryAccent.copy(alpha = intensityAlpha),
                            Color.Transparent
                        ),
                        center = Offset(cx1, cy1),
                        radius = w * 0.65f
                    ),
                    center = Offset(cx1, cy1),
                    radius = w * 0.65f
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            palette.secondaryAccent.copy(alpha = intensityAlpha * 0.85f),
                            Color.Transparent
                        ),
                        center = Offset(cx2, cy2),
                        radius = w * 0.6f
                    ),
                    center = Offset(cx2, cy2),
                    radius = w * 0.6f
                )
            }

            BarqAnimatedThemeId.GALAXY_MOTION -> {
                val nebulaCenter = Offset(
                    w * (0.5f + 0.2f * cos(angle)),
                    h * (0.35f + 0.15f * sin(angle))
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            palette.primaryAccent.copy(alpha = intensityAlpha * 0.9f),
                            palette.highlightAccent.copy(alpha = intensityAlpha * 0.4f),
                            Color.Transparent
                        ),
                        center = nebulaCenter,
                        radius = w * 0.6f
                    ),
                    center = nebulaCenter,
                    radius = w * 0.6f
                )
                // Twinkling starlight points
                for (i in 0 until 14) {
                    val fx = ((i * 37 + 13) % 100) / 100f
                    val fy = ((i * 53 + 29) % 100) / 100f
                    val twinkle = (0.35f + 0.65f * ((sin(angle + i * 0.9f) + 1f) * 0.5f))
                    drawCircle(
                        color = if (i % 2 == 0) palette.textPrimary.copy(alpha = intensityAlpha * 1.4f * twinkle)
                        else palette.secondaryAccent.copy(alpha = intensityAlpha * 1.3f * twinkle),
                        radius = (1.5f + (i % 3)) * density,
                        center = Offset(w * fx, h * fy)
                    )
                }
            }

            BarqAnimatedThemeId.CYBER_PULSE,
            BarqAnimatedThemeId.EMERALD_PULSE -> {
                val center = Offset(w * 0.5f, h * 0.35f)
                val maxR = maxOf(w, h) * 0.65f
                for (ring in 0..2) {
                    val p = (effectivePhase + ring * 0.33f) % 1f
                    val r = maxR * p
                    val ringAlpha = (1f - p) * intensityAlpha * 0.9f
                    drawCircle(
                        color = if (ring % 2 == 0) palette.primaryAccent.copy(alpha = ringAlpha)
                        else palette.secondaryAccent.copy(alpha = ringAlpha),
                        radius = r.coerceAtLeast(1f),
                        center = center,
                        style = Stroke(width = 2f * density)
                    )
                }
            }

            BarqAnimatedThemeId.OCEAN_WAVES -> {
                for (waveIdx in 0..2) {
                    reusableWavePath.reset()
                    val baseY = h * (0.35f + waveIdx * 0.22f)
                    val amp = h * 0.04f
                    reusableWavePath.moveTo(0f, baseY)
                    val steps = 20
                    for (s in 1..steps) {
                        val x = (w / steps) * s
                        val y = baseY + amp * sin(angle + s * 0.45f + waveIdx * 1.2f)
                        reusableWavePath.lineTo(x, y)
                    }
                    drawPath(
                        path = reusableWavePath,
                        color = if (waveIdx % 2 == 0) palette.primaryAccent.copy(alpha = intensityAlpha * 0.8f)
                        else palette.secondaryAccent.copy(alpha = intensityAlpha * 0.7f),
                        style = Stroke(width = 2.2f * density)
                    )
                }
            }

            BarqAnimatedThemeId.SUNSET_MOTION,
            BarqAnimatedThemeId.GOLDEN_LUXURY,
            BarqAnimatedThemeId.FLAME_MOTION -> {
                val glowY = h * (0.7f - 0.25f * ((sin(angle) + 1f) * 0.5f))
                val glowX = w * (0.5f + 0.2f * cos(angle))
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            palette.primaryAccent.copy(alpha = intensityAlpha),
                            palette.secondaryAccent.copy(alpha = intensityAlpha * 0.5f),
                            Color.Transparent
                        ),
                        center = Offset(glowX, glowY),
                        radius = w * 0.7f
                    ),
                    center = Offset(glowX, glowY),
                    radius = w * 0.7f
                )
            }

            BarqAnimatedThemeId.NONE -> {}
        }
    }
}
