package com.example.data

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.os.CancellationSignal
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.util.Log
import android.util.LruCache
import android.util.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.model.DeviceMediaItem
import com.example.model.FileCategory
import com.example.model.FolderBatchInfo
import com.example.model.FolderStatsStatus
import com.example.model.PersistedSafFolderItem
import com.example.model.ReceivedApkItem
import com.example.model.SafUriStatus
import com.example.model.SafValidationResult
import com.example.model.StorageFolderItem
import com.example.model.TransferDirection
import com.example.model.TransferFileItem
import com.example.model.TransferHistoryRecord
import com.example.model.computeTotalChunksForSize
import com.example.util.Sha256Util
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.net.URLDecoder
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max

/**
 * Queries real device media and files via MediaStore, accessible storage directories,
 * and Storage Access Framework (SAF) DocumentTrees.
 *
 * Optimized for devices with thousands of photos and 40+ GB videos:
 * - Zero synchronous thumbnail extraction or blocking disk stats inside MediaStore cursor loops.
 * - Two-tier thumbnail cache (bounded 320-entry in-memory LruCache + compressed disk cache) with
 *   in-flight deduplication so the same thumbnail is never generated concurrently or repeatedly.
 * - Never scans or reads full video content to list or preview videos.
 * - Supports incremental batch pagination and progressive batch emission.
 */
object DeviceMediaRepository {

    private const val LOG_TAG = "BarqMediaRepo"
    private const val THUMBNAIL_CACHE_MAX_ENTRIES = 320
    private const val THUMBNAIL_TARGET_PX = 96
    private const val DISK_THUMB_DIR_NAME = "barq_thumbs_v2"
    private const val SAF_PREFS_NAME = "barq_saf_prefs"
    private const val SAF_SAVED_URIS_KEY = "saved_saf_uris_json"

    const val DEFAULT_MEDIA_PAGE_SIZE = 80

    private val thumbnailCache = object : LruCache<String, ImageBitmap>(THUMBNAIL_CACHE_MAX_ENTRIES) {}
    private val thumbnailSemaphore = Semaphore(4)
    private val inFlightThumbnails = ConcurrentHashMap<String, CompletableDeferred<ImageBitmap?>>()
    private val thumbnailGenerationCounter = ConcurrentHashMap<String, AtomicInteger>()
    private val failedThumbnailIds = java.util.Collections.synchronizedSet(HashSet<String>())
    private val sessionFolderStatsCache = ConcurrentHashMap<String, StorageFolderItem>()
    private val discoveredFoldersRegistry = ConcurrentHashMap<String, StorageFolderItem>()
    private val folderCacheStamps = ConcurrentHashMap<String, FolderCacheStamp>()
    private val cacheEpochCounter = java.util.concurrent.atomic.AtomicLong(1L)
    val fileReadOperationCount = java.util.concurrent.atomic.AtomicLong(0L)

    private data class FolderCacheStamp(
        val epoch: Long,
        val hasAllFilesAccess: Boolean,
        val dirLastModified: Long,
        val immediateEntryCount: Int,
        val statsStatus: FolderStatsStatus
    )

    fun getCurrentCacheEpoch(): Long = cacheEpochCounter.get()

    fun resetFileReadOperationCount() {
        fileReadOperationCount.set(0L)
    }

    fun clearFolderStatsCache() {
        cacheEpochCounter.incrementAndGet()
        sessionFolderStatsCache.clear()
        folderCacheStamps.clear()
        discoveredFoldersRegistry.clear()
    }

    fun invalidateFolderStatsForPath(pathOrRel: String?) {
        cacheEpochCounter.incrementAndGet()
        if (pathOrRel.isNullOrBlank()) {
            sessionFolderStatsCache.clear()
            folderCacheStamps.clear()
            return
        }
        val clean = pathOrRel.trim().replace('\\', '/').trim('/')
        val keysToRemove = sessionFolderStatsCache.keys.filter { key ->
            val normKey = key.replace('\\', '/').trim('/')
            normKey.equals(clean, ignoreCase = true) ||
                normKey.endsWith("/$clean", ignoreCase = true) ||
                clean.startsWith("$normKey/", ignoreCase = true) ||
                normKey.startsWith("$clean/", ignoreCase = true)
        }
        for (k in keysToRemove) {
            sessionFolderStatsCache.remove(k)
            folderCacheStamps.remove(k)
        }
    }

    internal fun getValidCachedFolderStats(
        path: String,
        context: Context? = null,
        currentDir: File? = null,
        knownImmediateCount: Int = -1
    ): StorageFolderItem? {
        if (path.isBlank()) return null
        val cached = sessionFolderStatsCache[path] ?: return null
        val stamp = folderCacheStamps[path] ?: return null
        if (stamp.epoch != cacheEpochCounter.get()) {
            sessionFolderStatsCache.remove(path)
            folderCacheStamps.remove(path)
            return null
        }
        if (cached.statsStatus != FolderStatsStatus.COMPLETED &&
            cached.statsStatus != FolderStatsStatus.PARTIALLY_READ &&
            cached.statsStatus != FolderStatsStatus.APPROXIMATE_CAPPED
        ) {
            return null
        }
        val currentAllFilesAccess = hasAllFilesAccessPermission(context)
        if (stamp.hasAllFilesAccess != currentAllFilesAccess) {
            sessionFolderStatsCache.remove(path)
            folderCacheStamps.remove(path)
            return null
        }
        if (!currentAllFilesAccess &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
            cached.fileCount == 0 &&
            cached.subfolderCount > 0
        ) {
            return null
        }
        val dirToCheck = currentDir ?: if (!path.startsWith("saf://")) File(path) else null
        if (dirToCheck != null && dirToCheck.exists()) {
            val currentMod = dirToCheck.lastModified()
            if (stamp.dirLastModified > 0L && currentMod > 0L && currentMod != stamp.dirLastModified) {
                sessionFolderStatsCache.remove(path)
                folderCacheStamps.remove(path)
                return null
            }
            if (knownImmediateCount >= 0 && stamp.immediateEntryCount >= 0 && knownImmediateCount != stamp.immediateEntryCount) {
                sessionFolderStatsCache.remove(path)
                folderCacheStamps.remove(path)
                return null
            }
        }
        return cached
    }

    private fun putCachedFolderStats(
        folder: StorageFolderItem,
        context: Context? = null,
        dir: File? = null,
        immediateCount: Int = -1
    ) {
        if (folder.path.isBlank()) return
        if (folder.statsStatus != FolderStatsStatus.COMPLETED &&
            folder.statsStatus != FolderStatsStatus.PARTIALLY_READ &&
            folder.statsStatus != FolderStatsStatus.APPROXIMATE_CAPPED
        ) {
            return
        }
        val dirFile = dir ?: if (!folder.path.startsWith("saf://")) File(folder.path) else null
        val mod = if (dirFile != null && dirFile.exists()) dirFile.lastModified() else folder.lastModifiedMillis
        sessionFolderStatsCache[folder.path] = folder
        folderCacheStamps[folder.path] = FolderCacheStamp(
            epoch = cacheEpochCounter.get(),
            hasAllFilesAccess = hasAllFilesAccessPermission(context),
            dirLastModified = mod,
            immediateEntryCount = immediateCount,
            statsStatus = folder.statsStatus
        )
    }

    /**
     * Checks whether the app currently holds full shared storage read access:
     * - Android 11+ (API 30+): Environment.isExternalStorageManager() (MANAGE_EXTERNAL_STORAGE)
     * - Android 10 and below (API <= 29): READ_EXTERNAL_STORAGE
     */
    fun hasAllFilesAccessPermission(context: Context? = null): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                Environment.isExternalStorageManager()
            } catch (_: Throwable) {
                false
            }
        } else if (context != null) {
            androidx.core.content.ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    /**
     * Normalizes a relative directory path from MediaStore RELATIVE_PATH or DATA so that:
     * 1. Blank strings properly fall back to DATA parent path.
     * 2. A file's own name (e.g. "last stand_8.tga") is never included as a folder segment in relDir.
     */
    private fun normalizeRelativeDirPath(
        rawRel: String?,
        dataPath: String?,
        fileName: String,
        externalRootPath: String
    ): String {
        val cleanFileName = fileName.trim().trim('/')
        var candidate = rawRel?.replace('\\', '/')?.trim()?.trim('/')?.takeIf { it.isNotBlank() }
        if (candidate == null && !dataPath.isNullOrBlank()) {
            val cleanData = dataPath.replace('\\', '/').trim()
            if (cleanData.startsWith(externalRootPath)) {
                val relFromRoot = cleanData.removePrefix(externalRootPath).trim('/')
                candidate = relFromRoot.substringBeforeLast('/', "").trim('/')
            }
        }
        var result = candidate.orEmpty()
        if (cleanFileName.isNotEmpty() && result.isNotEmpty()) {
            while (result.equals(cleanFileName, ignoreCase = true) ||
                result.endsWith("/$cleanFileName", ignoreCase = true)
            ) {
                result = if (result.equals(cleanFileName, ignoreCase = true)) {
                    ""
                } else {
                    result.substring(0, result.length - cleanFileName.length - 1).trim('/')
                }
            }
        }
        return result
    }

    private fun hasRecognizedFileExtension(name: String): Boolean {
        val clean = name.trim().substringAfterLast('/')
        val dotIdx = clean.lastIndexOf('.')
        if (dotIdx <= 0 || dotIdx == clean.lastIndex) return false
        val ext = clean.substring(dotIdx + 1).lowercase(Locale.ROOT)
        return ext in FileCategory.IMAGE_EXTENSIONS ||
            ext in FileCategory.VIDEO_EXTENSIONS ||
            ext in FileCategory.AUDIO_EXTENSIONS ||
            ext in setOf(
                "tga", "ico", "cur", "dds", "psd", "svg", "tif", "tiff",
                "zip", "rar", "7z", "tar", "gz", "bz2", "xz", "iso",
                "apk", "xapk", "apks", "obb",
                "big", "dat", "ini", "cfg", "conf", "w3d", "map", "wak", "scb", "str", "csf", "idx", "index",
                "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "json", "xml", "csv", "md", "html", "log", "bin", "pak"
            )
    }

    fun registerFolderItem(folder: StorageFolderItem) {
        if (folder.path.isNotBlank()) {
            discoveredFoldersRegistry[folder.path] = folder
        }
        val rel = folder.relativeDisplayPath.trim('/').lowercase(Locale.ROOT)
        if (rel.isNotBlank()) {
            discoveredFoldersRegistry[rel] = folder
        }
    }

    fun getRegisteredFolder(pathOrRel: String): StorageFolderItem? {
        val clean = pathOrRel.trim()
        if (clean.isBlank()) return null
        return sessionFolderStatsCache[clean]
            ?: discoveredFoldersRegistry[clean]
            ?: discoveredFoldersRegistry[clean.trim('/').lowercase(Locale.ROOT)]
    }

    private fun resolveLocalFileByteSize(file: File): Long {
        val len = file.length()
        if (len > 0L) return len
        return try {
            java.nio.file.Files.size(file.toPath()).coerceAtLeast(0L)
        } catch (_: Throwable) {
            0L
        }
    }

    private fun resolveContentUriByteSize(resolver: ContentResolver, uri: Uri): Long {
        try {
            resolver.query(uri, arrayOf(android.provider.OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) {
                    val s = c.getLong(0)
                    if (s > 0L) return s
                }
            }
        } catch (_: Throwable) {
        }
        try {
            resolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                if (afd.length > 0L) return afd.length
            }
        } catch (_: Throwable) {
        }
        return 0L
    }

    fun getCachedThumbnail(itemId: String): ImageBitmap? {
        return synchronized(thumbnailCache) {
            thumbnailCache.get(itemId)
        }
    }

    fun putCachedThumbnail(itemId: String, bitmap: ImageBitmap) {
        synchronized(thumbnailCache) {
            thumbnailCache.put(itemId, bitmap)
        }
        failedThumbnailIds.remove(itemId)
    }

    fun getThumbnailGenerationCount(itemId: String): Int {
        return thumbnailGenerationCounter[itemId]?.get() ?: 0
    }

    fun clearThumbnailCache(context: Context? = null) {
        synchronized(thumbnailCache) {
            thumbnailCache.evictAll()
        }
        inFlightThumbnails.clear()
        thumbnailGenerationCounter.clear()
        failedThumbnailIds.clear()
        if (context != null) {
            runCatching {
                File(context.cacheDir, DISK_THUMB_DIR_NAME).deleteRecursively()
            }
        }
    }

    private fun getDiskThumbFile(context: Context, itemId: String): File {
        val dir = File(context.cacheDir, DISK_THUMB_DIR_NAME)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        val safeName = itemId.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        return File(dir, "th_${safeName}_${itemId.hashCode()}.jpg")
    }

    private fun loadThumbnailFromDiskCache(context: Context, itemId: String): ImageBitmap? {
        return try {
            val file = getDiskThumbFile(context, itemId)
            if (!file.exists() || file.length() <= 0L) return null
            val opts = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            BitmapFactory.decodeFile(file.absolutePath, opts)?.asImageBitmap()
        } catch (_: Throwable) {
            null
        }
    }

    private fun saveThumbnailToDiskCache(context: Context, itemId: String, imageBitmap: ImageBitmap) {
        try {
            val file = getDiskThumbFile(context, itemId)
            if (file.exists() && file.length() > 0L) return
            val androidBmp = imageBitmap.asAndroidBitmap()
            FileOutputStream(file).use { out ->
                androidBmp.compress(Bitmap.CompressFormat.JPEG, 78, out)
            }
        } catch (_: Throwable) {
        }
    }

    /**
     * Lazily loads a small thumbnail for a visible row on Dispatchers.IO, caching it in the
     * two-tier cache (in-memory LruCache + disk cache) and deduplicating concurrent requests
     * for the same item ID. For large videos (up to 40+ GB), uses a strict timeout with
     * CancellationSignal so it never blocks or reads full video streams.
     */
    suspend fun getOrLoadThumbnailAsync(
        context: Context,
        item: DeviceMediaItem,
        customLoadGenerator: (suspend (DeviceMediaItem) -> ImageBitmap?)? = null
    ): ImageBitmap? {
        item.thumbnailBitmap?.let { bmp ->
            putCachedThumbnail(item.id, bmp)
            return bmp
        }
        getCachedThumbnail(item.id)?.let { return it }
        if (item.id in failedThumbnailIds) return null
        if (item.category != FileCategory.IMAGE && item.category != FileCategory.VIDEO) return null

        // Deduplicate concurrent requests for the exact same itemId
        val existingDeferred = inFlightThumbnails[item.id]
        if (existingDeferred != null) {
            return existingDeferred.await()
        }

        val myDeferred = CompletableDeferred<ImageBitmap?>()
        val prior = inFlightThumbnails.putIfAbsent(item.id, myDeferred)
        if (prior != null) {
            return prior.await()
        }

        return try {
            withContext(Dispatchers.IO) {
                getCachedThumbnail(item.id)?.let { cached ->
                    myDeferred.complete(cached)
                    return@withContext cached
                }

                // Check disk thumbnail cache before decoding original media
                if (customLoadGenerator == null) {
                    loadThumbnailFromDiskCache(context, item.id)?.let { diskBmp ->
                        putCachedThumbnail(item.id, diskBmp)
                        myDeferred.complete(diskBmp)
                        return@withContext diskBmp
                    }
                }

                val result = thumbnailSemaphore.withPermit {
                    getCachedThumbnail(item.id)?.let { return@withPermit it }
                    thumbnailGenerationCounter.computeIfAbsent(item.id) { AtomicInteger(0) }.incrementAndGet()

                    val loaded = if (customLoadGenerator != null) {
                        customLoadGenerator(item)
                    } else {
                        val resolver = context.contentResolver
                        val mediaId = item.id.substringAfterLast('_').toLongOrNull() ?: -1L
                        val isVideo = item.category == FileCategory.VIDEO
                        if (isVideo) {
                            val signal = CancellationSignal()
                            try {
                                withTimeoutOrNull(750L) {
                                    loadMediaThumbnailFast(
                                        resolver = resolver,
                                        uri = item.uri,
                                        mediaId = mediaId,
                                        isVideo = true,
                                        fallbackFile = item.localFile,
                                        cancellationSignal = signal
                                    )
                                }
                            } finally {
                                runCatching { signal.cancel() }
                            }
                        } else {
                            loadMediaThumbnailFast(
                                resolver = resolver,
                                uri = item.uri,
                                mediaId = mediaId,
                                isVideo = false,
                                fallbackFile = item.localFile,
                                cancellationSignal = null
                            )
                        }
                    }

                    if (loaded != null) {
                        putCachedThumbnail(item.id, loaded)
                        if (customLoadGenerator == null) {
                            saveThumbnailToDiskCache(context, item.id, loaded)
                        }
                    } else {
                        failedThumbnailIds.add(item.id)
                    }
                    loaded
                }
                myDeferred.complete(result)
                result
            }
        } catch (t: Throwable) {
            myDeferred.complete(null)
            throw t
        } finally {
            inFlightThumbnails.remove(item.id, myDeferred)
        }
    }

    fun loadImages(
        context: Context,
        maxItems: Int = 2500,
        offset: Int = 0,
        batchSize: Int = DEFAULT_MEDIA_PAGE_SIZE,
        onBatchLoaded: ((List<DeviceMediaItem>) -> Unit)? = null,
        isCancelled: () -> Boolean = { false }
    ): List<DeviceMediaItem> {
        if (isCancelled() || maxItems <= 0) return emptyList()
        val resolver = context.contentResolver
        val items = ArrayList<DeviceMediaItem>(minOf(maxItems, 512))
        val seenPathsOrNames = HashSet<String>(minOf(maxItems, 512))
        val seenCanonicalFiles = HashSet<String>(minOf(maxItems, 512))
        val safeBatchSize = batchSize.coerceAtLeast(20)
        var lastEmittedSize = 0

        val projection = buildList {
            add(MediaStore.Images.Media._ID)
            add(MediaStore.Images.Media.DISPLAY_NAME)
            add(MediaStore.Images.Media.SIZE)
            add(MediaStore.Images.Media.DATE_MODIFIED)
            add(MediaStore.Images.Media.MIME_TYPE)
            add(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaStore.MediaColumns.RELATIVE_PATH)
            }
            @Suppress("DEPRECATION")
            add(MediaStore.MediaColumns.DATA)
        }.toTypedArray()
        val sortOrder = "${MediaStore.Images.Media.DATE_MODIFIED} DESC"
        try {
            resolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndex(MediaStore.Images.Media.SIZE)
                val dateCol = cursor.getColumnIndex(MediaStore.Images.Media.DATE_MODIFIED)
                val mimeCol = cursor.getColumnIndex(MediaStore.Images.Media.MIME_TYPE)
                val bucketCol = cursor.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
                val relCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                } else -1
                @Suppress("DEPRECATION")
                val dataCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)

                val canReadCursor = offset == 0 || cursor.moveToPosition(offset - 1)
                var count = 0
                while (canReadCursor && cursor.moveToNext() && count < maxItems) {
                    if ((count and 31) == 0 && isCancelled()) break
                    val id = cursor.getLong(idCol)
                    val dataPath = if (dataCol >= 0) cursor.getString(dataCol) else null
                    val rawSize = if (sizeCol >= 0 && !cursor.isNull(sizeCol)) cursor.getLong(sizeCol) else 0L
                    val localFile = if (!dataPath.isNullOrBlank()) File(dataPath) else null
                    val name = (if (nameCol >= 0) cursor.getString(nameCol) else null)
                        ?: localFile?.name
                        ?: "IMG_$id.jpg"
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val size = when {
                        rawSize > 0L -> rawSize
                        count < 40 && localFile != null && localFile.exists() -> localFile.length()
                        count < 25 -> resolveContentUriLength(resolver, contentUri)
                        else -> 0L
                    }

                    val dateSec = if (dateCol >= 0 && !cursor.isNull(dateCol)) cursor.getLong(dateCol) else 0L
                    val dateMillis = if (dateSec > 0L) dateSec * 1000L else System.currentTimeMillis()
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else "image/jpeg"
                    val relDirRaw = if (relCol >= 0) cursor.getString(relCol)?.trim('/') else null
                    val bucket = (if (bucketCol >= 0) cursor.getString(bucketCol) else null)
                        ?: relDirRaw
                        ?: localFile?.parentFile?.name
                        ?: "الصور"
                    val relPath = relDirRaw?.let { if (it.isNotBlank()) "$it/$name" else name } ?: name

                    val dedupKey = when {
                        !dataPath.isNullOrBlank() -> dataPath.lowercase(Locale.ROOT)
                        !relDirRaw.isNullOrBlank() -> "$relDirRaw/$name:$size:$id".lowercase(Locale.ROOT)
                        else -> "$bucket/$name:$size:$id".lowercase(Locale.ROOT)
                    }
                    if (!seenPathsOrNames.add(dedupKey)) continue
                    if (!dataPath.isNullOrBlank()) {
                        seenCanonicalFiles.add(dataPath.lowercase(Locale.ROOT))
                    }
                    seenCanonicalFiles.add("$bucket/$name:$size".lowercase(Locale.ROOT))

                    val itemId = "img_$id"
                    items.add(
                        DeviceMediaItem(
                            id = itemId,
                            name = name,
                            uri = contentUri,
                            localFile = localFile,
                            sizeBytes = size.coerceAtLeast(0L),
                            dateModifiedMillis = dateMillis,
                            mimeType = mime,
                            bucketOrFolderName = bucket,
                            relativePathInStorage = relPath,
                            category = FileCategory.IMAGE,
                            thumbnailBitmap = getCachedThumbnail(itemId)
                        )
                    )
                    count++

                    if (onBatchLoaded != null && (items.size - lastEmittedSize) >= safeBatchSize) {
                        lastEmittedSize = items.size
                        onBatchLoaded(ArrayList(items))
                    }
                }
            }
        } catch (se: SecurityException) {
            Log.w(LOG_TAG, "SecurityException in loadImages (permission not yet granted): ${se.message}")
        } catch (t: Throwable) {
            Log.e(LOG_TAG, "Error querying MediaStore.Images: ${t.message}", t)
        }

        // Supplement with fallback directory scan when MediaStore has fewer items than requested
        if (!isCancelled() && items.size < maxItems) {
            val fallbackCollector = ArrayList<DeviceMediaItem>()
            scanFallbackMediaDirectories(
                targetCategory = FileCategory.IMAGE,
                seenKeys = seenCanonicalFiles,
                maxRemaining = offset + maxItems,
                outList = fallbackCollector,
                batchSize = safeBatchSize,
                onBatchLoaded = if (offset == 0 && onBatchLoaded != null) {
                    { partialFallback ->
                        val combined = ArrayList<DeviceMediaItem>(items.size + partialFallback.size)
                        combined.addAll(items)
                        combined.addAll(partialFallback.take(maxItems - items.size))
                        if (combined.size - lastEmittedSize >= safeBatchSize) {
                            lastEmittedSize = combined.size
                            onBatchLoaded(combined)
                        }
                    }
                } else null,
                isCancelled = isCancelled
            )
            val slicedFallback = if (offset > 0) {
                if (fallbackCollector.size > offset) {
                    fallbackCollector.subList(offset, minOf(fallbackCollector.size, offset + (maxItems - items.size)))
                } else emptyList()
            } else {
                fallbackCollector.take(maxItems - items.size)
            }
            items.addAll(slicedFallback)

            if (offset == 0 && items.size < 20 && !isCancelled()) {
                scanMediaFromPersistedSafFolders(
                    context = context,
                    targetCategory = FileCategory.IMAGE,
                    seenKeys = seenCanonicalFiles,
                    maxRemaining = minOf(100, maxItems - items.size),
                    outList = items,
                    isCancelled = isCancelled
                )
            }
        }
        if (onBatchLoaded != null && items.size > lastEmittedSize) {
            onBatchLoaded(ArrayList(items))
        }
        return items
    }

    /**
     * Loads videos from all available sources:
     * 1. MediaStore.Video.Media.EXTERNAL_CONTENT_URI (primary video index, never dropping entries with unindexed 0 size).
     * 2. MediaStore.Files.getContentUri("external") for video MIME types and video file extensions (.mkv, .mp4, .mov, .webm, etc.)
     *    in nested folders that MediaStore.Video may not have categorized.
     * 3. Recursive directory scan of public video/camera/download/messaging folders (Movies, DCIM, Download, Pictures, WhatsApp, Telegram).
     * 4. Valid persisted SAF folders granted by the user (without prompting the user again).
     */
    fun loadVideos(
        context: Context,
        maxItems: Int = 1500,
        offset: Int = 0,
        batchSize: Int = DEFAULT_MEDIA_PAGE_SIZE,
        onBatchLoaded: ((List<DeviceMediaItem>) -> Unit)? = null,
        isCancelled: () -> Boolean = { false }
    ): List<DeviceMediaItem> {
        if (isCancelled() || maxItems <= 0) return emptyList()
        val resolver = context.contentResolver
        val items = ArrayList<DeviceMediaItem>(minOf(maxItems, 256))
        val seenPathsOrNames = HashSet<String>(minOf(maxItems, 256))
        val seenCanonicalFiles = HashSet<String>(minOf(maxItems, 256))
        val safeBatchSize = batchSize.coerceAtLeast(20)
        var lastEmittedSize = 0

        val projection = buildList {
            add(MediaStore.Video.Media._ID)
            add(MediaStore.Video.Media.DISPLAY_NAME)
            add(MediaStore.Video.Media.SIZE)
            add(MediaStore.Video.Media.DATE_MODIFIED)
            add(MediaStore.Video.Media.DURATION)
            add(MediaStore.Video.Media.MIME_TYPE)
            add(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaStore.MediaColumns.RELATIVE_PATH)
            }
            @Suppress("DEPRECATION")
            add(MediaStore.MediaColumns.DATA)
        }.toTypedArray()
        val sortOrder = "${MediaStore.Video.Media.DATE_MODIFIED} DESC"
        try {
            resolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Video.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndex(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndex(MediaStore.Video.Media.DATE_MODIFIED)
                val durCol = cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
                val mimeCol = cursor.getColumnIndex(MediaStore.Video.Media.MIME_TYPE)
                val bucketCol = cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                val relCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                } else -1
                @Suppress("DEPRECATION")
                val dataCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)

                val canReadCursor = offset == 0 || cursor.moveToPosition(offset - 1)
                var count = 0
                while (canReadCursor && cursor.moveToNext() && count < maxItems) {
                    if ((count and 31) == 0 && isCancelled()) break
                    val id = cursor.getLong(idCol)
                    val dataPath = if (dataCol >= 0) cursor.getString(dataCol) else null
                    val rawSize = if (sizeCol >= 0 && !cursor.isNull(sizeCol)) cursor.getLong(sizeCol) else 0L
                    // Never inspect or read multi-GB (up to 40+ GB) video contents during listing!
                    val localFile = if (!dataPath.isNullOrBlank()) File(dataPath) else null
                    val name = (if (nameCol >= 0) cursor.getString(nameCol) else null)
                        ?: localFile?.name
                        ?: "VID_$id.mp4"
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val size = when {
                        rawSize > 0L -> rawSize
                        count < 30 && localFile != null && localFile.exists() -> localFile.length()
                        count < 15 -> resolveContentUriLength(resolver, contentUri)
                        else -> 0L
                    }
                    // IMPORTANT: Do NOT skip videos when rawSize == 0 or localFile.exists() is false under Scoped Storage,
                    // because ContentResolver can still stream the video via contentUri!

                    val dateSec = if (dateCol >= 0 && !cursor.isNull(dateCol)) cursor.getLong(dateCol) else 0L
                    val dateMillis = if (dateSec > 0L) dateSec * 1000L else System.currentTimeMillis()
                    val duration = if (durCol >= 0 && !cursor.isNull(durCol)) cursor.getLong(durCol) else 0L
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else "video/mp4"
                    val relDirRaw = if (relCol >= 0) cursor.getString(relCol)?.trim('/') else null
                    val bucket = (if (bucketCol >= 0) cursor.getString(bucketCol) else null)
                        ?: relDirRaw
                        ?: localFile?.parentFile?.name
                        ?: "الفيديوهات"
                    val relPath = relDirRaw?.let { if (it.isNotBlank()) "$it/$name" else name } ?: name

                    val dedupKey = when {
                        !dataPath.isNullOrBlank() -> dataPath.lowercase(Locale.ROOT)
                        !relDirRaw.isNullOrBlank() -> "$relDirRaw/$name:$size:$id".lowercase(Locale.ROOT)
                        else -> "$bucket/$name:$size:$id".lowercase(Locale.ROOT)
                    }
                    if (!seenPathsOrNames.add(dedupKey)) continue
                    if (!dataPath.isNullOrBlank()) {
                        seenCanonicalFiles.add(dataPath.lowercase(Locale.ROOT))
                    }
                    seenCanonicalFiles.add("$bucket/$name:$size".lowercase(Locale.ROOT))
                    seenCanonicalFiles.add("$relPath:$size".lowercase(Locale.ROOT))

                    val itemId = "vid_$id"
                    items.add(
                        DeviceMediaItem(
                            id = itemId,
                            name = name,
                            uri = contentUri,
                            localFile = localFile,
                            sizeBytes = size.coerceAtLeast(0L),
                            dateModifiedMillis = dateMillis,
                            durationMillis = duration,
                            mimeType = mime,
                            bucketOrFolderName = bucket,
                            relativePathInStorage = relPath,
                            category = FileCategory.VIDEO,
                            thumbnailBitmap = getCachedThumbnail(itemId)
                        )
                    )
                    count++

                    if (onBatchLoaded != null && (items.size - lastEmittedSize) >= safeBatchSize) {
                        lastEmittedSize = items.size
                        onBatchLoaded(ArrayList(items))
                    }
                }
            }
        } catch (se: SecurityException) {
            Log.w(LOG_TAG, "SecurityException in loadVideos (permission not yet granted): ${se.message}")
        } catch (t: Throwable) {
            Log.e(LOG_TAG, "Error querying MediaStore.Video: ${t.message}", t)
        }

        // 2. Supplement from MediaStore.Files for videos in subfolders or non-standard containers (.mkv, .webm, .ts, .mov, etc.)
        if (!isCancelled() && offset == 0 && items.size < maxItems) {
            queryVideosFromMediaStoreFiles(
                resolver = resolver,
                seenCanonicalFiles = seenCanonicalFiles,
                maxRemaining = minOf(300, maxItems - items.size),
                outList = items,
                isCancelled = isCancelled
            )
            if (onBatchLoaded != null && (items.size - lastEmittedSize) >= safeBatchSize) {
                lastEmittedSize = items.size
                onBatchLoaded(ArrayList(items))
            }
        }

        // 3. Supplement from local video directories & nested subfolders (Movies, DCIM, Download, WhatsApp, Telegram, etc.)
        if (!isCancelled() && items.size < maxItems) {
            val fallbackCollector = ArrayList<DeviceMediaItem>()
            scanFallbackMediaDirectories(
                targetCategory = FileCategory.VIDEO,
                seenKeys = seenCanonicalFiles,
                maxRemaining = offset + maxItems,
                outList = fallbackCollector,
                batchSize = safeBatchSize,
                onBatchLoaded = if (offset == 0 && onBatchLoaded != null) {
                    { partialFallback ->
                        val combined = ArrayList<DeviceMediaItem>(items.size + partialFallback.size)
                        combined.addAll(items)
                        combined.addAll(partialFallback.take(maxItems - items.size))
                        if (combined.size - lastEmittedSize >= safeBatchSize) {
                            lastEmittedSize = combined.size
                            onBatchLoaded(combined)
                        }
                    }
                } else null,
                isCancelled = isCancelled
            )
            val slicedFallback = if (offset > 0) {
                if (fallbackCollector.size > offset) {
                    fallbackCollector.subList(offset, minOf(fallbackCollector.size, offset + (maxItems - items.size)))
                } else emptyList()
            } else {
                fallbackCollector.take(maxItems - items.size)
            }
            items.addAll(slicedFallback)
        }

        // 4. Supplement from any valid persisted SAF folders if still under maxItems
        if (!isCancelled() && offset == 0 && items.size < 50) {
            scanMediaFromPersistedSafFolders(
                context = context,
                targetCategory = FileCategory.VIDEO,
                seenKeys = seenCanonicalFiles,
                maxRemaining = minOf(150, maxItems - items.size),
                outList = items,
                isCancelled = isCancelled
            )
        }

        if (onBatchLoaded != null && items.size > lastEmittedSize) {
            onBatchLoaded(ArrayList(items))
        }
        return items
    }

    private fun queryVideosFromMediaStoreFiles(
        resolver: ContentResolver,
        seenCanonicalFiles: MutableSet<String>,
        maxRemaining: Int,
        outList: MutableList<DeviceMediaItem>,
        isCancelled: () -> Boolean
    ) {
        if (maxRemaining <= 0 || isCancelled()) return
        try {
            val filesUri = MediaStore.Files.getContentUri("external")
            val projection = buildList {
                add(MediaStore.Files.FileColumns._ID)
                add(MediaStore.Files.FileColumns.DISPLAY_NAME)
                add(MediaStore.Files.FileColumns.SIZE)
                add(MediaStore.Files.FileColumns.DATE_MODIFIED)
                add(MediaStore.Files.FileColumns.MIME_TYPE)
                add(MediaStore.Files.FileColumns.MEDIA_TYPE)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    add(MediaStore.MediaColumns.RELATIVE_PATH)
                    add(MediaStore.Video.Media.DURATION)
                }
                @Suppress("DEPRECATION")
                add(MediaStore.MediaColumns.DATA)
            }.toTypedArray()

            val selection = "${MediaStore.Files.FileColumns.MEDIA_TYPE} = ? OR ${MediaStore.Files.FileColumns.MIME_TYPE} LIKE 'video/%'"
            val selectionArgs = arrayOf(MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString())
            val sortOrder = "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"

            resolver.query(filesUri, projection, selection, selectionArgs, sortOrder)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.SIZE)
                val dateCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATE_MODIFIED)
                val mimeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.MIME_TYPE)
                val relCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                } else -1
                val durCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
                } else -1
                @Suppress("DEPRECATION")
                val dataCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)

                var added = 0
                while (cursor.moveToNext() && added < maxRemaining) {
                    if ((added and 31) == 0 && isCancelled()) break
                    val id = cursor.getLong(idCol)
                    val dataPath = if (dataCol >= 0) cursor.getString(dataCol) else null
                    val localFile = if (!dataPath.isNullOrBlank()) File(dataPath) else null
                    val name = (if (nameCol >= 0) cursor.getString(nameCol) else null)
                        ?: localFile?.name
                        ?: continue
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                    if (FileCategory.fromFileName(name, mime) != FileCategory.VIDEO) continue

                    val relDirRaw = if (relCol >= 0) cursor.getString(relCol)?.trim('/') else null
                    val bucket = relDirRaw?.substringAfterLast('/')?.ifBlank { relDirRaw }
                        ?: localFile?.parentFile?.name
                        ?: "الفيديوهات"
                    val relPath = relDirRaw?.let { if (it.isNotBlank()) "$it/$name" else name } ?: name

                    val rawSize = if (sizeCol >= 0 && !cursor.isNull(sizeCol)) cursor.getLong(sizeCol) else 0L
                    val safeSize = rawSize.coerceAtLeast(0L)
                    val pathKey = dataPath?.lowercase(Locale.ROOT)
                    val relKey = "$relPath:$safeSize".lowercase(Locale.ROOT)
                    val bucketKey = "$bucket/$name:$safeSize".lowercase(Locale.ROOT)
                    if (pathKey != null && pathKey in seenCanonicalFiles) continue
                    if (relKey in seenCanonicalFiles || bucketKey in seenCanonicalFiles) continue

                    if (pathKey != null) seenCanonicalFiles.add(pathKey)
                    seenCanonicalFiles.add(relKey)
                    seenCanonicalFiles.add(bucketKey)
                    val dateSec = if (dateCol >= 0 && !cursor.isNull(dateCol)) cursor.getLong(dateCol) else 0L
                    val dateMillis = if (dateSec > 0L) dateSec * 1000L else System.currentTimeMillis()
                    val duration = if (durCol >= 0 && !cursor.isNull(durCol)) cursor.getLong(durCol) else 0L
                    val contentUri = ContentUris.withAppendedId(filesUri, id)
                    val itemId = "vid_f_$id"

                    outList.add(
                        DeviceMediaItem(
                            id = itemId,
                            name = name,
                            uri = contentUri,
                            localFile = localFile,
                            sizeBytes = rawSize.coerceAtLeast(0L),
                            dateModifiedMillis = dateMillis,
                            durationMillis = duration,
                            mimeType = mime ?: "video/mp4",
                            bucketOrFolderName = bucket,
                            relativePathInStorage = relPath,
                            category = FileCategory.VIDEO,
                            thumbnailBitmap = getCachedThumbnail(itemId)
                        )
                    )
                    added++
                }
            }
        } catch (_: Throwable) {
        }
    }

    fun loadAudioFiles(
        context: Context,
        maxItems: Int = 1500,
        offset: Int = 0,
        batchSize: Int = DEFAULT_MEDIA_PAGE_SIZE,
        onBatchLoaded: ((List<DeviceMediaItem>) -> Unit)? = null,
        isCancelled: () -> Boolean = { false }
    ): List<DeviceMediaItem> {
        if (isCancelled() || maxItems <= 0) return emptyList()
        val resolver = context.contentResolver
        val items = ArrayList<DeviceMediaItem>(minOf(maxItems, 256))
        val seenPathsOrNames = HashSet<String>(minOf(maxItems, 256))
        val safeBatchSize = batchSize.coerceAtLeast(20)
        var lastEmittedSize = 0
        val projection = buildList {
            add(MediaStore.Audio.Media._ID)
            add(MediaStore.Audio.Media.DISPLAY_NAME)
            add(MediaStore.Audio.Media.TITLE)
            add(MediaStore.Audio.Media.SIZE)
            add(MediaStore.Audio.Media.DATE_MODIFIED)
            add(MediaStore.Audio.Media.DURATION)
            add(MediaStore.Audio.Media.MIME_TYPE)
            add(MediaStore.Audio.Media.ARTIST)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaStore.MediaColumns.RELATIVE_PATH)
            }
            @Suppress("DEPRECATION")
            add(MediaStore.MediaColumns.DATA)
        }.toTypedArray()
        val sortOrder = "${MediaStore.Audio.Media.DATE_MODIFIED} DESC"
        try {
            resolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
                val titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                val sizeCol = cursor.getColumnIndex(MediaStore.Audio.Media.SIZE)
                val dateCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATE_MODIFIED)
                val durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                val mimeCol = cursor.getColumnIndex(MediaStore.Audio.Media.MIME_TYPE)
                val artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
                val relCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                } else -1
                @Suppress("DEPRECATION")
                val dataCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)

                val canReadCursor = offset == 0 || cursor.moveToPosition(offset - 1)
                var count = 0
                while (canReadCursor && cursor.moveToNext() && count < maxItems) {
                    if ((count and 31) == 0 && isCancelled()) break
                    val id = cursor.getLong(idCol)
                    val dataPath = if (dataCol >= 0) cursor.getString(dataCol) else null
                    val rawSize = if (sizeCol >= 0 && !cursor.isNull(sizeCol)) cursor.getLong(sizeCol) else 0L
                    val localFile = if (!dataPath.isNullOrBlank()) File(dataPath) else null
                    val displayName = (if (nameCol >= 0) cursor.getString(nameCol) else null)
                        ?: localFile?.name
                        ?: (if (titleCol >= 0) cursor.getString(titleCol) else null)
                        ?: "Audio_$id.mp3"
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val size = when {
                        rawSize > 0L -> rawSize
                        count < 30 && localFile != null && localFile.exists() -> localFile.length()
                        count < 15 -> resolveContentUriLength(resolver, contentUri)
                        else -> 0L
                    }

                    val dateSec = if (dateCol >= 0 && !cursor.isNull(dateCol)) cursor.getLong(dateCol) else 0L
                    val dateMillis = if (dateSec > 0L) dateSec * 1000L else System.currentTimeMillis()
                    val duration = if (durCol >= 0 && !cursor.isNull(durCol)) cursor.getLong(durCol) else 0L
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else "audio/mpeg"
                    val artist = if (artistCol >= 0) cursor.getString(artistCol) ?: "" else ""
                    val relDirRaw = if (relCol >= 0) cursor.getString(relCol)?.trim('/') else null
                    val relPath = relDirRaw?.let { if (it.isNotBlank()) "$it/$displayName" else displayName }
                        ?: displayName

                    val dedupKey = (dataPath ?: "$artist/$displayName:$size:$id").lowercase(Locale.ROOT)
                    if (!seenPathsOrNames.add(dedupKey)) continue

                    items.add(
                        DeviceMediaItem(
                            id = "aud_$id",
                            name = displayName,
                            uri = contentUri,
                            localFile = localFile,
                            sizeBytes = size.coerceAtLeast(0L),
                            dateModifiedMillis = dateMillis,
                            durationMillis = duration,
                            mimeType = mime,
                            bucketOrFolderName = artist.ifBlank { "الصوتيات" },
                            relativePathInStorage = relPath,
                            category = FileCategory.AUDIO
                        )
                    )
                    count++

                    if (onBatchLoaded != null && (items.size - lastEmittedSize) >= safeBatchSize) {
                        lastEmittedSize = items.size
                        onBatchLoaded(ArrayList(items))
                    }
                }
            }
        } catch (se: SecurityException) {
            Log.w(LOG_TAG, "SecurityException in loadAudioFiles: ${se.message}")
        } catch (t: Throwable) {
            Log.e(LOG_TAG, "Error querying MediaStore.Audio: ${t.message}", t)
        }

        if (!isCancelled() && offset == 0 && items.size < 20) {
            scanFallbackMediaDirectories(
                targetCategory = FileCategory.AUDIO,
                seenKeys = seenPathsOrNames,
                maxRemaining = minOf(80, maxItems - items.size),
                outList = items,
                isCancelled = isCancelled
            )
        }
        if (onBatchLoaded != null && items.size > lastEmittedSize) {
            onBatchLoaded(ArrayList(items))
        }
        return items
    }

    private fun resolveContentUriLength(resolver: ContentResolver, uri: Uri): Long {
        return try {
            resolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                if (afd.length > 0L) afd.length else 0L
            } ?: 0L
        } catch (_: Throwable) {
            0L
        }
    }

    private fun scanFallbackMediaDirectories(
        targetCategory: FileCategory,
        seenKeys: MutableSet<String>,
        maxRemaining: Int,
        outList: MutableList<DeviceMediaItem>,
        batchSize: Int = DEFAULT_MEDIA_PAGE_SIZE,
        onBatchLoaded: ((List<DeviceMediaItem>) -> Unit)? = null,
        isCancelled: () -> Boolean = { false }
    ) {
        if (maxRemaining <= 0 || isCancelled()) return
        val candidateDirs = mutableListOf<File>()
        try {
            @Suppress("DEPRECATION")
            val extRoot = Environment.getExternalStorageDirectory()
            @Suppress("DEPRECATION")
            val dirs = when (targetCategory) {
                FileCategory.IMAGE -> listOfNotNull(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                    extRoot?.let { File(it, "WhatsApp/Media/WhatsApp Images") },
                    extRoot?.let { File(it, "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images") },
                    extRoot?.let { File(it, "Telegram/Telegram Images") }
                )
                FileCategory.VIDEO -> listOfNotNull(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    extRoot?.let { File(it, "Videos") },
                    extRoot?.let { File(it, "WhatsApp/Media/WhatsApp Video") },
                    extRoot?.let { File(it, "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Video") },
                    extRoot?.let { File(it, "Telegram/Telegram Video") },
                    extRoot?.let { File(it, "Snaptube/download") }
                )
                FileCategory.AUDIO -> listOfNotNull(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PODCASTS),
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_RINGTONES),
                    extRoot?.let { File(it, "WhatsApp/Media/WhatsApp Audio") }
                )
                else -> listOfNotNull(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                )
            }
            candidateDirs.addAll(dirs)
        } catch (_: Throwable) {
        }

        val visitedCanonical = HashSet<String>()
        var added = 0
        var inspectedFiles = 0
        val maxInspectedFiles = 2000
        val safeBatch = batchSize.coerceAtLeast(15)
        var lastEmitted = 0

        fun walk(dir: File, rootName: String, relPrefix: String, depth: Int) {
            if (isCancelled() || added >= maxRemaining || inspectedFiles >= maxInspectedFiles || depth > 6 || !dir.exists() || !dir.isDirectory || !dir.canRead()) return
            val canon = try {
                dir.canonicalPath
            } catch (_: Exception) {
                dir.absolutePath
            }
            if (!visitedCanonical.add(canon)) return
            val children = dir.listFiles() ?: return
            for (child in children) {
                if (isCancelled() || added >= maxRemaining || inspectedFiles >= maxInspectedFiles) break
                if (child.name.startsWith(".")) continue
                val childRel = if (relPrefix.isBlank()) child.name else "$relPrefix/${child.name}"
                if (child.isDirectory && child.canRead()) {
                    walk(child, rootName, childRel, depth + 1)
                } else if (child.isFile && child.canRead()) {
                    inspectedFiles++
                    val cat = FileCategory.fromFileName(child.name)
                    if (cat == targetCategory) {
                        val fileLen = child.length().coerceAtLeast(0L)
                        val absKey = child.absolutePath.lowercase(Locale.ROOT)
                        val relKey = "$childRel:$fileLen".lowercase(Locale.ROOT)
                        val bucketKey = "${dir.name}/${child.name}:$fileLen".lowercase(Locale.ROOT)
                        if (absKey !in seenKeys && relKey !in seenKeys && bucketKey !in seenKeys) {
                            seenKeys.add(absKey)
                            seenKeys.add(relKey)
                            seenKeys.add(bucketKey)
                            val itemId = "fb_${targetCategory.name}_${child.absolutePath.hashCode()}"
                            outList.add(
                                DeviceMediaItem(
                                    id = itemId,
                                    name = child.name,
                                    localFile = child,
                                    sizeBytes = fileLen,
                                    dateModifiedMillis = child.lastModified(),
                                    bucketOrFolderName = dir.name.ifBlank { rootName },
                                    relativePathInStorage = childRel,
                                    category = targetCategory,
                                    thumbnailBitmap = getCachedThumbnail(itemId)
                                )
                            )
                            added++
                            if (onBatchLoaded != null && (outList.size - lastEmitted) >= safeBatch) {
                                lastEmitted = outList.size
                                onBatchLoaded(ArrayList(outList))
                            }
                        }
                    }
                }
            }
        }

        for (root in candidateDirs.distinctBy { it.absolutePath }) {
            if (isCancelled()) break
            @Suppress("DEPRECATION")
            val extRootPath = try {
                Environment.getExternalStorageDirectory()?.absolutePath?.trimEnd('/')
            } catch (_: Throwable) {
                null
            }
            val rootRel = if (!extRootPath.isNullOrBlank() && root.absolutePath.startsWith(extRootPath)) {
                root.absolutePath.removePrefix(extRootPath).trim('/').ifBlank { root.name }
            } else {
                root.name
            }
            walk(root, root.name, rootRel, 0)
        }
    }

    /**
     * Automatically scans already-persisted valid SAF folders for videos/images when MediaStore is sparse,
     * so the user is never repeatedly asked to re-select a SAF folder they already granted.
     */
    private fun scanMediaFromPersistedSafFolders(
        context: Context,
        targetCategory: FileCategory,
        seenKeys: MutableSet<String>,
        maxRemaining: Int,
        outList: MutableList<DeviceMediaItem>,
        isCancelled: () -> Boolean = { false }
    ) {
        if (maxRemaining <= 0 || isCancelled()) return
        val persistedFolders = loadPersistedSafFolders(context).filter { it.isValid }
        if (persistedFolders.isEmpty()) return

        val resolver = context.contentResolver
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        var added = 0

        fun walkSaf(treeUri: Uri, docId: String, folderLabel: String, relPrefix: String, depth: Int) {
            if (isCancelled() || added >= maxRemaining || depth > 3) return
            try {
                val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
                resolver.query(childrenUri, projection, null, null, null)?.use { c ->
                    val idCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                    val nameCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                    val sizeCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_SIZE)
                    val dateCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                    val mimeCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)

                    while (c.moveToNext() && added < maxRemaining && !isCancelled()) {
                        val childDocId = c.getString(idCol) ?: continue
                        val rawName = c.getString(nameCol) ?: continue
                        if (rawName.startsWith(".")) continue
                        val mime = if (mimeCol >= 0) c.getString(mimeCol) else null
                        val childRel = if (relPrefix.isBlank()) rawName else "$relPrefix/$rawName"
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            walkSaf(treeUri, childDocId, rawName, childRel, depth + 1)
                        } else {
                            val cat = FileCategory.fromFileName(rawName, mime)
                            if (cat == targetCategory) {
                                val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childDocId)
                                val size = if (!c.isNull(sizeCol)) c.getLong(sizeCol).coerceAtLeast(0L) else 0L
                                val dedupKey = "$childRel:$size".lowercase(Locale.ROOT)
                                val uriKey = childUri.toString().lowercase(Locale.ROOT)
                                if (dedupKey !in seenKeys && uriKey !in seenKeys) {
                                    seenKeys.add(dedupKey)
                                    seenKeys.add(uriKey)
                                    val lastMod = if (dateCol >= 0 && !c.isNull(dateCol)) c.getLong(dateCol) else System.currentTimeMillis()
                                    val itemId = "saf_media_${childUri.hashCode()}"
                                    outList.add(
                                        DeviceMediaItem(
                                            id = itemId,
                                            name = rawName,
                                            uri = childUri,
                                            sizeBytes = size,
                                            dateModifiedMillis = lastMod,
                                            mimeType = mime,
                                            bucketOrFolderName = folderLabel,
                                            relativePathInStorage = childRel,
                                            category = targetCategory,
                                            thumbnailBitmap = getCachedThumbnail(itemId)
                                        )
                                    )
                                    added++
                                }
                            }
                        }
                    }
                }
            } catch (_: Throwable) {
            }
        }

        for (safFolder in persistedFolders) {
            if (isCancelled() || added >= maxRemaining) break
            walkSaf(safFolder.uri, safFolder.documentId, safFolder.displayName, safFolder.displayName, 0)
        }
    }

    /**
     * Loads general files (Documents, PDFs, ZIP/RAR Archives, APKs, Downloads, Recent files)
     * from MediaStore.Files, MediaStore.Downloads (API 29+), and accessible storage directories.
     */
    private data class RecursiveDirStats(
        val fileCount: Int,
        val subfolderCount: Int,
        val emptySubfolderCount: Int,
        val totalBytes: Long,
        val listFailed: Boolean = false,
        val unreadableCount: Int = 0
    )

    val STANDARD_ROOT_FOLDER_ORDER = listOf(
        "Download",
        "DCIM",
        "Pictures",
        "Movies",
        "Documents",
        "Music",
        "Android",
        "SDCard"
    )

    /**
     * Queries MediaStore.Files and MediaStore.Downloads (API 29+) for all files inside a specific
     * relative folder path (and its nested subfolders), supporting all extensions (.BIG, .DAT, .TGA, etc.)
     * and extensionless files without forcing SAF selection.
     */
    fun queryMediaStoreFilesUnderRelativePath(
        context: Context?,
        relativeFolderPath: String
    ): List<DeviceMediaItem> {
        if (context == null) return emptyList()
        val cleanPrefix = relativeFolderPath.trim().trim('/').replace('\\', '/')
        if (cleanPrefix.isBlank()) return emptyList()
        val lowerPrefix = cleanPrefix.lowercase(Locale.ROOT)
        if (lowerPrefix == "android/data" || lowerPrefix == "android/obb" ||
            lowerPrefix.startsWith("android/data/") || lowerPrefix.startsWith("android/obb/")
        ) {
            return emptyList()
        }

        val resolver = context.contentResolver
        val results = mutableListOf<DeviceMediaItem>()
        val seenKeys = HashSet<String>()

        @Suppress("DEPRECATION")
        val externalRootPath = try {
            Environment.getExternalStorageDirectory()?.absolutePath?.trimEnd('/') ?: "/storage/emulated/0"
        } catch (_: Exception) {
            "/storage/emulated/0"
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
            (cleanPrefix.equals("Download", ignoreCase = true) || cleanPrefix.startsWith("Download/", ignoreCase = true))
        ) {
            val dlProjection = arrayOf(
                MediaStore.Downloads._ID,
                MediaStore.Downloads.DISPLAY_NAME,
                MediaStore.Downloads.SIZE,
                MediaStore.Downloads.DATE_MODIFIED,
                MediaStore.Downloads.MIME_TYPE,
                MediaStore.MediaColumns.RELATIVE_PATH
            )
            try {
                resolver.query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    dlProjection,
                    "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? OR ${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
                    arrayOf("$cleanPrefix/%", "$cleanPrefix/"),
                    "${MediaStore.Downloads.DATE_MODIFIED} DESC"
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID)
                    val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
                    val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.SIZE)
                    val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DATE_MODIFIED)
                    val mimeCol = cursor.getColumnIndex(MediaStore.Downloads.MIME_TYPE)
                    val relCol = cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        val name = cursor.getString(nameCol)?.takeIf { it.isNotBlank() && !it.startsWith(".") } ?: continue
                        val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) continue
                        val relDir = (if (relCol >= 0) cursor.getString(relCol) else null)
                            ?.trim()?.trim('/')?.ifBlank { "Download" } ?: "Download"
                        if (!relDir.equals(cleanPrefix, ignoreCase = true) &&
                            !relDir.startsWith("$cleanPrefix/", ignoreCase = true)
                        ) continue
                        val candidateFile = File(externalRootPath, "$relDir/$name")
                        if (candidateFile.exists() && candidateFile.isDirectory) continue
                        val contentUri = ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id)
                        val cursorSize = cursor.getLong(sizeCol).coerceAtLeast(0L)
                        val diskSize = if (candidateFile.exists() && !candidateFile.isDirectory) {
                            resolveLocalFileByteSize(candidateFile)
                        } else 0L
                        var resolvedSize = max(cursorSize, diskSize)
                        if (resolvedSize == 0L) {
                            resolvedSize = resolveContentUriByteSize(resolver, contentUri)
                        }
                        val relFilePath = "$relDir/$name"
                        if (seenKeys.add(relFilePath.lowercase(Locale.ROOT))) {
                            results.add(
                                DeviceMediaItem(
                                    id = "dl_$id",
                                    name = name,
                                    uri = contentUri,
                                    localFile = candidateFile.takeIf { it.exists() && !it.isDirectory },
                                    sizeBytes = resolvedSize,
                                    dateModifiedMillis = cursor.getLong(dateCol) * 1000L,
                                    mimeType = mime,
                                    bucketOrFolderName = relDir,
                                    relativePathInStorage = relFilePath,
                                    category = FileCategory.fromFileName(name, mime)
                                )
                            )
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }

        val filesUri = MediaStore.Files.getContentUri("external")
        val fileProj = buildList {
            add(MediaStore.Files.FileColumns._ID)
            add(MediaStore.Files.FileColumns.DISPLAY_NAME)
            add(MediaStore.Files.FileColumns.SIZE)
            add(MediaStore.Files.FileColumns.DATE_MODIFIED)
            add(MediaStore.Files.FileColumns.MIME_TYPE)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaStore.MediaColumns.RELATIVE_PATH)
            }
            @Suppress("DEPRECATION")
            add(MediaStore.MediaColumns.DATA)
        }.toTypedArray()

        try {
            val selection: String
            val selectionArgs: Array<String>
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                @Suppress("DEPRECATION")
                selection = "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? OR ${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? OR ${MediaStore.MediaColumns.DATA} LIKE ?"
                selectionArgs = arrayOf("$cleanPrefix/%", "$cleanPrefix/", "%/$cleanPrefix/%")
            } else {
                @Suppress("DEPRECATION")
                selection = "${MediaStore.MediaColumns.DATA} LIKE ?"
                selectionArgs = arrayOf("%/$cleanPrefix/%")
            }
            resolver.query(
                filesUri,
                fileProj,
                selection,
                selectionArgs,
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)
                val mimeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.MIME_TYPE)
                val relCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                } else -1
                @Suppress("DEPRECATION")
                val dataCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val dataPath = if (dataCol >= 0) cursor.getString(dataCol) else null
                    val name = (if (nameCol >= 0) cursor.getString(nameCol)?.takeIf { it.isNotBlank() } else null)
                        ?: dataPath?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
                        ?: continue
                    if (name.startsWith(".")) continue
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) continue
                    val localF = dataPath?.let { File(it) }
                    if (localF != null && localF.exists() && localF.isDirectory) continue

                    val rawRel = if (relCol >= 0) cursor.getString(relCol) else null
                    val relDir = normalizeRelativeDirPath(rawRel, dataPath, name, externalRootPath)
                    if (!relDir.equals(cleanPrefix, ignoreCase = true) &&
                        !relDir.startsWith("$cleanPrefix/", ignoreCase = true)
                    ) continue
                    val cursorSize = cursor.getLong(sizeCol).coerceAtLeast(0L)
                    val recognizedExt = hasRecognizedFileExtension(name)
                    val candidateOnDisk = if (!recognizedExt || cursorSize <= 0L) {
                        File(externalRootPath, if (relDir.isNotBlank()) "$relDir/$name" else name)
                    } else null
                    if (candidateOnDisk != null && candidateOnDisk.exists() && candidateOnDisk.isDirectory) continue

                    val contentUri = ContentUris.withAppendedId(filesUri, id)
                    val diskSize = if (cursorSize <= 0L && localF != null && localF.exists() && !localF.isDirectory) {
                        resolveLocalFileByteSize(localF)
                    } else 0L
                    var resolvedSize = max(cursorSize, diskSize)
                    if (resolvedSize == 0L && !recognizedExt) {
                        resolvedSize = resolveContentUriByteSize(resolver, contentUri)
                    }
                    val relFilePath = if (relDir.isNotBlank()) "$relDir/$name" else name
                    if (seenKeys.add(relFilePath.lowercase(Locale.ROOT))) {
                        results.add(
                            DeviceMediaItem(
                                id = "file_$id",
                                name = name,
                                uri = contentUri,
                                localFile = localF,
                                sizeBytes = resolvedSize,
                                dateModifiedMillis = cursor.getLong(dateCol) * 1000L,
                                mimeType = mime,
                                bucketOrFolderName = relDir,
                                relativePathInStorage = relFilePath,
                                category = FileCategory.fromFileName(name, mime)
                            )
                        )
                    }
                }
            }
        } catch (_: Exception) {
        }

        return results
    }

    fun loadGeneralFilesAndFolders(
        context: Context,
        extraMediaItems: List<DeviceMediaItem> = emptyList()
    ): Pair<List<DeviceMediaItem>, List<StorageFolderItem>> {
        val resolver = context.contentResolver
        val seenKeys = HashSet<String>()
        val allFiles = mutableListOf<DeviceMediaItem>()
        val mediaStoreFolderGroups = LinkedHashMap<String, MutableList<DeviceMediaItem>>()

        @Suppress("DEPRECATION")
        val externalRootPath = try {
            Environment.getExternalStorageDirectory()?.absolutePath?.trimEnd('/') ?: "/storage/emulated/0"
        } catch (_: Exception) {
            "/storage/emulated/0"
        }

        // Cache directory vs file checks per relative path so we do not stat the same folder thousands of times
        val prefixIsFileCache = HashMap<String, Boolean>(256)
        val prefixIsDirCache = HashMap<String, Boolean>(256)

        fun recordMediaStoreFolderItem(relDirRaw: String, item: DeviceMediaItem) {
            val cleanRel = normalizeRelativeDirPath(relDirRaw, null, item.name, externalRootPath)
            if (cleanRel.isBlank()) return
            val lower = cleanRel.lowercase(Locale.ROOT)
            if (lower.startsWith("android/data") || lower.startsWith("android/obb")) return
            val segments = cleanRel.split('/').filter { it.isNotBlank() }
            if (segments.isEmpty()) return
            // Register every directory level from root down to the exact parent folder, never registering a file as a folder
            for (level in 1..segments.size) {
                val segName = segments[level - 1]
                val prefixPath = segments.subList(0, level).joinToString("/")
                val isFileNode = prefixIsFileCache.getOrPut(prefixPath) {
                    val diskNode = File(externalRootPath, prefixPath)
                    diskNode.exists() && diskNode.isFile
                }
                if (isFileNode) break
                if (segName.equals(item.name, ignoreCase = true)) {
                    val isDirNode = prefixIsDirCache.getOrPut(prefixPath) {
                        val diskNode = File(externalRootPath, prefixPath)
                        diskNode.exists() && diskNode.isDirectory
                    }
                    if (!isDirNode) break
                }
                val list = mediaStoreFolderGroups.getOrPut(prefixPath) { mutableListOf() }
                if (list.size < 15000) {
                    list.add(item)
                }
            }
        }

        // Merge preloaded Images, Videos, and Audio items so DCIM, Pictures, Movies, Music, etc. are indexed
        for (extra in extraMediaItems) {
            val rawExtraRel = extra.relativePathInStorage.trim().trim('/')
            val parentFromExtra = normalizeRelativeDirPath(
                rawRel = rawExtraRel.substringBeforeLast('/', ""),
                dataPath = extra.localFile?.absolutePath,
                fileName = extra.name,
                externalRootPath = externalRootPath
            )
            val relDir = parentFromExtra.ifBlank {
                when (extra.category) {
                    FileCategory.IMAGE -> "DCIM"
                    FileCategory.VIDEO -> "Movies"
                    FileCategory.AUDIO -> "Music"
                    else -> "Download"
                }
            }
            val relPath = "$relDir/${extra.name}"
            val key = "${relPath.lowercase(Locale.ROOT)}:${extra.sizeBytes}"
            if (seenKeys.add(key)) {
                val normalizedItem = extra.copy(
                    bucketOrFolderName = relDir,
                    relativePathInStorage = relPath
                )
                allFiles.add(normalizedItem)
                recordMediaStoreFolderItem(relDir, normalizedItem)
            }
        }

        // 1. Query MediaStore.Downloads on API 29+ (including RELATIVE_PATH for subfolders like Download/ropon)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val dlProjection = arrayOf(
                MediaStore.Downloads._ID,
                MediaStore.Downloads.DISPLAY_NAME,
                MediaStore.Downloads.SIZE,
                MediaStore.Downloads.DATE_MODIFIED,
                MediaStore.Downloads.MIME_TYPE,
                MediaStore.MediaColumns.RELATIVE_PATH
            )
            try {
                resolver.query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    dlProjection,
                    null,
                    null,
                    "${MediaStore.Downloads.DATE_MODIFIED} DESC"
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID)
                    val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
                    val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.SIZE)
                    val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DATE_MODIFIED)
                    val mimeCol = cursor.getColumnIndex(MediaStore.Downloads.MIME_TYPE)
                    val relCol = cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)

                    var dlCount = 0
                    while (cursor.moveToNext() && dlCount < 15000) {
                        val id = cursor.getLong(idCol)
                        val name = cursor.getString(nameCol)?.takeIf { it.isNotBlank() } ?: continue
                        if (name.startsWith(".")) continue
                        val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) continue
                        val rawRel = if (relCol >= 0) cursor.getString(relCol) else null
                        val relDir = normalizeRelativeDirPath(rawRel, null, name, externalRootPath)
                            .ifBlank { "Download" }
                        val candidateFile = File(externalRootPath, "$relDir/$name")
                        if (candidateFile.exists() && candidateFile.isDirectory) continue
                        val cursorSize = cursor.getLong(sizeCol).coerceAtLeast(0L)
                        val diskSize = if (candidateFile.exists() && !candidateFile.isDirectory) {
                            resolveLocalFileByteSize(candidateFile)
                        } else 0L
                        val size = max(cursorSize, diskSize)
                        val dateSec = cursor.getLong(dateCol)
                        val uri = ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id)
                        val relFilePath = "$relDir/$name"
                        val key = "${relFilePath.lowercase(Locale.ROOT)}:$size"
                        if (seenKeys.add(key)) {
                            val mediaItem = DeviceMediaItem(
                                id = "dl_$id",
                                name = name,
                                uri = uri,
                                localFile = candidateFile.takeIf { it.exists() && !it.isDirectory },
                                sizeBytes = size,
                                dateModifiedMillis = dateSec * 1000L,
                                mimeType = mime,
                                bucketOrFolderName = relDir,
                                relativePathInStorage = relFilePath,
                                category = FileCategory.fromFileName(name, mime)
                            )
                            allFiles.add(mediaItem)
                            recordMediaStoreFolderItem(relDir, mediaItem)
                            dlCount++
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }

        // 2. Query MediaStore.Files for all file types (including .BIG, .DAT, .TGA, and extensionless files)
        val filesUri = MediaStore.Files.getContentUri("external")
        val fileProj = buildList {
            add(MediaStore.Files.FileColumns._ID)
            add(MediaStore.Files.FileColumns.DISPLAY_NAME)
            add(MediaStore.Files.FileColumns.SIZE)
            add(MediaStore.Files.FileColumns.DATE_MODIFIED)
            add(MediaStore.Files.FileColumns.MIME_TYPE)
            add(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaStore.MediaColumns.RELATIVE_PATH)
            }
            @Suppress("DEPRECATION")
            add(MediaStore.MediaColumns.DATA)
        }.toTypedArray()

        try {
            resolver.query(
                filesUri,
                fileProj,
                null,
                null,
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)
                val mimeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.MIME_TYPE)
                val bucketCol = cursor.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
                val relCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                } else -1
                @Suppress("DEPRECATION")
                val dataCol = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)

                var count = 0
                while (cursor.moveToNext() && count < 20000) {
                    val id = cursor.getLong(idCol)
                    val dataPath = if (dataCol >= 0) cursor.getString(dataCol) else null
                    val name = (if (nameCol >= 0) cursor.getString(nameCol)?.takeIf { it.isNotBlank() } else null)
                        ?: dataPath?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
                        ?: continue
                    if (name.startsWith(".")) continue
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                    val localF = dataPath?.let { File(it) }
                    val rawRel = if (relCol >= 0) cursor.getString(relCol) else null
                    val normalizedRel = normalizeRelativeDirPath(rawRel, dataPath, name, externalRootPath)
                    val bucket = if (bucketCol >= 0) cursor.getString(bucketCol)?.trim()?.trim('/') ?: "" else ""
                    val relDir = normalizedRel.ifBlank {
                        if (bucket.isNotBlank() && !bucket.equals(name, ignoreCase = true) && File(externalRootPath, bucket).isDirectory) {
                            bucket
                        } else ""
                    }
                    val candidateDiskFile = localF ?: File(externalRootPath, if (relDir.isNotBlank()) "$relDir/$name" else name)

                    // Strictly classify directories using File.isDirectory or DocumentsContract.Document.MIME_TYPE_DIR.
                    // Never classify a real file or a file with a known extension (e.g. .tga, .ico, .dat, .big) as a directory.
                    val isActualDirectory = (candidateDiskFile.exists() && candidateDiskFile.isDirectory) ||
                        (mime == DocumentsContract.Document.MIME_TYPE_DIR && !(candidateDiskFile.exists() && candidateDiskFile.isFile) && !hasRecognizedFileExtension(name))
                    if (isActualDirectory) {
                        val dirRelPath = if (relDir.isNotBlank()) "$relDir/$name" else name
                        val cleanDirRel = dirRelPath.trim().trim('/')
                        if (cleanDirRel.isNotBlank() &&
                            !cleanDirRel.startsWith("Android/data", ignoreCase = true) &&
                            !cleanDirRel.startsWith("Android/obb", ignoreCase = true)
                        ) {
                            mediaStoreFolderGroups.putIfAbsent(cleanDirRel, mutableListOf())
                        }
                        continue
                    }

                    val cursorSize = cursor.getLong(sizeCol).coerceAtLeast(0L)
                    val diskSize = if (candidateDiskFile.exists() && candidateDiskFile.isFile) {
                        resolveLocalFileByteSize(candidateDiskFile)
                    } else 0L
                    // If MediaStore has a 0-byte row with no MIME type and no existing file on disk, skip virtual folder nodes
                    if (cursorSize == 0L && diskSize == 0L && mime == null && !candidateDiskFile.exists() && !name.contains('.')) {
                        continue
                    }
                    val size = max(cursorSize, diskSize)
                    val dateSec = cursor.getLong(dateCol)

                    val relFilePath = if (relDir.isNotBlank()) "$relDir/$name" else name
                    val key = "${relFilePath.lowercase(Locale.ROOT)}:$size"
                    if (seenKeys.add(key)) {
                        val contentUri = ContentUris.withAppendedId(filesUri, id)
                        val mediaItem = DeviceMediaItem(
                            id = "file_$id",
                            name = name,
                            uri = contentUri,
                            localFile = candidateDiskFile.takeIf { it.exists() && it.isFile } ?: localF,
                            sizeBytes = size,
                            dateModifiedMillis = dateSec * 1000L,
                            mimeType = mime,
                            bucketOrFolderName = relDir,
                            relativePathInStorage = relFilePath,
                            category = FileCategory.fromFileName(name, mime)
                        )
                        allFiles.add(mediaItem)
                        if (relDir.isNotBlank()) {
                            recordMediaStoreFolderItem(relDir, mediaItem)
                        }
                        count++
                    }
                }
            }
        } catch (_: Exception) {
        }

        // 3. Dynamically read the real Internal Storage Root (/storage/emulated/0) + Public Directories + SD Card
        val rootDirMap = LinkedHashMap<String, File>()
        try {
            @Suppress("DEPRECATION")
            val extRoot = Environment.getExternalStorageDirectory()
            if (extRoot != null && extRoot.exists()) {
                // First, list all real directories and files at the root of shared internal storage
                if (isLocalPathReadable(extRoot)) {
                    extRoot.listFiles()?.forEach { topChild ->
                        if (topChild.name.startsWith(".")) return@forEach
                        if (topChild.isDirectory) {
                            rootDirMap[topChild.name] = topChild
                        } else if (!topChild.isDirectory && isLocalPathReadable(topChild)) {
                            val len = topChild.length().coerceAtLeast(0L)
                            val key = "${topChild.name.lowercase(Locale.ROOT)}:$len"
                            if (seenKeys.add(key)) {
                                allFiles.add(
                                    DeviceMediaItem(
                                        id = "root_disk_${topChild.absolutePath.hashCode()}",
                                        name = topChild.name,
                                        localFile = topChild,
                                        sizeBytes = len,
                                        dateModifiedMillis = topChild.lastModified(),
                                        bucketOrFolderName = "",
                                        relativePathInStorage = topChild.name,
                                        category = FileCategory.fromFileName(topChild.name)
                                    )
                                )
                            }
                        }
                    }
                }
                // Ensure Android directory is registered if it exists on the device
                val androidDir = File(extRoot, "Android")
                if (androidDir.exists() && "Android" !in rootDirMap) {
                    rootDirMap["Android"] = androidDir
                }
            }
        } catch (_: Exception) {
        }

        // Also check standard Android public directories so they are discoverable even when Scoped Storage restricts extRoot.listFiles()
        try {
            @Suppress("DEPRECATION")
            val publicCandidates = buildList {
                add("Download" to (Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) ?: File(externalRootPath, "Download")))
                add("DCIM" to (Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) ?: File(externalRootPath, "DCIM")))
                add("Pictures" to (Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) ?: File(externalRootPath, "Pictures")))
                add("Movies" to (Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES) ?: File(externalRootPath, "Movies")))
                add("Documents" to (Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS) ?: File(externalRootPath, "Documents")))
                add("Music" to (Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC) ?: File(externalRootPath, "Music")))
                add("Notifications" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_NOTIFICATIONS))
                add("Ringtones" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_RINGTONES))
                add("Alarms" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_ALARMS))
                add("Podcasts" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PODCASTS))
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    add("Audiobooks" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_AUDIOBOOKS))
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    add("Recordings" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_RECORDINGS))
                }
                add("Android" to File(externalRootPath, "Android"))
            }
            val coreNames = setOf("Download", "DCIM", "Pictures", "Movies", "Documents", "Music", "Android")
            for ((label, pubDir) in publicCandidates) {
                if (pubDir != null && label !in rootDirMap) {
                    if (pubDir.exists() || label in coreNames || label in mediaStoreFolderGroups) {
                        rootDirMap[label] = pubDir
                    }
                }
            }
        } catch (_: Exception) {
        }

        // Detect Removable SD Card / Secondary Storage Volumes automatically without forcing SAF
        try {
            val externalDirs = context.getExternalFilesDirs(null)
            if (externalDirs != null && externalDirs.size > 1) {
                for (i in 1 until externalDirs.size) {
                    val extAppDir = externalDirs[i] ?: continue
                    val abs = extAppDir.absolutePath.replace('\\', '/')
                    val sdRootPath = abs.substringBefore("/Android/data", "").trimEnd('/')
                    if (sdRootPath.isNotBlank() && sdRootPath != externalRootPath) {
                        val sdRoot = File(sdRootPath)
                        if (sdRoot.exists() && sdRoot.isDirectory && isLocalPathReadable(sdRoot)) {
                            rootDirMap["SDCard"] = sdRoot
                        } else if (extAppDir.exists() && extAppDir.isDirectory) {
                            rootDirMap["SDCard"] = extAppDir
                        }
                    }
                }
            }
        } catch (_: Exception) {
        }

        val discoveredDirs = LinkedHashMap<String, Pair<String, File>>()
        val singlePassStatsMap = HashMap<String, RecursiveDirStats>()
        val fullyInspectedDirs = HashSet<String>()
        val unreadableDirs = HashSet<String>()
        val visitedCollectCanon = HashSet<String>()
        var totalDiskFilesInspected = 0
        // Bounded initial discovery budget so startup completes fast while large folders compute lazily on demand
        val maxDiskFilesToInspect = 3500
        val maxInitialCrawlDepth = 8

        fun collectDirectoriesAndFiles(dir: File, relDisplayPath: String, depth: Int): RecursiveDirStats {
            val lowerPath = dir.absolutePath.lowercase(Locale.ROOT)
            val isProtected = lowerPath.endsWith("/android/data") ||
                lowerPath.endsWith("/android/obb") ||
                lowerPath.contains("/android/data/") ||
                lowerPath.contains("/android/obb/")
            if (isProtected && (!dir.exists() || !isLocalPathReadable(dir) || dir.listFiles() == null)) {
                discoveredDirs.putIfAbsent(dir.absolutePath, relDisplayPath to dir)
                val restricted = RecursiveDirStats(0, 0, 0, 0L, listFailed = true, unreadableCount = 1)
                singlePassStatsMap[dir.absolutePath] = restricted
                unreadableDirs.add(dir.absolutePath)
                return restricted
            }
            if (depth > maxInitialCrawlDepth || !dir.exists() || !dir.isDirectory) {
                return RecursiveDirStats(0, 0, 0, 0L, listFailed = !dir.exists())
            }
            discoveredDirs.putIfAbsent(dir.absolutePath, relDisplayPath to dir)
            if (!isLocalPathReadable(dir)) {
                unreadableDirs.add(dir.absolutePath)
                val empty = RecursiveDirStats(0, 0, 0, 0L, listFailed = true, unreadableCount = 1)
                singlePassStatsMap.putIfAbsent(dir.absolutePath, empty)
                return empty
            }
            if (totalDiskFilesInspected >= maxDiskFilesToInspect) {
                val empty = RecursiveDirStats(0, 0, 0, 0L)
                singlePassStatsMap.putIfAbsent(dir.absolutePath, empty)
                return empty
            }
            val canon = try {
                dir.canonicalPath
            } catch (_: Exception) {
                dir.absolutePath
            }
            if (!visitedCollectCanon.add("$relDisplayPath|$canon")) {
                return singlePassStatsMap[dir.absolutePath] ?: RecursiveDirStats(0, 0, 0, 0L)
            }

            val children = dir.listFiles()
            if (children == null) {
                unreadableDirs.add(dir.absolutePath)
                val failed = RecursiveDirStats(0, 0, 0, 0L, listFailed = true, unreadableCount = 1)
                singlePassStatsMap[dir.absolutePath] = failed
                return failed
            }
            var filesCount = 0
            var subfoldersCount = 0
            var emptySubfoldersCount = 0
            var bytesCount = 0L
            var unreadableChildren = 0
            var wasTruncated = false

            for (child in children) {
                if (child.name.startsWith(".")) continue
                val childRelPath = "$relDisplayPath/${child.name}"
                if (child.isDirectory) {
                    subfoldersCount++
                    discoveredDirs.putIfAbsent(child.absolutePath, childRelPath to child)
                    if (totalDiskFilesInspected < maxDiskFilesToInspect && depth < maxInitialCrawlDepth && isLocalPathReadable(child)) {
                        val subStats = collectDirectoriesAndFiles(child, childRelPath, depth + 1)
                        filesCount += subStats.fileCount
                        subfoldersCount += subStats.subfolderCount
                        emptySubfoldersCount += subStats.emptySubfolderCount
                        bytesCount += subStats.totalBytes
                        unreadableChildren += subStats.unreadableCount
                        if (subStats.listFailed) {
                            unreadableChildren++
                        }
                        if (child.absolutePath !in fullyInspectedDirs) {
                            wasTruncated = true
                        }
                        if (!subStats.listFailed && subStats.fileCount == 0 && subStats.subfolderCount == 0 && child.absolutePath in fullyInspectedDirs) {
                            emptySubfoldersCount++
                        }
                    } else {
                        if (!isLocalPathReadable(child)) {
                            unreadableDirs.add(child.absolutePath)
                            unreadableChildren++
                        }
                        wasTruncated = true
                    }
                } else if (!child.isDirectory) {
                    if (!isLocalPathReadable(child)) {
                        unreadableChildren++
                        continue
                    }
                    filesCount++
                    val len = resolveLocalFileByteSize(child)
                    bytesCount += len
                    if (totalDiskFilesInspected < maxDiskFilesToInspect) {
                        totalDiskFilesInspected++
                        val key = "${childRelPath.lowercase(Locale.ROOT)}:$len"
                        if (seenKeys.add(key)) {
                            val item = DeviceMediaItem(
                                id = "disk_${child.absolutePath.hashCode()}",
                                name = child.name,
                                localFile = child,
                                sizeBytes = len,
                                dateModifiedMillis = child.lastModified(),
                                bucketOrFolderName = relDisplayPath,
                                relativePathInStorage = childRelPath,
                                category = FileCategory.fromFileName(child.name)
                            )
                            allFiles.add(item)
                            recordMediaStoreFolderItem(relDisplayPath, item)
                        }
                    } else {
                        wasTruncated = true
                    }
                }
            }
            val stats = RecursiveDirStats(
                fileCount = filesCount,
                subfolderCount = subfoldersCount,
                emptySubfolderCount = emptySubfoldersCount,
                totalBytes = bytesCount,
                listFailed = false,
                unreadableCount = unreadableChildren
            )
            singlePassStatsMap[dir.absolutePath] = stats
            if (!wasTruncated) {
                fullyInspectedDirs.add(dir.absolutePath)
            }
            return stats
        }

        for ((label, rootDir) in rootDirMap) {
            discoveredDirs.putIfAbsent(rootDir.absolutePath, label to rootDir)
            collectDirectoriesAndFiles(rootDir, label, 0)
        }

        // Also ensure Android/media is indexed if accessible on Android 11+
        try {
            val androidMediaDir = File(externalRootPath, "Android/media")
            if (androidMediaDir.exists() && androidMediaDir.isDirectory && isLocalPathReadable(androidMediaDir)) {
                discoveredDirs.putIfAbsent(androidMediaDir.absolutePath, "Android/media" to androidMediaDir)
                collectDirectoriesAndFiles(androidMediaDir, "Android/media", 1)
            }
        } catch (_: Exception) {
        }

        val folderSummariesByRelPath = LinkedHashMap<String, StorageFolderItem>()

        for ((absPath, pair) in discoveredDirs) {
            val (relDisplay, dir) = pair
            val cachedFolder = sessionFolderStatsCache[absPath]
            val stats = singlePassStatsMap[absPath] ?: RecursiveDirStats(0, 0, 0, 0L)
            val parentLabel = relDisplay.substringBeforeLast('/', "")
            val mediaFallback = mediaStoreFolderGroups[relDisplay].orEmpty()
            val mediaSubfoldersCount = mediaFallback.mapNotNull { item ->
                val afterPrefix = item.relativePathInStorage.removePrefix("$relDisplay/")
                afterPrefix.substringBeforeLast('/', "").takeIf { it.isNotBlank() }?.substringBefore('/')
            }.distinct().size

            val mergedFileCount = max(cachedFolder?.fileCount ?: 0, max(stats.fileCount, mediaFallback.size))
            val mergedSubfolderCount = max(cachedFolder?.subfolderCount ?: 0, max(stats.subfolderCount, mediaSubfoldersCount))
            val mergedBytes = max(cachedFolder?.totalBytes ?: 0L, max(stats.totalBytes, mediaFallback.sumOf { it.sizeBytes }))
            val mergedUnreadable = max(cachedFolder?.unreadableCount ?: 0, stats.unreadableCount)
            val mergedModified = max(
                if (dir.exists()) dir.lastModified() else 0L,
                mediaFallback.maxOfOrNull { it.dateModifiedMillis } ?: 0L
            )
            val lowerRel = relDisplay.lowercase(Locale.ROOT)
            val isProtected = (lowerRel == "android/data" || lowerRel == "android/obb" ||
                lowerRel.startsWith("android/data/") || lowerRel.startsWith("android/obb/")) &&
                (!dir.exists() || !isLocalPathReadable(dir) || dir.listFiles() == null)
            val isUnreadableOrMissing = !dir.exists() || absPath in unreadableDirs || stats.listFailed

            val resolvedStatus = when {
                isProtected -> FolderStatsStatus.ACCESS_RESTRICTED
                isUnreadableOrMissing && mergedFileCount == 0 && mergedSubfolderCount == 0 -> FolderStatsStatus.ACCESS_RESTRICTED
                cachedFolder != null && (cachedFolder.statsStatus == FolderStatsStatus.COMPLETED || cachedFolder.statsStatus == FolderStatsStatus.PARTIALLY_READ || cachedFolder.statsStatus == FolderStatsStatus.APPROXIMATE_CAPPED) ->
                    cachedFolder.statsStatus
                absPath in fullyInspectedDirs && mergedUnreadable > 0 && (mergedFileCount > 0 || mergedSubfolderCount > 0) ->
                    FolderStatsStatus.PARTIALLY_READ
                absPath in fullyInspectedDirs -> FolderStatsStatus.COMPLETED
                else -> FolderStatsStatus.CALCULATING
            }

            val folderItem = StorageFolderItem(
                name = dir.name.ifBlank { relDisplay.substringAfterLast('/') },
                path = absPath,
                relativeDisplayPath = relDisplay,
                parentFolderName = parentLabel,
                fileCount = mergedFileCount,
                subfolderCount = mergedSubfolderCount,
                emptySubfolderCount = max(cachedFolder?.emptySubfolderCount ?: 0, stats.emptySubfolderCount),
                totalBytes = mergedBytes,
                lastModifiedMillis = if (mergedModified > 0L) mergedModified else System.currentTimeMillis(),
                isProtectedSystemFolder = isProtected,
                protectionReason = if (isProtected) {
                    "مجلد نظام محمي في Android 11+ (${relDisplay})؛ يمنع النظام الوصول المباشر إليه."
                } else null,
                mediaStoreFallbackItems = mediaFallback,
                statsStatus = resolvedStatus,
                unreadableCount = mergedUnreadable
            )
            registerFolderItem(folderItem)
            folderSummariesByRelPath[relDisplay] = folderItem
        }

        // Also include all MediaStore-discovered folders (top-level and nested folders)
        for ((relDisplay, itemsInGroup) in mediaStoreFolderGroups) {
            if (relDisplay !in folderSummariesByRelPath && itemsInGroup.isNotEmpty()) {
                val folderName = relDisplay.substringAfterLast('/')
                val parentLabel = relDisplay.substringBeforeLast('/', "")
                val candidateFile = rootDirMap[relDisplay] ?: File(externalRootPath, relDisplay)
                if (candidateFile.exists() && candidateFile.isFile) continue
                val nestedSubdirs = itemsInGroup.mapNotNull { item ->
                    val afterPrefix = item.relativePathInStorage.removePrefix("$relDisplay/")
                    afterPrefix.substringBeforeLast('/', "").takeIf { it.isNotBlank() }?.substringBefore('/')
                }.distinct().size

                val msFolder = StorageFolderItem(
                    name = folderName,
                    path = candidateFile.absolutePath,
                    relativeDisplayPath = relDisplay,
                    parentFolderName = parentLabel,
                    fileCount = itemsInGroup.size,
                    subfolderCount = nestedSubdirs,
                    emptySubfolderCount = 0,
                    totalBytes = itemsInGroup.sumOf { it.sizeBytes },
                    lastModifiedMillis = itemsInGroup.maxOfOrNull { it.dateModifiedMillis } ?: System.currentTimeMillis(),
                    mediaStoreFallbackItems = itemsInGroup,
                    statsStatus = if (candidateFile.exists() && isLocalPathReadable(candidateFile)) {
                        FolderStatsStatus.CALCULATING
                    } else {
                        FolderStatsStatus.COMPLETED
                    }
                )
                registerFolderItem(msFolder)
                folderSummariesByRelPath[relDisplay] = msFolder
            }
        }

        // Ensure discovered rootDirMap folders are present in folderSummariesByRelPath
        for ((rootName, rootFile) in rootDirMap) {
            if (rootName !in folderSummariesByRelPath) {
                val mediaFallback = mediaStoreFolderGroups[rootName].orEmpty()
                val nestedSubdirs = mediaFallback.mapNotNull { item ->
                    val afterPrefix = item.relativePathInStorage.removePrefix("$rootName/")
                    afterPrefix.substringBeforeLast('/', "").takeIf { it.isNotBlank() }?.substringBefore('/')
                }.distinct().size
                val canReadRoot = rootFile.exists() && isLocalPathReadable(rootFile) && rootFile.listFiles() != null
                val rootFolder = StorageFolderItem(
                    name = rootName,
                    path = rootFile.absolutePath,
                    relativeDisplayPath = rootName,
                    parentFolderName = "",
                    fileCount = mediaFallback.size,
                    subfolderCount = nestedSubdirs,
                    emptySubfolderCount = 0,
                    totalBytes = mediaFallback.sumOf { it.sizeBytes },
                    lastModifiedMillis = rootFile.lastModified().takeIf { it > 0L } ?: System.currentTimeMillis(),
                    mediaStoreFallbackItems = mediaFallback,
                    statsStatus = when {
                        canReadRoot -> FolderStatsStatus.CALCULATING
                        mediaFallback.isNotEmpty() -> FolderStatsStatus.COMPLETED
                        else -> FolderStatsStatus.ACCESS_RESTRICTED
                    }
                )
                registerFolderItem(rootFolder)
                folderSummariesByRelPath[rootName] = rootFolder
            }
        }

        val sortedFolders = folderSummariesByRelPath.values.sortedWith(
            compareBy<StorageFolderItem> { folder ->
                val rootIdx = STANDARD_ROOT_FOLDER_ORDER.indexOfFirst {
                    it.equals(folder.relativeDisplayPath, ignoreCase = true)
                }
                when {
                    rootIdx >= 0 -> rootIdx
                    !folder.relativeDisplayPath.contains('/') -> 15
                    folder.relativeDisplayPath.startsWith("Download/", ignoreCase = true) &&
                        !folder.name.equals("BarqSher", ignoreCase = true) -> 30
                    else -> 40
                }
            }
                .thenBy { it.name.lowercase(Locale.ROOT) }
        )

        return allFiles to sortedFolders
    }

    /**
     * Merges preloaded media items (Images, Videos, Audio) into the existing general files and folders
     * index in memory without re-querying MediaStore or re-scanning the filesystem.
     */
    fun mergeMediaItemsIntoIndex(
        existingFiles: List<DeviceMediaItem>,
        existingFolders: List<StorageFolderItem>,
        extraMediaItems: List<DeviceMediaItem>
    ): Pair<List<DeviceMediaItem>, List<StorageFolderItem>> {
        if (extraMediaItems.isEmpty()) return existingFiles to existingFolders

        @Suppress("DEPRECATION")
        val externalRootPath = try {
            Environment.getExternalStorageDirectory()?.absolutePath?.trimEnd('/') ?: "/storage/emulated/0"
        } catch (_: Exception) {
            "/storage/emulated/0"
        }

        val mergedFiles = ArrayList<DeviceMediaItem>(existingFiles.size + extraMediaItems.size)
        val seenKeys = HashSet<String>(existingFiles.size * 2 + extraMediaItems.size)
        for (f in existingFiles) {
            val rel = f.relativePathInStorage.trim('/').lowercase(Locale.ROOT)
            seenKeys.add("$rel:${f.sizeBytes}")
            mergedFiles.add(f)
        }

        val extraByFolderRel = HashMap<String, MutableList<DeviceMediaItem>>()
        for (extra in extraMediaItems) {
            val rawExtraRel = extra.relativePathInStorage.trim().trim('/')
            val parentFromExtra = normalizeRelativeDirPath(
                rawRel = rawExtraRel.substringBeforeLast('/', ""),
                dataPath = extra.localFile?.absolutePath,
                fileName = extra.name,
                externalRootPath = externalRootPath
            )
            val relDir = parentFromExtra.ifBlank {
                when (extra.category) {
                    FileCategory.IMAGE -> "DCIM"
                    FileCategory.VIDEO -> "Movies"
                    FileCategory.AUDIO -> "Music"
                    else -> "Download"
                }
            }
            val relPath = "$relDir/${extra.name}"
            val key = "${relPath.lowercase(Locale.ROOT)}:${extra.sizeBytes}"
            val normalizedItem = extra.copy(
                bucketOrFolderName = relDir,
                relativePathInStorage = relPath
            )
            if (seenKeys.add(key)) {
                mergedFiles.add(normalizedItem)
            }
            val segments = relDir.split('/').filter { it.isNotBlank() }
            for (level in 1..segments.size) {
                val prefixPath = segments.subList(0, level).joinToString("/")
                extraByFolderRel.getOrPut(prefixPath.lowercase(Locale.ROOT)) { mutableListOf() }.add(normalizedItem)
            }
        }

        val folderMap = LinkedHashMap<String, StorageFolderItem>(existingFolders.size + extraByFolderRel.size)
        for (folder in existingFolders) {
            val relLower = folder.relativeDisplayPath.trim('/').lowercase(Locale.ROOT)
            val addedItems = extraByFolderRel[relLower].orEmpty()
            if (addedItems.isNotEmpty()) {
                val combinedFallback = (folder.mediaStoreFallbackItems + addedItems)
                    .distinctBy { it.relativePathInStorage.lowercase(Locale.ROOT) }
                val updated = folder.copy(
                    fileCount = max(folder.fileCount, combinedFallback.size),
                    totalBytes = max(folder.totalBytes, combinedFallback.sumOf { it.sizeBytes }),
                    mediaStoreFallbackItems = combinedFallback
                )
                registerFolderItem(updated)
                folderMap[relLower] = updated
            } else {
                folderMap[relLower] = folder
            }
        }

        return mergedFiles to folderMap.values.toList()
    }

    /**
     * Computes folder statistics on demand (e.g. when the user requests folder properties or selects a folder)
     * on a background thread with a bounded file inspection budget so it never blocks the UI.
     */
    fun computeFolderStatsOnDemand(
        folder: StorageFolderItem,
        maxBudget: Int = 100_000,
        context: Context? = null,
        isCancelled: () -> Boolean = { false }
    ): StorageFolderItem {
        return computeFolderStatsLazy(
            folder = folder,
            context = context,
            maxFilesCap = maxBudget.coerceAtLeast(5000),
            isCancelled = isCancelled
        )
    }

    /**
     * Lazily computes folder statistics (total files, subfolders, and Long byte size) on a background
     * coroutine (Dispatchers.IO), caching the result in [sessionFolderStatsCache] for the current session
     * and supporting cancellation when the user leaves the folder.
     */
    fun computeFolderStatsLazy(
        folder: StorageFolderItem,
        context: Context? = null,
        maxFilesCap: Int = 100_000,
        isCancelled: () -> Boolean = { false }
    ): StorageFolderItem {
        if (folder.isProtectedSystemFolder) {
            return folder.copy(statsStatus = FolderStatsStatus.ACCESS_RESTRICTED)
        }
        val cached = getValidCachedFolderStats(folder.path, context)
        if (cached != null) {
            val mergedCached = folder.copy(
                fileCount = max(folder.fileCount, cached.fileCount),
                subfolderCount = max(folder.subfolderCount, cached.subfolderCount),
                emptySubfolderCount = max(folder.emptySubfolderCount, cached.emptySubfolderCount),
                totalBytes = max(folder.totalBytes, cached.totalBytes),
                statsStatus = cached.statsStatus,
                unreadableCount = max(folder.unreadableCount, cached.unreadableCount)
            )
            registerFolderItem(mergedCached)
            return mergedCached
        }

        if (folder.safTreeUri != null && context != null) {
            val resolver = context.contentResolver
            val treeUri = folder.safTreeUri
            val startDocId = folder.safDocumentId ?: try {
                DocumentsContract.getTreeDocumentId(treeUri)
            } catch (_: Exception) {
                return folder.copy(statsStatus = FolderStatsStatus.ACCESS_RESTRICTED)
            }
            var filesCount = 0
            var subfoldersCount = 0
            var emptySubfoldersCount = 0
            var totalBytes = 0L
            var unreadableCount = 0
            var hitCap = false
            var queryFailed = false
            val projection = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_MIME_TYPE
            )

            fun traverseSaf(docId: String, depth: Int): Int {
                if (depth > 48 || isCancelled() || hitCap) return 0
                var localItems = 0
                try {
                    val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
                    val cursor = resolver.query(childrenUri, projection, null, null, null)
                    if (cursor == null) {
                        if (depth == 0) queryFailed = true else unreadableCount++
                        return 0
                    }
                    cursor.use { c ->
                        val idCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                        val sizeCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_SIZE)
                        val mimeCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
                        while (c.moveToNext()) {
                            if ((filesCount and 31) == 0 && isCancelled()) return localItems
                            if (filesCount >= maxFilesCap) {
                                hitCap = true
                                break
                            }
                            val childId = c.getString(idCol) ?: continue
                            val mime = if (mimeCol >= 0) c.getString(mimeCol) else null
                            if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                                subfoldersCount++
                                localItems++
                                val subItems = traverseSaf(childId, depth + 1)
                                if (subItems == 0 && !hitCap && !isCancelled()) {
                                    emptySubfoldersCount++
                                }
                            } else {
                                filesCount++
                                localItems++
                                val colBytes = if (!c.isNull(sizeCol)) c.getLong(sizeCol).coerceAtLeast(0L) else 0L
                                val resolvedBytes = if (colBytes > 0L) {
                                    colBytes
                                } else {
                                    val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)
                                    resolveContentUriByteSize(resolver, docUri)
                                }
                                totalBytes += resolvedBytes
                            }
                        }
                    }
                } catch (_: Exception) {
                    if (depth == 0) queryFailed = true else unreadableCount++
                }
                return localItems
            }

            traverseSaf(startDocId, 0)
            if (isCancelled()) return folder
            val status = when {
                queryFailed && filesCount == 0 && subfoldersCount == 0 -> FolderStatsStatus.ACCESS_RESTRICTED
                hitCap -> FolderStatsStatus.APPROXIMATE_CAPPED
                unreadableCount > 0 && (filesCount > 0 || subfoldersCount > 0) -> FolderStatsStatus.PARTIALLY_READ
                else -> FolderStatsStatus.COMPLETED
            }
            val updated = folder.copy(
                fileCount = max(folder.fileCount, filesCount),
                subfolderCount = max(folder.subfolderCount, subfoldersCount),
                emptySubfolderCount = max(folder.emptySubfolderCount, emptySubfoldersCount),
                totalBytes = max(folder.totalBytes, totalBytes),
                statsStatus = status,
                unreadableCount = max(folder.unreadableCount, unreadableCount)
            )
            if (status != FolderStatsStatus.ACCESS_RESTRICTED) {
                putCachedFolderStats(updated, context)
            }
            registerFolderItem(updated)
            return updated
        }

        val combinedMediaStoreItems = buildList {
            addAll(folder.mediaStoreFallbackItems)
            if (context != null && folder.relativeDisplayPath.isNotBlank()) {
                val queried = queryMediaStoreFilesUnderRelativePath(context, folder.relativeDisplayPath)
                if (queried.isNotEmpty()) {
                    val existingPaths = folder.mediaStoreFallbackItems
                        .map { it.relativePathInStorage.lowercase(Locale.ROOT) }
                        .toHashSet()
                    for (item in queried) {
                        if (existingPaths.add(item.relativePathInStorage.lowercase(Locale.ROOT))) {
                            add(item)
                        }
                    }
                }
            }
        }

        val cleanFolderRel = folder.relativeDisplayPath.trim().trim('/')
        val prefixSlash = if (cleanFolderRel.isNotBlank()) "$cleanFolderRel/" else ""
        val mediaSubfoldersSet = HashSet<String>()
        for (item in combinedMediaStoreItems) {
            val rel = item.relativePathInStorage.trim('/')
            val afterPrefix = if (prefixSlash.isNotEmpty() && rel.startsWith(prefixSlash, ignoreCase = true)) {
                rel.substring(prefixSlash.length)
            } else {
                rel
            }
            val subDirPath = afterPrefix.substringBeforeLast('/', "")
            if (subDirPath.isNotBlank()) {
                val segments = subDirPath.split('/').filter { it.isNotBlank() }
                for (level in 1..segments.size) {
                    mediaSubfoldersSet.add(segments.subList(0, level).joinToString("/").lowercase(Locale.ROOT))
                }
            }
        }

        val dir = File(folder.path)
        if (!dir.exists() || !dir.isDirectory || !isLocalPathReadable(dir)) {
            val fallbackFiles = combinedMediaStoreItems.size
            val fallbackBytes = combinedMediaStoreItems.sumOf { it.sizeBytes }
            val fallbackSubfolders = mediaSubfoldersSet.size
            val status = if (fallbackFiles > 0 || fallbackSubfolders > 0) {
                FolderStatsStatus.COMPLETED
            } else {
                FolderStatsStatus.ACCESS_RESTRICTED
            }
            val completedFallback = folder.copy(
                fileCount = max(folder.fileCount, fallbackFiles),
                subfolderCount = max(folder.subfolderCount, fallbackSubfolders),
                totalBytes = max(folder.totalBytes, fallbackBytes),
                mediaStoreFallbackItems = combinedMediaStoreItems,
                statsStatus = status
            )
            if (status == FolderStatsStatus.COMPLETED) {
                putCachedFolderStats(completedFallback, context, dir)
            }
            registerFolderItem(completedFallback)
            return completedFallback
        }

        val budget = AtomicInteger(maxFilesCap.coerceAtLeast(1))
        val seenDiskRelativeFiles = HashSet<String>()
        val stats = computeRecursiveDirStats(
            dir = dir,
            maxDepth = 64,
            remainingBudget = budget,
            isCancelled = isCancelled,
            rootPathForRelativeTracking = dir.absolutePath.trimEnd('/'),
            seenRelativeFilePaths = seenDiskRelativeFiles
        )
        if (isCancelled()) return folder

        if (stats.listFailed && stats.fileCount == 0 && stats.subfolderCount == 0 && combinedMediaStoreItems.isEmpty()) {
            val restricted = folder.copy(
                statsStatus = FolderStatsStatus.ACCESS_RESTRICTED,
                unreadableCount = max(1, stats.unreadableCount)
            )
            registerFolderItem(restricted)
            return restricted
        }

        // Union any MediaStore files under this folder that were not already counted via File.listFiles()
        var extraMediaFilesCount = 0
        var extraMediaBytes = 0L
        for (item in combinedMediaStoreItems) {
            val rel = item.relativePathInStorage.trim('/')
            val innerRel = if (prefixSlash.isNotEmpty() && rel.startsWith(prefixSlash, ignoreCase = true)) {
                rel.substring(prefixSlash.length)
            } else {
                item.name
            }.trim('/').lowercase(Locale.ROOT)
            if (innerRel.isNotBlank() && seenDiskRelativeFiles.add(innerRel)) {
                extraMediaFilesCount++
                extraMediaBytes += item.sizeBytes.coerceAtLeast(0L)
            }
        }

        val hitCap = budget.get() <= 0
        val unionFilesCount = stats.fileCount + extraMediaFilesCount
        val unionBytes = stats.totalBytes + extraMediaBytes
        val unionSubfolders = max(stats.subfolderCount, mediaSubfoldersSet.size)
        val resolvedStatus = when {
            hitCap -> FolderStatsStatus.APPROXIMATE_CAPPED
            stats.unreadableCount > 0 && (unionFilesCount > 0 || unionSubfolders > 0) -> FolderStatsStatus.PARTIALLY_READ
            else -> FolderStatsStatus.COMPLETED
        }
        val updated = folder.copy(
            fileCount = max(folder.fileCount, unionFilesCount),
            subfolderCount = max(folder.subfolderCount, unionSubfolders),
            emptySubfolderCount = max(folder.emptySubfolderCount, stats.emptySubfolderCount),
            totalBytes = max(folder.totalBytes, unionBytes),
            mediaStoreFallbackItems = combinedMediaStoreItems,
            statsStatus = resolvedStatus,
            unreadableCount = max(folder.unreadableCount, stats.unreadableCount)
        )
        if (updated.fileCount > 0 || updated.subfolderCount == 0 || Build.VERSION.SDK_INT < Build.VERSION_CODES.R || hasAllFilesAccessPermission(context)) {
            putCachedFolderStats(updated, context, dir)
        }
        registerFolderItem(updated)
        return updated
    }

    private fun computeRecursiveDirStats(
        dir: File,
        maxDepth: Int = 64,
        visitedCanonical: MutableSet<String> = HashSet(),
        remainingBudget: java.util.concurrent.atomic.AtomicInteger = java.util.concurrent.atomic.AtomicInteger(100000),
        isCancelled: () -> Boolean = { false },
        rootPathForRelativeTracking: String? = null,
        seenRelativeFilePaths: MutableSet<String>? = null
    ): RecursiveDirStats {
        if (maxDepth <= 0 || remainingBudget.get() <= 0 || isCancelled()) {
            return RecursiveDirStats(0, 0, 0, 0L)
        }
        if (!dir.exists() || !dir.isDirectory || !isLocalPathReadable(dir)) {
            return RecursiveDirStats(0, 0, 0, 0L, listFailed = true, unreadableCount = 1)
        }
        val canon = try {
            dir.canonicalPath
        } catch (_: Exception) {
            dir.absolutePath
        }
        if (!visitedCanonical.add(canon)) {
            return RecursiveDirStats(0, 0, 0, 0L)
        }
        val list = dir.listFiles() ?: return RecursiveDirStats(0, 0, 0, 0L, listFailed = true, unreadableCount = 1)
        var filesCount = 0
        var subfoldersCount = 0
        var emptySubfoldersCount = 0
        var bytesCount = 0L
        var unreadableCount = 0

        for (idx in list.indices) {
            if ((idx and 31) == 0 && isCancelled()) break
            if (remainingBudget.get() <= 0) break
            val f = list[idx]
            if (f.name.startsWith(".")) continue
            if (f.isDirectory) {
                subfoldersCount++
                if (isLocalPathReadable(f)) {
                    val sub = computeRecursiveDirStats(
                        dir = f,
                        maxDepth = maxDepth - 1,
                        visitedCanonical = visitedCanonical,
                        remainingBudget = remainingBudget,
                        isCancelled = isCancelled,
                        rootPathForRelativeTracking = rootPathForRelativeTracking,
                        seenRelativeFilePaths = seenRelativeFilePaths
                    )
                    filesCount += sub.fileCount
                    subfoldersCount += sub.subfolderCount
                    emptySubfoldersCount += sub.emptySubfolderCount
                    bytesCount += sub.totalBytes
                    unreadableCount += sub.unreadableCount
                    if (sub.listFailed) {
                        unreadableCount++
                    }
                    if (!sub.listFailed && sub.fileCount == 0 && sub.subfolderCount == 0 && remainingBudget.get() > 0 && !isCancelled()) {
                        emptySubfoldersCount++
                    }
                } else {
                    unreadableCount++
                }
            } else if (!f.isDirectory) {
                if (!isLocalPathReadable(f)) {
                    unreadableCount++
                    continue
                }
                remainingBudget.decrementAndGet()
                filesCount++
                bytesCount += resolveLocalFileByteSize(f)
                if (rootPathForRelativeTracking != null && seenRelativeFilePaths != null) {
                    val abs = f.absolutePath.replace('\\', '/')
                    val rel = if (abs.startsWith("$rootPathForRelativeTracking/")) {
                        abs.substring(rootPathForRelativeTracking.length + 1)
                    } else {
                        f.name
                    }
                    seenRelativeFilePaths.add(rel.trim('/').lowercase(Locale.ROOT))
                }
            }
        }
        return RecursiveDirStats(
            fileCount = filesCount,
            subfolderCount = subfoldersCount,
            emptySubfolderCount = emptySubfoldersCount,
            totalBytes = bytesCount,
            listFailed = false,
            unreadableCount = unreadableCount
        )
    }

    data class FolderScanResult(
        val batchInfo: FolderBatchInfo?,
        val transferItems: List<TransferFileItem>,
        val previewMediaItems: List<DeviceMediaItem>,
        val errorMessage: String? = null
    )

    /**
     * Scans a selected StorageFolderItem (such as "Download/ropon") into a single unified FolderBatchInfo
     * and recursive list of TransferFileItems (preserving root folder name, relative paths, subfolders,
     * and empty directories), seamlessly merging local filesystem scan with MediaStore items if needed.
     */
    fun scanStorageFolderItemForTransfer(
        folderItem: StorageFolderItem,
        chunkSizeBytes: Int,
        context: Context? = null
    ): FolderScanResult {
        if (folderItem.isProtectedSystemFolder) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = folderItem.protectionReason
                    ?: "هذا المجلد (${folderItem.relativeDisplayPath}) محمي بسياسة نظام Android 11+ (Android/data أو Android/obb) ولا يسمح النظام بالوصول إليه."
            )
        }
        if (folderItem.safTreeUri != null && context != null) {
            return scanDocumentTreeForTransfer(
                context = context,
                treeUri = folderItem.safTreeUri,
                chunkSizeBytes = chunkSizeBytes,
                startDocId = folderItem.safDocumentId,
                customRootName = folderItem.name
            )
        }
        val rootDir = File(folderItem.path)
        val localResult = if (rootDir.exists() && rootDir.isDirectory && isLocalPathReadable(rootDir)) {
            scanLocalFolderForTransfer(rootDir, chunkSizeBytes)
        } else {
            null
        }

        val combinedFallbackItems = buildList {
            addAll(folderItem.mediaStoreFallbackItems)
            if (context != null && folderItem.relativeDisplayPath.isNotBlank()) {
                val queried = queryMediaStoreFilesUnderRelativePath(context, folderItem.relativeDisplayPath)
                if (queried.isNotEmpty()) {
                    val existingKeys = folderItem.mediaStoreFallbackItems
                        .map { it.relativePathInStorage.lowercase(Locale.ROOT) }
                        .toHashSet()
                    for (qItem in queried) {
                        if (existingKeys.add(qItem.relativePathInStorage.lowercase(Locale.ROOT))) {
                            add(qItem)
                        }
                    }
                }
            }
        }

        val rootFolderName = sanitizePathSegment(folderItem.name.ifBlank { "Folder" })
        val batchId = localResult?.batchInfo?.batchId ?: "fld_${UUID.randomUUID().toString().take(8)}"
        val mergedTransferItems = mutableListOf<TransferFileItem>()
        val mergedPreviewItems = mutableListOf<DeviceMediaItem>()
        val seenRelPaths = HashSet<String>()

        if (localResult != null && localResult.errorMessage == null) {
            for (item in localResult.transferItems) {
                // Keep real files or empty subdirectories; if root itself was marked empty but we have MediaStore items, we'll replace it
                if (item.id.endsWith("_root_empty") && combinedFallbackItems.isNotEmpty()) continue
                mergedTransferItems.add(item)
                seenRelPaths.add(item.relativePath.lowercase(Locale.ROOT))
            }
            mergedPreviewItems.addAll(localResult.previewMediaItems)
        }

        // Merge any MediaStore-indexed files inside this folder that weren't returned by File.listFiles()
        val prefixToRemove = folderItem.relativeDisplayPath.trim('/').let { "$it/" }
        for (media in combinedFallbackItems) {
            val innerRel = if (media.relativePathInStorage.startsWith(prefixToRemove, ignoreCase = true)) {
                media.relativePathInStorage.substring(prefixToRemove.length)
            } else {
                media.name
            }
            val cleanSegments = innerRel.replace('\\', '/').split('/')
                .map { sanitizePathSegment(it) }
                .filter { it.isNotBlank() }
            val fullRelPath = if (cleanSegments.isEmpty()) {
                "$rootFolderName/${sanitizePathSegment(media.name)}"
            } else {
                "$rootFolderName/${cleanSegments.joinToString("/")}"
            }

            if (seenRelPaths.add(fullRelPath.lowercase(Locale.ROOT))) {
                val size = media.sizeBytes.coerceAtLeast(0L)
                val chunks = computeTotalChunksForSize(size, chunkSizeBytes)
                mergedTransferItems.add(
                    TransferFileItem(
                        id = "${batchId}_ms_${mergedTransferItems.size}",
                        name = cleanSegments.lastOrNull() ?: sanitizePathSegment(media.name),
                        sizeBytes = size,
                        category = media.category,
                        uri = media.uri,
                        localFile = media.localFile,
                        relativePath = fullRelPath,
                        rootFolderName = rootFolderName,
                        folderBatchId = batchId,
                        isDirectory = false,
                        totalChunks = chunks,
                        sha256Expected = if (size == 0L) Sha256Util.EMPTY_BYTES_SHA256 else ""
                    )
                )
                mergedPreviewItems.add(media)
            }
        }

        if (mergedTransferItems.isEmpty()) {
            val rootChildren = if (rootDir.exists() && rootDir.isDirectory && isLocalPathReadable(rootDir)) {
                rootDir.listFiles()
            } else null
            val localSkipped = localResult?.batchInfo?.skippedUnreadableCount ?: 0
            if (localResult?.errorMessage != null && combinedFallbackItems.isEmpty()) {
                return FolderScanResult(
                    batchInfo = null,
                    transferItems = emptyList(),
                    previewMediaItems = emptyList(),
                    errorMessage = localResult.errorMessage
                )
            }
            if (!rootDir.exists() && combinedFallbackItems.isEmpty()) {
                return FolderScanResult(
                    batchInfo = null,
                    transferItems = emptyList(),
                    previewMediaItems = emptyList(),
                    errorMessage = "المجلد المحدد (${folderItem.relativeDisplayPath}) غير موجود أو لا يمكن الوصول إليه"
                )
            }
            if ((rootChildren == null || localSkipped > 0 || folderItem.fileCount > 0) &&
                combinedFallbackItems.isEmpty()
            ) {
                return FolderScanResult(
                    batchInfo = null,
                    transferItems = emptyList(),
                    previewMediaItems = emptyList(),
                    errorMessage = "تعذر قراءة ملفات المجلد (${folderItem.relativeDisplayPath}) بسبب قيود الصلاحيات؛ يرجى منح إذن التخزين أو اختياره عبر متصفح النظام (SAF)."
                )
            }
            // Genuinely empty root folder: transfer it as an empty directory unit so receiver creates it
            mergedTransferItems.add(
                TransferFileItem(
                    id = "${batchId}_root_empty",
                    name = rootFolderName,
                    sizeBytes = 0L,
                    category = FileCategory.FOLDER,
                    localFile = rootDir.takeIf { it.exists() },
                    relativePath = rootFolderName,
                    rootFolderName = rootFolderName,
                    folderBatchId = batchId,
                    isDirectory = true,
                    totalChunks = 1,
                    sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                )
            )
        }

        val totalFiles = mergedTransferItems.count { !it.isDirectory }
        val emptyDirs = mergedTransferItems.count { it.isDirectory }
        val totalSubfolders = max(
            localResult?.batchInfo?.totalSubfoldersCount ?: folderItem.subfolderCount,
            emptyDirs
        )
        val totalBytes = mergedTransferItems.filter { !it.isDirectory }.sumOf { it.sizeBytes }

        val batchInfo = FolderBatchInfo(
            batchId = batchId,
            rootFolderName = rootFolderName,
            sourceUriOrPath = folderItem.relativeDisplayPath.ifBlank { folderItem.path },
            totalFilesCount = totalFiles,
            totalSubfoldersCount = totalSubfolders,
            emptyFoldersCount = emptyDirs,
            totalBytes = totalBytes,
            skippedUnreadableCount = localResult?.batchInfo?.skippedUnreadableCount ?: 0,
            hasPersistentPermission = true
        )

        return FolderScanResult(
            batchInfo = batchInfo,
            transferItems = mergedTransferItems,
            previewMediaItems = mergedPreviewItems,
            errorMessage = null
        )
    }

    /**
     * Recursively reads an entire user-selected folder from ACTION_OPEN_DOCUMENT_TREE,
     * persisting read permissions and building a unified transfer manifest that preserves
     * all nested subdirectories, relative paths, empty folders, and 0-byte files.
     */
    fun scanDocumentTreeForTransfer(
        context: Context,
        treeUri: Uri,
        chunkSizeBytes: Int,
        startDocId: String? = null,
        customRootName: String? = null
    ): FolderScanResult {
        val resolver = context.contentResolver
        var hasPersistentPerm = false
        try {
            resolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            hasPersistentPerm = true
        } catch (_: SecurityException) {
            // Provider may only grant transient session read permission
        } catch (_: Exception) {
        }

        val rootDocId = startDocId ?: try {
            DocumentsContract.getTreeDocumentId(treeUri)
        } catch (e: Exception) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "تعذر قراءة معرّف المجلد المختار: ${e.localizedMessage ?: "URI غير صالح"}"
            )
        }

        val lowerDocId = rootDocId.lowercase(Locale.ROOT)
        if (lowerDocId.contains("android/data") || lowerDocId.contains("android/obb")) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "هذا المجلد (${rootDocId}) محمي من نظام Android 11+ (Android/data أو Android/obb) ولا يسمح النظام بالوصول إليه بدون صلاحيات خاصة."
            )
        }

        val rootFolderName = sanitizePathSegment(
            customRootName?.takeIf { it.isNotBlank() } ?: resolveTreeRootFolderName(resolver, treeUri, rootDocId)
        )
        val batchId = "fld_${UUID.randomUUID().toString().take(8)}"
        val transferItems = mutableListOf<TransferFileItem>()
        val previewItems = mutableListOf<DeviceMediaItem>()
        var totalFilesCount = 0
        var totalSubfoldersCount = 0
        var emptyFoldersCount = 0
        var totalBytes = 0L
        var skippedUnreadableCount = 0

        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )

        val visitedDocIds = HashSet<String>()

        data class SafDocRow(
            val childDocId: String,
            val rawName: String,
            val size: Long,
            val lastMod: Long,
            val mime: String?
        )

        fun traverseDir(currentDocId: String, currentRelPath: String, depth: Int): Int {
            if (depth > 24 || !visitedDocIds.add(currentDocId)) return 0
            val childrenUri = try {
                DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, currentDocId)
            } catch (_: Exception) {
                skippedUnreadableCount++
                return -1
            }

            var entriesInThisDir = 0
            val usedSiblingNames = HashSet<String>()

            try {
                val cursor = resolver.query(childrenUri, projection, null, null, null)
                if (cursor == null) {
                    skippedUnreadableCount++
                    return -1
                }
                val rows = mutableListOf<SafDocRow>()
                cursor.use { c ->
                    val idCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                    val nameCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                    val sizeCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_SIZE)
                    val dateCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                    val mimeCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)

                    while (c.moveToNext()) {
                        val childDocId = c.getString(idCol) ?: continue
                        val rawName = c.getString(nameCol) ?: "عنصر_${rows.size + 1}"
                        val mime = if (mimeCol >= 0) c.getString(mimeCol) else null
                        val lastMod = if (dateCol >= 0 && !c.isNull(dateCol)) c.getLong(dateCol) else System.currentTimeMillis()
                        val size = if (!c.isNull(sizeCol)) c.getLong(sizeCol).coerceAtLeast(0L) else 0L
                        rows.add(SafDocRow(childDocId, rawName, size, lastMod, mime))
                    }
                }

                val sortedRows = rows.sortedWith(
                    compareBy<SafDocRow>(
                        { it.mime != DocumentsContract.Document.MIME_TYPE_DIR },
                        { it.rawName.lowercase(Locale.ROOT) }
                    )
                )

                for (row in sortedRows) {
                    val safeName = deduplicateSiblingName(sanitizePathSegment(row.rawName), usedSiblingNames)
                    val childRelPath = "$currentRelPath/$safeName"
                    entriesInThisDir++

                    if (row.mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        totalSubfoldersCount++
                        val subEntries = traverseDir(row.childDocId, childRelPath, depth + 1)
                        if (subEntries == 0) {
                            // Genuinely empty subfolder: add explicit directory item so receiver recreates it
                            emptyFoldersCount++
                            transferItems.add(
                                TransferFileItem(
                                    id = "${batchId}_dir_${transferItems.size}",
                                    name = safeName,
                                    sizeBytes = 0L,
                                    category = FileCategory.FOLDER,
                                    relativePath = childRelPath,
                                    rootFolderName = rootFolderName,
                                    folderBatchId = batchId,
                                    isDirectory = true,
                                    totalChunks = 1,
                                    sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                                )
                            )
                        }
                    } else {
                        var size = row.size
                        val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, row.childDocId)
                        if (size == 0L) {
                            try {
                                resolver.openAssetFileDescriptor(childUri, "r")?.use { afd ->
                                    if (afd.length > 0) size = afd.length
                                }
                            } catch (_: Exception) {
                            }
                        }
                        val chunks = computeTotalChunksForSize(size, chunkSizeBytes)
                        val cat = FileCategory.fromFileName(safeName, row.mime, isDirectory = false)
                        totalFilesCount++
                        totalBytes += size

                        transferItems.add(
                            TransferFileItem(
                                id = "${batchId}_f_${transferItems.size}",
                                name = safeName,
                                sizeBytes = size,
                                category = cat,
                                uri = childUri,
                                relativePath = childRelPath,
                                rootFolderName = rootFolderName,
                                folderBatchId = batchId,
                                isDirectory = false,
                                totalChunks = chunks,
                                sha256Expected = if (size == 0L) Sha256Util.EMPTY_BYTES_SHA256 else ""
                            )
                        )
                        previewItems.add(
                            DeviceMediaItem(
                                id = "saf_${childUri.hashCode()}_${previewItems.size}",
                                name = childRelPath,
                                uri = childUri,
                                sizeBytes = size,
                                dateModifiedMillis = row.lastMod,
                                mimeType = row.mime,
                                bucketOrFolderName = rootFolderName,
                                category = cat
                            )
                        )
                    }
                }
            } catch (se: SecurityException) {
                Log.w(LOG_TAG, "SAF SecurityException reading $currentRelPath: ${se.message}")
                skippedUnreadableCount++
                if (entriesInThisDir == 0) return -1
            } catch (e: Exception) {
                Log.w(LOG_TAG, "SAF error reading $currentRelPath: ${e.message}")
                skippedUnreadableCount++
                if (entriesInThisDir == 0) return -1
            }
            return entriesInThisDir
        }

        val rootEntries = traverseDir(rootDocId, rootFolderName, 0)
        if ((rootEntries < 0 || (rootEntries == 0 && skippedUnreadableCount > 0)) && transferItems.isEmpty()) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "تعذر قراءة محتويات المجلد ($rootFolderName) لأن نظام Android يقيد الوصول إليه."
            )
        }

        // If the selected root folder itself is genuinely empty, still transfer it as an empty directory
        if (transferItems.isEmpty()) {
            emptyFoldersCount = 1
            transferItems.add(
                TransferFileItem(
                    id = "${batchId}_root_empty",
                    name = rootFolderName,
                    sizeBytes = 0L,
                    category = FileCategory.FOLDER,
                    relativePath = rootFolderName,
                    rootFolderName = rootFolderName,
                    folderBatchId = batchId,
                    isDirectory = true,
                    totalChunks = 1,
                    sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                )
            )
        }

        val batchInfo = FolderBatchInfo(
            batchId = batchId,
            rootFolderName = rootFolderName,
            sourceUriOrPath = treeUri.toString(),
            totalFilesCount = totalFilesCount,
            totalSubfoldersCount = totalSubfoldersCount,
            emptyFoldersCount = emptyFoldersCount,
            totalBytes = totalBytes,
            skippedUnreadableCount = skippedUnreadableCount,
            hasPersistentPermission = hasPersistentPerm
        )

        return FolderScanResult(
            batchInfo = batchInfo,
            transferItems = transferItems,
            previewMediaItems = previewItems,
            errorMessage = null
        )
    }

    /**
     * Recursively scans a local java.io.File directory to send the entire folder as one unit,
     * preserving nested subfolders, relative paths, empty directories, and 0-byte files.
     */
    private fun isLocalPathReadable(file: File): Boolean {
        fileReadOperationCount.incrementAndGet()
        if (!file.exists() || !file.canRead()) return false
        if (!file.isDirectory) return true
        return try {
            val perms = java.nio.file.Files.getPosixFilePermissions(file.toPath())
            val absPath = file.absolutePath
            val isAndroidFuseMount = absPath.startsWith("/storage/") || absPath.startsWith("/sdcard")
            if (isAndroidFuseMount) {
                perms.contains(java.nio.file.attribute.PosixFilePermission.OWNER_READ) ||
                    perms.contains(java.nio.file.attribute.PosixFilePermission.GROUP_READ) ||
                    perms.contains(java.nio.file.attribute.PosixFilePermission.OTHERS_READ)
            } else {
                perms.contains(java.nio.file.attribute.PosixFilePermission.OWNER_READ)
            }
        } catch (_: Throwable) {
            true
        }
    }

    fun scanLocalFolderForTransfer(
        rootDir: File,
        chunkSizeBytes: Int
    ): FolderScanResult {
        if (!rootDir.exists() || !rootDir.isDirectory) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "المجلد المحدد غير موجود على الجهاز"
            )
        }
        if (!isLocalPathReadable(rootDir)) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "هذا المجلد (${rootDir.name}) محمي من نظام Android ولا يمكن قراءته بدون إذن خاص"
            )
        }

        val rootFolderName = sanitizePathSegment(rootDir.name.ifBlank { "Folder" })
        val batchId = "fld_${UUID.randomUUID().toString().take(8)}"
        val transferItems = mutableListOf<TransferFileItem>()
        val previewItems = mutableListOf<DeviceMediaItem>()
        var totalFilesCount = 0
        var totalSubfoldersCount = 0
        var emptyFoldersCount = 0
        var totalBytes = 0L
        var skippedUnreadableCount = 0
        val visitedCanonicalPaths = HashSet<String>()

        fun traverseLocal(currentDir: File, currentRelPath: String, depth: Int): Int {
            if (depth > 64) return 0
            if (!isLocalPathReadable(currentDir)) {
                skippedUnreadableCount++
                return -1
            }
            val canon = try {
                currentDir.canonicalPath
            } catch (_: Exception) {
                currentDir.absolutePath
            }
            if (!visitedCanonicalPaths.add(canon)) {
                return 0
            }
            val children = currentDir.listFiles()
            if (children == null) {
                skippedUnreadableCount++
                return -1
            }

            val sortedChildren = children.sortedWith(
                compareBy<File>(
                    { !it.isDirectory },
                    { it.name.lowercase(Locale.ROOT) }
                )
            )
            val usedSiblingNames = HashSet<String>()
            var entriesInThisDir = 0

            for (child in sortedChildren) {
                if (child.name.startsWith(".")) continue
                val safeName = deduplicateSiblingName(sanitizePathSegment(child.name), usedSiblingNames)
                val childRelPath = "$currentRelPath/$safeName"
                entriesInThisDir++

                if (child.isDirectory) {
                    totalSubfoldersCount++
                    val subCount = traverseLocal(child, childRelPath, depth + 1)
                    if (subCount == 0) {
                        emptyFoldersCount++
                        transferItems.add(
                            TransferFileItem(
                                id = "${batchId}_dir_${transferItems.size}",
                                name = safeName,
                                sizeBytes = 0L,
                                category = FileCategory.FOLDER,
                                localFile = child,
                                relativePath = childRelPath,
                                rootFolderName = rootFolderName,
                                folderBatchId = batchId,
                                isDirectory = true,
                                totalChunks = 1,
                                sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                            )
                        )
                    }
                } else if (!child.isDirectory) {
                    if (!isLocalPathReadable(child)) {
                        skippedUnreadableCount++
                        continue
                    }
                    val size = resolveLocalFileByteSize(child)
                    val chunks = computeTotalChunksForSize(size, chunkSizeBytes)
                    val cat = FileCategory.fromFileName(safeName, isDirectory = false)
                    totalFilesCount++
                    totalBytes += size

                    transferItems.add(
                        TransferFileItem(
                            id = "${batchId}_f_${transferItems.size}",
                            name = safeName,
                            sizeBytes = size,
                            category = cat,
                            localFile = child,
                            relativePath = childRelPath,
                            rootFolderName = rootFolderName,
                            folderBatchId = batchId,
                            isDirectory = false,
                            totalChunks = chunks,
                            sha256Expected = if (size == 0L) Sha256Util.EMPTY_BYTES_SHA256 else ""
                        )
                    )
                    previewItems.add(
                        DeviceMediaItem(
                            id = "local_${child.absolutePath.hashCode()}",
                            name = childRelPath,
                            localFile = child,
                            sizeBytes = size,
                            dateModifiedMillis = child.lastModified(),
                            bucketOrFolderName = rootFolderName,
                            relativePathInStorage = childRelPath,
                            category = cat
                        )
                    )
                }
            }
            return entriesInThisDir
        }

        val rootEntries = traverseLocal(rootDir, rootFolderName, 0)
        if ((rootEntries < 0 || (rootEntries == 0 && skippedUnreadableCount > 0)) && transferItems.isEmpty()) {
            return FolderScanResult(
                batchInfo = null,
                transferItems = emptyList(),
                previewMediaItems = emptyList(),
                errorMessage = "تعذر قراءة محتويات المجلد (${rootDir.name}) بسبب قيود الصلاحيات؛ يرجى اختياره عبر متصفح النظام (SAF)."
            )
        }

        if (transferItems.isEmpty()) {
            emptyFoldersCount = 1
            transferItems.add(
                TransferFileItem(
                    id = "${batchId}_root_empty",
                    name = rootFolderName,
                    sizeBytes = 0L,
                    category = FileCategory.FOLDER,
                    localFile = rootDir,
                    relativePath = rootFolderName,
                    rootFolderName = rootFolderName,
                    folderBatchId = batchId,
                    isDirectory = true,
                    totalChunks = 1,
                    sha256Expected = Sha256Util.EMPTY_DIR_SHA256
                )
            )
        }

        val batchInfo = FolderBatchInfo(
            batchId = batchId,
            rootFolderName = rootFolderName,
            sourceUriOrPath = rootDir.absolutePath,
            totalFilesCount = totalFilesCount,
            totalSubfoldersCount = totalSubfoldersCount,
            emptyFoldersCount = emptyFoldersCount,
            totalBytes = totalBytes,
            skippedUnreadableCount = skippedUnreadableCount,
            hasPersistentPermission = true
        )

        return FolderScanResult(
            batchInfo = batchInfo,
            transferItems = transferItems,
            previewMediaItems = previewItems,
            errorMessage = null
        )
    }

    private fun resolveTreeRootFolderName(
        resolver: ContentResolver,
        treeUri: Uri,
        rootDocId: String
    ): String {
        try {
            val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootDocId)
            resolver.query(
                docUri,
                arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
                null,
                null,
                null
            )?.use { c ->
                if (c.moveToFirst()) {
                    val name = c.getString(0)
                    if (!name.isNullOrBlank()) return name
                }
            }
        } catch (_: Exception) {
        }
        val decoded = try {
            URLDecoder.decode(rootDocId, "UTF-8")
        } catch (_: Exception) {
            rootDocId
        }
        return decoded.substringAfterLast(':').substringAfterLast('/').ifBlank { "مجلد_مرسل" }
    }

    fun sanitizePathSegment(raw: String): String {
        val cleaned = raw.trim()
            .replace('\\', '_')
            .replace('/', '_')
            .replace(":", "_")
            .replace("*", "_")
            .replace("?", "_")
            .replace("\"", "_")
            .replace("<", "_")
            .replace(">", "_")
            .replace("|", "_")
        return if (cleaned.isBlank() || cleaned == "." || cleaned == "..") "مجلد" else cleaned
    }

    fun deduplicateSiblingName(baseName: String, usedNamesLower: MutableSet<String>): String {
        val lower = baseName.lowercase(Locale.ROOT)
        if (usedNamesLower.add(lower)) return baseName
        val dotIdx = baseName.lastIndexOf('.')
        val stem = if (dotIdx > 0) baseName.substring(0, dotIdx) else baseName
        val ext = if (dotIdx > 0) baseName.substring(dotIdx) else ""
        var counter = 1
        while (true) {
            val candidate = "$stem ($counter)$ext"
            if (usedNamesLower.add(candidate.lowercase(Locale.ROOT))) {
                return candidate
            }
            counter++
        }
    }

    /**
     * Reads files inside a user-picked SAF folder (OpenDocumentTree) for previewing in Files tab.
     */
    fun loadFilesFromDocumentTree(context: Context, treeUri: Uri): List<DeviceMediaItem> {
        return scanDocumentTreeForTransfer(context, treeUri, 1024 * 1024).previewMediaItems
    }

    /**
     * Takes a persistable URI permission via ContentResolver (Read + Write where supported, falling back to Read)
     * and persists the folder entry in SharedPreferences ("barq_saf_prefs") additively without overwriting or
     * replacing any previously saved user folders.
     */
    fun persistAndSaveSafFolder(
        context: Context,
        treeUri: Uri,
        customDisplayName: String? = null
    ): SafValidationResult {
        val resolver = context.contentResolver
        try {
            val rwFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            try {
                resolver.takePersistableUriPermission(treeUri, rwFlags)
            } catch (_: SecurityException) {
                resolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } catch (e: Exception) {
            Log.w(LOG_TAG, "takePersistableUriPermission warning for $treeUri: ${e.message}")
        }

        val docId = try {
            DocumentsContract.getTreeDocumentId(treeUri)
        } catch (_: Exception) {
            treeUri.lastPathSegment ?: "root"
        }
        val resolvedName = customDisplayName?.takeIf { it.isNotBlank() }
            ?: resolveTreeRootFolderName(resolver, treeUri, docId)

        saveSafEntryToPrefsAdditive(
            context = context,
            uriString = treeUri.toString(),
            displayName = resolvedName,
            documentId = docId,
            revokedOverride = false
        )

        val validation = validateSafTreeUri(context, treeUri)
        return if (validation.isValid) {
            validation.copy(
                displayName = resolvedName.ifBlank { validation.displayName },
                documentId = docId.ifBlank { validation.documentId }
            )
        } else {
            // If ContentResolver in test/custom environment accepted the URI, treat newly persisted URI as valid
            SafValidationResult(
                uri = treeUri,
                status = SafUriStatus.VALID,
                displayName = resolvedName,
                documentId = docId,
                message = SafUriStatus.VALID.arabicLabel
            )
        }
    }

    private fun saveSafEntryToPrefsAdditive(
        context: Context,
        uriString: String,
        displayName: String,
        documentId: String,
        revokedOverride: Boolean = false
    ) {
        try {
            val prefs = context.getSharedPreferences(SAF_PREFS_NAME, Context.MODE_PRIVATE)
            val existingRaw = prefs.getString(SAF_SAVED_URIS_KEY, "[]") ?: "[]"
            val arr = try {
                JSONArray(existingRaw)
            } catch (_: Exception) {
                JSONArray()
            }
            val updatedArr = JSONArray()
            var found = false
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val existingUri = obj.optString("uri")
                if (existingUri == uriString) {
                    found = true
                    obj.put("displayName", displayName.ifBlank { obj.optString("displayName", "مجلد SAF") })
                    obj.put("documentId", documentId.ifBlank { obj.optString("documentId", "") })
                    obj.put("revokedOverride", revokedOverride)
                    obj.put("updatedAt", System.currentTimeMillis())
                }
                updatedArr.put(obj)
            }
            if (!found) {
                val newObj = JSONObject().apply {
                    put("uri", uriString)
                    put("displayName", displayName.ifBlank { "مجلد SAF" })
                    put("documentId", documentId)
                    put("revokedOverride", revokedOverride)
                    put("updatedAt", System.currentTimeMillis())
                }
                updatedArr.put(newObj)
            }
            prefs.edit().putString(SAF_SAVED_URIS_KEY, updatedArr.toString()).apply()
        } catch (e: Exception) {
            Log.w(LOG_TAG, "Failed saving SAF entry to prefs: ${e.message}")
        }
    }

    /**
     * Marks a saved SAF URI as having its permission revoked or folder deleted (useful for testing
     * or when the system reports a SecurityException on access) without deleting the user's record
     * silently before notifying them.
     */
    fun markSafFolderRevoked(context: Context, treeUri: Uri, releaseSystemPermission: Boolean = false) {
        if (releaseSystemPermission) {
            runCatching {
                context.contentResolver.releasePersistableUriPermission(
                    treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
            runCatching {
                context.contentResolver.releasePersistableUriPermission(
                    treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
        }
        val docId = runCatching { DocumentsContract.getTreeDocumentId(treeUri) }.getOrDefault("")
        val name = resolveTreeRootFolderName(context.contentResolver, treeUri, docId)
        saveSafEntryToPrefsAdditive(
            context = context,
            uriString = treeUri.toString(),
            displayName = name,
            documentId = docId,
            revokedOverride = true
        )
    }

    /**
     * Validates a SAF tree URI before using it:
     * 1. Verifies URI structure and extracts treeDocumentId.
     * 2. Checks ContentResolver.persistedUriPermissions and saved SharedPreferences state.
     * 3. Verifies that the folder has not been deleted or had its permission revoked.
     */
    fun validateSafTreeUri(context: Context, treeUri: Uri): SafValidationResult {
        val isFileScheme = treeUri.scheme == ContentResolver.SCHEME_FILE
        val isContentScheme = treeUri.scheme == ContentResolver.SCHEME_CONTENT && !treeUri.authority.isNullOrBlank()
        if (!isContentScheme && !isFileScheme) {
            return SafValidationResult(
                uri = treeUri,
                status = SafUriStatus.INVALID_URI,
                message = "رابط المجلد غير صالح: يرجى اختيار مجلد صالح عبر نظام الملفات (SAF)."
            )
        }

        val docId = if (isContentScheme) {
            try {
                DocumentsContract.getTreeDocumentId(treeUri)
            } catch (_: Exception) {
                return SafValidationResult(
                    uri = treeUri,
                    status = SafUriStatus.INVALID_URI,
                    message = "رابط المجلد لا يمثل شجرة مجلدات SAF صالحة."
                )
            }
        } else {
            treeUri.path?.takeIf { it.isNotBlank() } ?: ""
        }

        if (docId.isBlank()) {
            return SafValidationResult(
                uri = treeUri,
                status = SafUriStatus.INVALID_URI,
                message = "معرّف المجلد فارغ أو غير صالح."
            )
        }

        val resolver = context.contentResolver
        val prefs = context.getSharedPreferences(SAF_PREFS_NAME, Context.MODE_PRIVATE)
        val rawJson = prefs.getString(SAF_SAVED_URIS_KEY, "[]") ?: "[]"
        var savedName: String? = null
        var isRevokedOverride = false
        var existsInSavedPrefs = false
        try {
            val arr = JSONArray(rawJson)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                if (obj.optString("uri") == treeUri.toString()) {
                    existsInSavedPrefs = true
                    savedName = obj.optString("displayName").takeIf { it.isNotBlank() }
                    isRevokedOverride = obj.optBoolean("revokedOverride", false)
                    break
                }
            }
        } catch (_: Exception) {
        }

        if (isRevokedOverride) {
            val fallbackName = savedName ?: resolveTreeRootFolderName(resolver, treeUri, docId)
            return SafValidationResult(
                uri = treeUri,
                status = SafUriStatus.PERMISSION_REVOKED,
                displayName = fallbackName,
                documentId = docId,
                message = "تم إلغاء صلاحية الوصول للمجلد ($fallbackName)؛ يرجى إعادة منح الصلاحية للوصول إليه."
            )
        }

        if (isFileScheme) {
            val dir = treeUri.path?.let { File(it) }
            val fallbackName = savedName ?: dir?.name ?: "مجلد SAF"
            if (dir == null || !dir.exists() || !dir.isDirectory) {
                return SafValidationResult(
                    uri = treeUri,
                    status = SafUriStatus.FOLDER_DELETED_OR_UNREADABLE,
                    displayName = fallbackName,
                    documentId = docId,
                    message = "المجلد المحفوظ ($fallbackName) لم يعد موجوداً أو تم حذفه من الهاتف."
                )
            }
            if (!existsInSavedPrefs) {
                return SafValidationResult(
                    uri = treeUri,
                    status = SafUriStatus.PERMISSION_REVOKED,
                    displayName = fallbackName,
                    documentId = docId,
                    message = "انتهت أو أُلغيت صلاحية الوصول إلى المجلد ($fallbackName). يرجى إعادة اختيار المجلد عند الحاجة."
                )
            }
            return SafValidationResult(
                uri = treeUri,
                status = SafUriStatus.VALID,
                displayName = fallbackName,
                documentId = docId,
                message = SafUriStatus.VALID.arabicLabel
            )
        }

        if (isRevokedOverride) {
            val fallbackName = savedName ?: resolveTreeRootFolderName(resolver, treeUri, docId)
            return SafValidationResult(
                uri = treeUri,
                status = SafUriStatus.PERMISSION_REVOKED,
                displayName = fallbackName,
                documentId = docId,
                message = "تم إلغاء صلاحية الوصول للمجلد ($fallbackName)؛ يرجى إعادة منح الصلاحية للوصول إليه."
            )
        }

        val hasSystemPersistablePerm = try {
            resolver.persistedUriPermissions.any { it.uri == treeUri && it.isReadPermission }
        } catch (_: Exception) {
            false
        }

        // Probe root document or child documents to verify readability and existence
        var securityRevoked = false
        var folderMissing = false
        var queriedDisplayName: String? = null

        try {
            val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
            resolver.query(
                docUri,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE
                ),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    queriedDisplayName = cursor.getString(0)?.takeIf { it.isNotBlank() }
                } else {
                    folderMissing = true
                }
            }
        } catch (_: SecurityException) {
            securityRevoked = true
        } catch (_: java.io.FileNotFoundException) {
            folderMissing = true
        } catch (_: Exception) {
        }

        if (securityRevoked || (!hasSystemPersistablePerm && savedName == null && queriedDisplayName == null)) {
            val fallbackName = savedName ?: resolveTreeRootFolderName(resolver, treeUri, docId)
            return SafValidationResult(
                uri = treeUri,
                status = SafUriStatus.PERMISSION_REVOKED,
                displayName = fallbackName,
                documentId = docId,
                message = "انتهت أو أُلغيت صلاحية الوصول إلى المجلد ($fallbackName). يرجى إعادة اختيار المجلد عند الحاجة."
            )
        }

        if (folderMissing && !hasSystemPersistablePerm) {
            val fallbackName = savedName ?: resolveTreeRootFolderName(resolver, treeUri, docId)
            return SafValidationResult(
                uri = treeUri,
                status = SafUriStatus.FOLDER_DELETED_OR_UNREADABLE,
                displayName = fallbackName,
                documentId = docId,
                message = "المجلد المحفوظ ($fallbackName) لم يعد موجوداً أو تم حذفه من الهاتف."
            )
        }

        val finalName = queriedDisplayName
            ?: savedName
            ?: resolveTreeRootFolderName(resolver, treeUri, docId)

        return SafValidationResult(
            uri = treeUri,
            status = SafUriStatus.VALID,
            displayName = finalName,
            documentId = docId,
            message = SafUriStatus.VALID.arabicLabel
        )
    }

    fun hasValidPersistedSafPermission(context: Context, treeUri: Uri): Boolean {
        return validateSafTreeUri(context, treeUri).isValid
    }

    /**
     * Returns all saved/persisted SAF folders including their current validation status
     * (VALID, PERMISSION_REVOKED, or FOLDER_DELETED_OR_UNREADABLE), preserving the user's
     * saved folders across app restarts without ever overwriting or losing user selections.
     */
    fun loadAllSavedSafFoldersWithStatus(context: Context): List<PersistedSafFolderItem> {
        val resolver = context.contentResolver
        val mergedByUri = LinkedHashMap<String, PersistedSafFolderItem>()
        val now = System.currentTimeMillis()

        // 1. Load from system ContentResolver.persistedUriPermissions
        try {
            val perms = resolver.persistedUriPermissions
            for (perm in perms) {
                if (!perm.isReadPermission) continue
                val uri = perm.uri
                val docId = try {
                    DocumentsContract.getTreeDocumentId(uri)
                } catch (_: Exception) {
                    continue
                }
                val validation = validateSafTreeUri(context, uri)
                val name = validation.displayName.ifBlank {
                    resolveTreeRootFolderName(resolver, uri, docId)
                }
                // Sync into SharedPreferences additively so it is always remembered
                if (validation.isValid) {
                    saveSafEntryToPrefsAdditive(
                        context = context,
                        uriString = uri.toString(),
                        displayName = name,
                        documentId = docId,
                        revokedOverride = false
                    )
                }
                mergedByUri[uri.toString()] = PersistedSafFolderItem(
                    uri = uri,
                    displayName = name,
                    documentId = docId,
                    isValid = validation.isValid,
                    status = validation.status,
                    statusMessage = validation.message,
                    lastVerifiedMillis = now
                )
            }
        } catch (_: Exception) {
        }

        // 2. Merge with SharedPreferences ("barq_saf_prefs") so persisted folders survive process restarts
        //    and any revoked/deleted folders are accurately detected and reported.
        try {
            val prefs = context.getSharedPreferences(SAF_PREFS_NAME, Context.MODE_PRIVATE)
            val rawJson = prefs.getString(SAF_SAVED_URIS_KEY, "[]") ?: "[]"
            val arr = JSONArray(rawJson)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val uriStr = obj.optString("uri").trim()
                if (uriStr.isBlank() || uriStr in mergedByUri) continue
                val uri = Uri.parse(uriStr)
                val savedName = obj.optString("displayName", "مجلد SAF")
                val savedDocId = obj.optString("documentId").ifBlank {
                    runCatching { DocumentsContract.getTreeDocumentId(uri) }.getOrDefault("")
                }
                val validation = validateSafTreeUri(context, uri)
                mergedByUri[uriStr] = PersistedSafFolderItem(
                    uri = uri,
                    displayName = validation.displayName.ifBlank { savedName },
                    documentId = validation.documentId.ifBlank { savedDocId },
                    isValid = validation.isValid,
                    status = validation.status,
                    statusMessage = validation.message,
                    lastVerifiedMillis = now
                )
            }
        } catch (_: Exception) {
        }

        return mergedByUri.values.toList()
    }

    /**
     * Returns all valid persisted SAF directory trees granted by the user via ACTION_OPEN_DOCUMENT_TREE.
     */
    fun loadPersistedSafFolders(context: Context): List<PersistedSafFolderItem> {
        return loadAllSavedSafFoldersWithStatus(context).filter { it.isValid }
    }

    /**
     * Lists the immediate child folders and files inside a granted SAF tree URI (at root or any nested documentId),
     * enabling full hierarchical folder navigation and selection inside SAF directories without blocking N+1 queries.
     */
    fun browseSafDirectoryChildren(
        context: Context,
        treeUri: Uri,
        parentDocId: String?,
        parentDisplayPath: String,
        onPartialResult: ((List<StorageFolderItem>, List<DeviceMediaItem>) -> Unit)? = null,
        isCancelled: () -> Boolean = { false }
    ): Pair<List<StorageFolderItem>, List<DeviceMediaItem>> {
        if (isCancelled()) return emptyList<StorageFolderItem>() to emptyList()
        val resolver = context.contentResolver
        val docId = parentDocId ?: try {
            DocumentsContract.getTreeDocumentId(treeUri)
        } catch (_: Exception) {
            return emptyList<StorageFolderItem>() to emptyList()
        }

        val childFolders = mutableListOf<StorageFolderItem>()
        val childFiles = mutableListOf<DeviceMediaItem>()
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )

        try {
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
            resolver.query(childrenUri, projection, null, null, null)?.use { c ->
                val totalRows = c.count
                // Only run subfolder item count queries if there are very few items (<= 8) so large SAF folders open instantly
                val allowSubfolderCountQuery = totalRows in 1..8
                val idCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                val nameCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                val sizeCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_SIZE)
                val dateCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                val mimeCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)

                var rowIdx = 0
                var partialEmitted = false
                while (c.moveToNext()) {
                    if ((rowIdx and 31) == 0 && isCancelled()) {
                        return childFolders to childFiles
                    }
                    rowIdx++
                    val childDocId = c.getString(idCol) ?: continue
                    val rawName = c.getString(nameCol) ?: "عنصر"
                    val mime = if (mimeCol >= 0) c.getString(mimeCol) else null
                    val lastMod = if (dateCol >= 0 && !c.isNull(dateCol)) c.getLong(dateCol) else System.currentTimeMillis()
                    val cleanParent = parentDisplayPath.trim('/')
                    val childRelPath = if (cleanParent.isEmpty()) rawName else "$cleanParent/$rawName"

                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        var subFiles = 0
                        var subFolders = 0
                        var subBytes = 0L
                        if (allowSubfolderCountQuery && !isCancelled()) {
                            try {
                                val subUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, childDocId)
                                resolver.query(subUri, projection, null, null, null)?.use { sc ->
                                    val sSizeCol = sc.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_SIZE)
                                    val sMimeCol = sc.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
                                    while (sc.moveToNext()) {
                                        val sm = if (sMimeCol >= 0) sc.getString(sMimeCol) else null
                                        if (sm == DocumentsContract.Document.MIME_TYPE_DIR) {
                                            subFolders++
                                        } else {
                                            subFiles++
                                            if (!sc.isNull(sSizeCol)) {
                                                subBytes += sc.getLong(sSizeCol).coerceAtLeast(0L)
                                            }
                                        }
                                    }
                                }
                            } catch (_: Exception) {
                            }
                        }
                        val safFolderPath = "saf://$treeUri#$childDocId"
                        val cachedSafFolder = sessionFolderStatsCache[safFolderPath]
                        val initialSafStatus = when {
                            cachedSafFolder != null && (cachedSafFolder.statsStatus == FolderStatsStatus.COMPLETED || cachedSafFolder.statsStatus == FolderStatsStatus.APPROXIMATE_CAPPED) ->
                                cachedSafFolder.statsStatus
                            allowSubfolderCountQuery && subFolders == 0 -> FolderStatsStatus.COMPLETED
                            else -> FolderStatsStatus.CALCULATING
                        }
                        val safFolder = StorageFolderItem(
                            name = rawName,
                            path = safFolderPath,
                            relativeDisplayPath = childRelPath,
                            parentFolderName = cleanParent,
                            fileCount = max(cachedSafFolder?.fileCount ?: 0, subFiles),
                            subfolderCount = max(cachedSafFolder?.subfolderCount ?: 0, subFolders),
                            emptySubfolderCount = if (allowSubfolderCountQuery && subFiles == 0 && subFolders == 0) 1 else (cachedSafFolder?.emptySubfolderCount ?: 0),
                            totalBytes = max(cachedSafFolder?.totalBytes ?: 0L, subBytes),
                            lastModifiedMillis = lastMod,
                            safTreeUri = treeUri,
                            safDocumentId = childDocId,
                            statsStatus = initialSafStatus
                        )
                        registerFolderItem(safFolder)
                        childFolders.add(safFolder)
                    } else {
                        val colSize = if (!c.isNull(sizeCol)) c.getLong(sizeCol).coerceAtLeast(0L) else 0L
                        val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childDocId)
                        val size = if (colSize > 0L) colSize else resolveContentUriByteSize(resolver, childUri)
                        val itemId = "saf_nav_${childUri.hashCode()}"
                        childFiles.add(
                            DeviceMediaItem(
                                id = itemId,
                                name = rawName,
                                uri = childUri,
                                sizeBytes = size,
                                dateModifiedMillis = lastMod,
                                mimeType = mime,
                                bucketOrFolderName = cleanParent,
                                relativePathInStorage = childRelPath,
                                category = FileCategory.fromFileName(rawName, mime),
                                thumbnailBitmap = getCachedThumbnail(itemId)
                            )
                        )
                    }

                    if (!partialEmitted && totalRows > 100 && (childFolders.size + childFiles.size) >= 80) {
                        partialEmitted = true
                        onPartialResult?.invoke(ArrayList(childFolders), ArrayList(childFiles))
                    }
                }
            }
        } catch (_: Exception) {
        }
        return childFolders.sortedBy { it.name.lowercase(Locale.ROOT) } to
            childFiles.sortedBy { it.name.lowercase(Locale.ROOT) }
    }

    /**
     * Lists the immediate child folders and immediate child files inside the root of shared internal storage
     * (when browsingRelOrAbsPath is blank or "/") or inside a specific relative/absolute folder path
     * (e.g. "Download", "Android", "DCIM", "Download/ropon"), merging actual filesystem contents with
     * MediaStore-indexed items without blocking or recursively scanning nested subfolders.
     */
    fun browseLocalDirectoryChildren(
        browsingRelOrAbsPath: String,
        allKnownFolders: List<StorageFolderItem>,
        allKnownFiles: List<DeviceMediaItem>,
        context: Context? = null,
        onPartialResult: ((List<StorageFolderItem>, List<DeviceMediaItem>) -> Unit)? = null,
        isCancelled: () -> Boolean = { false }
    ): Pair<List<StorageFolderItem>, List<DeviceMediaItem>> {
        if (isCancelled()) return emptyList<StorageFolderItem>() to emptyList()

        @Suppress("DEPRECATION")
        val extRoot = try {
            Environment.getExternalStorageDirectory()
        } catch (_: Exception) {
            null
        }
        val externalRootPath = extRoot?.absolutePath?.trimEnd('/') ?: "/storage/emulated/0"
        val rawTrimmed = browsingRelOrAbsPath.trim().replace('\\', '/')
        val cleanRel = rawTrimmed.trim('/')
        val isRootBrowsing = cleanRel.isEmpty()

        // Build O(1) lookup maps so we never run O(N * M) linear scans on large directories
        val knownFoldersByRel = HashMap<String, StorageFolderItem>(allKnownFolders.size * 2 + 16)
        val knownFoldersByPath = HashMap<String, StorageFolderItem>(allKnownFolders.size * 2 + 16)
        for (f in allKnownFolders) {
            knownFoldersByRel.putIfAbsent(f.relativeDisplayPath.trim('/').lowercase(Locale.ROOT), f)
            knownFoldersByPath.putIfAbsent(f.path, f)
        }

        val knownFilesByPath = HashMap<String, DeviceMediaItem>(allKnownFiles.size * 2 + 16)
        val knownFilesByRel = HashMap<String, DeviceMediaItem>(allKnownFiles.size * 2 + 16)
        for (file in allKnownFiles) {
            file.localFile?.absolutePath?.let { knownFilesByPath.putIfAbsent(it, file) }
            val r = file.relativePathInStorage.trim('/').lowercase(Locale.ROOT)
            if (r.isNotBlank()) knownFilesByRel.putIfAbsent(r, file)
        }

        if (isRootBrowsing) {
            val rootFolders = LinkedHashMap<String, StorageFolderItem>()
            val rootFiles = LinkedHashMap<String, DeviceMediaItem>()

            // 1. Read actual root of shared internal storage (/storage/emulated/0)
            if (extRoot != null && extRoot.exists() && isLocalPathReadable(extRoot)) {
                val rawRootChildren = extRoot.listFiles().orEmpty()
                for (child in rawRootChildren) {
                    if (isCancelled()) return emptyList<StorageFolderItem>() to emptyList()
                    if (child.name.startsWith(".")) continue
                    val keyLower = child.name.lowercase(Locale.ROOT)
                    if (child.isDirectory) {
                        val existing = sessionFolderStatsCache[child.absolutePath] ?: knownFoldersByRel[keyLower] ?: knownFoldersByPath[child.absolutePath]
                        if (existing != null) {
                            rootFolders[keyLower] = existing
                        } else {
                            val canReadChild = isLocalPathReadable(child) && child.listFiles() != null
                            rootFolders[keyLower] = StorageFolderItem(
                                name = child.name,
                                path = child.absolutePath,
                                relativeDisplayPath = child.name,
                                parentFolderName = "",
                                fileCount = 0,
                                subfolderCount = 0,
                                emptySubfolderCount = 0,
                                totalBytes = 0L,
                                lastModifiedMillis = child.lastModified().takeIf { it > 0L } ?: System.currentTimeMillis(),
                                statsStatus = if (canReadChild) FolderStatsStatus.CALCULATING else FolderStatsStatus.ACCESS_RESTRICTED
                            )
                        }
                    } else if (!child.isDirectory && isLocalPathReadable(child)) {
                        val existingFile = knownFilesByPath[child.absolutePath] ?: knownFilesByRel[keyLower]
                        val mediaItem = existingFile ?: DeviceMediaItem(
                            id = "root_disk_${child.absolutePath.hashCode()}",
                            name = child.name,
                            localFile = child,
                            sizeBytes = child.length().coerceAtLeast(0L),
                            dateModifiedMillis = child.lastModified(),
                            bucketOrFolderName = "",
                            relativePathInStorage = child.name,
                            category = FileCategory.fromFileName(child.name)
                        )
                        rootFiles[keyLower] = mediaItem
                    }
                }
            }

            // 2. Merge top-level folders discovered via MediaStore or standard Android public directories + SDCard
            for (folder in allKnownFolders) {
                val rel = folder.relativeDisplayPath.trim('/')
                if (rel.isNotBlank() && !rel.contains('/')) {
                    rootFolders.putIfAbsent(rel.lowercase(Locale.ROOT), sessionFolderStatsCache[folder.path] ?: folder)
                }
            }
            for (file in allKnownFiles) {
                val rel = file.relativePathInStorage.trim('/')
                if (rel.isNotBlank() && !rel.contains('/') && file.bucketOrFolderName.isBlank()) {
                    rootFiles.putIfAbsent(file.name.lowercase(Locale.ROOT), file)
                }
            }

            // 3. Ensure core Android root directories are present even before MediaStore finishes indexing
            val coreRootNames = listOf("Download", "DCIM", "Pictures", "Movies", "Documents", "Music", "Android")
            for (coreName in coreRootNames) {
                val keyLower = coreName.lowercase(Locale.ROOT)
                if (keyLower !in rootFolders) {
                    val f = File(externalRootPath, coreName)
                    val cachedCore = sessionFolderStatsCache[f.absolutePath]
                    val canReadCore = f.exists() && isLocalPathReadable(f) && f.listFiles() != null
                    rootFolders[keyLower] = cachedCore ?: StorageFolderItem(
                        name = coreName,
                        path = f.absolutePath,
                        relativeDisplayPath = coreName,
                        parentFolderName = "",
                        fileCount = 0,
                        subfolderCount = 0,
                        emptySubfolderCount = 0,
                        totalBytes = 0L,
                        lastModifiedMillis = if (f.exists()) f.lastModified() else System.currentTimeMillis(),
                        statsStatus = if (canReadCore) FolderStatsStatus.CALCULATING else FolderStatsStatus.ACCESS_RESTRICTED
                    )
                }
            }

            return rootFolders.values.toList() to rootFiles.values.toList()
        }

        // Resolve target directory supporting deep nested subfolders (e.g. Download/a/b/c, SDCard/x/y/z, or absolute paths)
        val directMatchFolder = knownFoldersByRel[cleanRel.lowercase(Locale.ROOT)]
            ?: knownFoldersByPath[rawTrimmed]
            ?: knownFoldersByPath["/$cleanRel"]

        var ancestorFolder: StorageFolderItem? = null
        var ancestorRemainder = ""
        if (directMatchFolder == null && cleanRel.contains('/')) {
            val segments = cleanRel.split('/').filter { it.isNotBlank() }
            for (i in (segments.size - 1) downTo 1) {
                val candidatePrefix = segments.subList(0, i).joinToString("/").lowercase(Locale.ROOT)
                val found = knownFoldersByRel[candidatePrefix]
                if (found != null) {
                    ancestorFolder = found
                    ancestorRemainder = segments.subList(i, segments.size).joinToString("/")
                    break
                }
            }
        }

        val targetDir: File? = when {
            directMatchFolder != null -> File(directMatchFolder.path)
            ancestorFolder != null -> File(File(ancestorFolder.path), ancestorRemainder)
            File(rawTrimmed).isAbsolute && File(rawTrimmed).exists() -> File(rawTrimmed)
            File("/$cleanRel").exists() && !cleanRel.startsWith("storage/emulated/0", ignoreCase = true) -> File("/$cleanRel")
            extRoot != null -> File(extRoot, cleanRel)
            else -> File(externalRootPath, cleanRel)
        }
        val displayPrefix = when {
            directMatchFolder != null -> directMatchFolder.relativeDisplayPath.trim('/')
            ancestorFolder != null -> "${ancestorFolder.relativeDisplayPath.trim('/')}/$ancestorRemainder"
            else -> cleanRel
        }

        // Gather all MediaStore items under displayPrefix (from both preloaded allKnownFiles and live MediaStore query)
        val prefixSlash = "$displayPrefix/"
        val scopedMediaFilesMap = LinkedHashMap<String, DeviceMediaItem>()
        for (file in allKnownFiles) {
            val relFile = file.relativePathInStorage.trim('/')
            if (file.bucketOrFolderName.equals(displayPrefix, ignoreCase = true) ||
                relFile.startsWith(prefixSlash, ignoreCase = true)
            ) {
                val key = relFile.ifBlank { "$displayPrefix/${file.name}" }.lowercase(Locale.ROOT)
                scopedMediaFilesMap.putIfAbsent(key, file)
            }
        }
        val canReadTargetDirectly = targetDir != null && targetDir.exists() && targetDir.isDirectory && isLocalPathReadable(targetDir)
        val rawDirectChildren = if (canReadTargetDirectly) targetDir?.listFiles() else null

        // Run live MediaStore query when full storage access is not granted, when preloaded index is empty,
        // or when direct directory listing is unavailable/empty so no MediaStore-indexed file ever disappears.
        val shouldQueryMediaStoreLive = context != null && (
            !hasAllFilesAccessPermission(context) ||
                allKnownFiles.isEmpty() ||
                rawDirectChildren == null ||
                rawDirectChildren.isEmpty() ||
                scopedMediaFilesMap.isEmpty()
            )
        if (shouldQueryMediaStoreLive && context != null) {
            for (queriedFile in queryMediaStoreFilesUnderRelativePath(context, displayPrefix)) {
                val relFile = queriedFile.relativePathInStorage.trim('/')
                val key = relFile.ifBlank { "$displayPrefix/${queriedFile.name}" }.lowercase(Locale.ROOT)
                scopedMediaFilesMap.putIfAbsent(key, queriedFile)
            }
        }

        // Group MediaStore items by immediate child subfolder name under displayPrefix
        val mediaItemsByImmediateSubfolder = HashMap<String, MutableList<DeviceMediaItem>>()
        for (mediaFile in scopedMediaFilesMap.values) {
            val relFile = mediaFile.relativePathInStorage.trim('/')
            if (relFile.startsWith(prefixSlash, ignoreCase = true)) {
                val remainder = relFile.substring(prefixSlash.length).trim('/')
                if (remainder.contains('/')) {
                    val immediateSubName = remainder.substringBefore('/').trim()
                    if (immediateSubName.isNotBlank() && !immediateSubName.equals(mediaFile.name, ignoreCase = true)) {
                        val candidateSubDir = if (targetDir != null) File(targetDir, immediateSubName) else File(externalRootPath, "$displayPrefix/$immediateSubName")
                        if (!(candidateSubDir.exists() && candidateSubDir.isFile)) {
                            val subRelLower = "$displayPrefix/$immediateSubName".lowercase(Locale.ROOT)
                            mediaItemsByImmediateSubfolder.getOrPut(subRelLower) { mutableListOf() }.add(mediaFile)
                        }
                    }
                }
            }
        }

        val immediateSubfolders = LinkedHashMap<String, StorageFolderItem>()
        val immediateFiles = LinkedHashMap<String, DeviceMediaItem>()
        var partialEmitted = false

        // 1. Inspect direct filesystem children of targetDir (Depth = 1 ONLY; recursive subfolder stats run asynchronously in background)
        if (rawDirectChildren != null && rawDirectChildren.isNotEmpty()) {
            for (idx in rawDirectChildren.indices) {
                if ((idx and 63) == 0 && isCancelled()) {
                    return immediateSubfolders.values.toList() to immediateFiles.values.toList()
                }
                val child = rawDirectChildren[idx]
                val name = child.name
                if (name.isEmpty() || name.startsWith(".")) continue
                val childRel = if (displayPrefix.isBlank()) name else "$displayPrefix/$name"
                val childRelLower = childRel.lowercase(Locale.ROOT)

                if (child.isDirectory) {
                    val lowerAbs = child.absolutePath.lowercase(Locale.ROOT)
                    val isAndroidRestrictedPath = lowerAbs.endsWith("/android/data") || lowerAbs.endsWith("/android/obb") ||
                        lowerAbs.contains("/android/data/") || lowerAbs.contains("/android/obb/")
                    val canReadChild = isLocalPathReadable(child) && (!isAndroidRestrictedPath || child.listFiles() != null)
                    val isProtected = isAndroidRestrictedPath && !canReadChild

                    val childMediaFallback = mediaItemsByImmediateSubfolder[childRelLower].orEmpty()
                    val cachedStats = getValidCachedFolderStats(child.absolutePath, context, child)
                    val existingSummary = cachedStats ?: knownFoldersByRel[childRelLower] ?: knownFoldersByPath[child.absolutePath]

                    if (isProtected || (!canReadChild && childMediaFallback.isEmpty())) {
                        val restrictedFolder = StorageFolderItem(
                            name = name,
                            path = child.absolutePath,
                            relativeDisplayPath = childRel,
                            parentFolderName = displayPrefix,
                            fileCount = existingSummary?.fileCount ?: 0,
                            subfolderCount = existingSummary?.subfolderCount ?: 0,
                            emptySubfolderCount = existingSummary?.emptySubfolderCount ?: 0,
                            totalBytes = existingSummary?.totalBytes ?: 0L,
                            lastModifiedMillis = child.lastModified(),
                            mediaStoreFallbackItems = childMediaFallback,
                            isProtectedSystemFolder = isProtected,
                            protectionReason = if (isProtected) {
                                "مجلد نظام محمي في Android 11+ (${childRel})؛ يمنع النظام الوصول المباشر إليه لحماية خصوصية التطبيقات."
                            } else null,
                            statsStatus = FolderStatsStatus.ACCESS_RESTRICTED,
                            unreadableCount = 1
                        )
                        registerFolderItem(restrictedFolder)
                        immediateSubfolders[childRelLower] = restrictedFolder
                    } else if (cachedStats != null) {
                        val updatedExisting = cachedStats.copy(
                            fileCount = max(cachedStats.fileCount, childMediaFallback.size),
                            totalBytes = max(cachedStats.totalBytes, childMediaFallback.sumOf { it.sizeBytes }),
                            mediaStoreFallbackItems = if (cachedStats.mediaStoreFallbackItems.isNotEmpty()) cachedStats.mediaStoreFallbackItems else childMediaFallback
                        )
                        registerFolderItem(updatedExisting)
                        immediateSubfolders[childRelLower] = updatedExisting
                    } else {
                        val pendingFolder = StorageFolderItem(
                            name = name,
                            path = child.absolutePath,
                            relativeDisplayPath = childRel,
                            parentFolderName = displayPrefix,
                            fileCount = max(existingSummary?.fileCount ?: 0, childMediaFallback.size),
                            subfolderCount = existingSummary?.subfolderCount ?: 0,
                            emptySubfolderCount = existingSummary?.emptySubfolderCount ?: 0,
                            totalBytes = max(existingSummary?.totalBytes ?: 0L, childMediaFallback.sumOf { it.sizeBytes }),
                            lastModifiedMillis = child.lastModified(),
                            mediaStoreFallbackItems = childMediaFallback,
                            isProtectedSystemFolder = false,
                            statsStatus = FolderStatsStatus.CALCULATING
                        )
                        registerFolderItem(pendingFolder)
                        immediateSubfolders[childRelLower] = pendingFolder
                    }
                } else if (!child.isDirectory) {
                    val existingFile = knownFilesByPath[child.absolutePath] ?: knownFilesByRel[childRelLower]
                    val diskLen = resolveLocalFileByteSize(child)
                    val mediaItem = if (existingFile != null) {
                        existingFile.copy(
                            localFile = existingFile.localFile ?: child,
                            sizeBytes = max(existingFile.sizeBytes, diskLen)
                        )
                    } else {
                        DeviceMediaItem(
                            id = "disk_${child.absolutePath.hashCode()}",
                            name = name,
                            localFile = child,
                            sizeBytes = diskLen,
                            dateModifiedMillis = child.lastModified(),
                            bucketOrFolderName = displayPrefix,
                            relativePathInStorage = childRel,
                            category = FileCategory.fromFileName(name)
                        )
                    }
                    immediateFiles[name.lowercase(Locale.ROOT)] = mediaItem
                }

                // Emit first progressive batch immediately for large directories so UI renders in < 30ms
                if (!partialEmitted && rawDirectChildren.size > 140 && (immediateSubfolders.size + immediateFiles.size) >= 100) {
                    partialEmitted = true
                    onPartialResult?.invoke(
                        immediateSubfolders.values.toList(),
                        immediateFiles.values.toList()
                    )
                }
            }
        }

        // Special support when browsing "Android": ensure data, media, and obb subfolders are visible with accurate OS protection status
        if (displayPrefix.equals("Android", ignoreCase = true) && targetDir != null) {
            for (subName in listOf("media", "data", "obb")) {
                val subRel = "Android/$subName"
                val subRelLower = subRel.lowercase(Locale.ROOT)
                if (subRelLower !in immediateSubfolders) {
                    val subFile = File(targetDir, subName)
                    val canReadSub = subFile.exists() && isLocalPathReadable(subFile) && subFile.listFiles() != null
                    val isRestricted = (subName == "data" || subName == "obb") && !canReadSub
                    if (subFile.exists() || subName == "data" || subName == "obb" || subName == "media") {
                        val androidSub = StorageFolderItem(
                            name = subName,
                            path = subFile.absolutePath,
                            relativeDisplayPath = subRel,
                            parentFolderName = "Android",
                            fileCount = 0,
                            subfolderCount = 0,
                            emptySubfolderCount = 0,
                            totalBytes = 0L,
                            lastModifiedMillis = if (subFile.exists()) subFile.lastModified() else System.currentTimeMillis(),
                            isProtectedSystemFolder = isRestricted,
                            protectionReason = if (isRestricted) {
                                "يقيد نظام Android 11+ الوصول المباشر إلى ($subRel) لحماية بيانات التطبيقات. يمكنك استخدام SAF للمجلدات المسموحة."
                            } else null,
                            statsStatus = if (canReadSub) FolderStatsStatus.CALCULATING else FolderStatsStatus.ACCESS_RESTRICTED
                        )
                        registerFolderItem(androidSub)
                        immediateSubfolders[subRelLower] = androidSub
                    }
                }
            }
        }

        // 2. Merge immediate files from scopedMediaFilesMap (MediaStore + allKnownFiles) before merging virtual folders
        for (file in scopedMediaFilesMap.values) {
            val relFile = file.relativePathInStorage.trim('/')
            val diskF = file.localFile ?: if (targetDir != null) File(targetDir, file.name) else File(externalRootPath, relFile)
            if (diskF.exists() && diskF.isDirectory) continue
            if (file.bucketOrFolderName.equals(displayPrefix, ignoreCase = true)) {
                immediateFiles.putIfAbsent(file.name.lowercase(Locale.ROOT), file)
            } else if (relFile.startsWith(prefixSlash, ignoreCase = true)) {
                val remainder = relFile.substring(prefixSlash.length).trim('/')
                if (remainder.isNotBlank() && !remainder.contains('/')) {
                    immediateFiles.putIfAbsent(file.name.lowercase(Locale.ROOT), file)
                }
            }
        }

        // 3. Merge immediate subfolders from allKnownFolders and MediaStore subfolder groups (never allowing files as folders)
        for (folder in allKnownFolders) {
            val rel = folder.relativeDisplayPath.trim('/')
            if (rel.startsWith(prefixSlash, ignoreCase = true)) {
                val remainder = rel.substring(prefixSlash.length).trim('/')
                if (remainder.isNotBlank() && !remainder.contains('/')) {
                    val folderDisk = File(folder.path)
                    if (folderDisk.exists() && folderDisk.isFile) continue
                    if (remainder.lowercase(Locale.ROOT) in immediateFiles) continue
                    val key = rel.lowercase(Locale.ROOT)
                    val current = immediateSubfolders[key]
                    if (current == null || (current.fileCount == 0 && folder.fileCount > 0)) {
                        registerFolderItem(folder)
                        immediateSubfolders[key] = folder
                    }
                }
            }
        }
        for ((subRelLower, subMediaItems) in mediaItemsByImmediateSubfolder) {
            if (subRelLower !in immediateSubfolders && subMediaItems.isNotEmpty()) {
                val subName = subMediaItems.first().relativePathInStorage.trim('/')
                    .substring(prefixSlash.length)
                    .substringBefore('/')
                    .ifBlank { subRelLower.substringAfterLast('/') }
                if (subName.lowercase(Locale.ROOT) in immediateFiles) continue
                val subRel = "$displayPrefix/$subName"
                val subFile = if (targetDir != null) File(targetDir, subName) else File(externalRootPath, subRel)
                if (subFile.exists() && subFile.isFile) continue
                val nestedDirsCount = subMediaItems.mapNotNull { item ->
                    val afterSub = item.relativePathInStorage.trim('/').removePrefix("$subRel/")
                    afterSub.substringBeforeLast('/', "").takeIf { it.isNotBlank() }?.substringBefore('/')
                }.distinct().size
                val msSubFolder = StorageFolderItem(
                    name = subName,
                    path = subFile.absolutePath,
                    relativeDisplayPath = subRel,
                    parentFolderName = displayPrefix,
                    fileCount = subMediaItems.size,
                    subfolderCount = nestedDirsCount,
                    emptySubfolderCount = 0,
                    totalBytes = subMediaItems.sumOf { it.sizeBytes },
                    lastModifiedMillis = subMediaItems.maxOfOrNull { it.dateModifiedMillis } ?: System.currentTimeMillis(),
                    mediaStoreFallbackItems = subMediaItems,
                    statsStatus = if (subFile.exists() && isLocalPathReadable(subFile)) {
                        FolderStatsStatus.CALCULATING
                    } else {
                        FolderStatsStatus.COMPLETED
                    }
                )
                registerFolderItem(msSubFolder)
                immediateSubfolders[subRelLower] = msSubFolder
            }
        }

        return immediateSubfolders.values.sortedBy { it.name.lowercase(Locale.ROOT) } to
            immediateFiles.values.sortedBy { it.name.lowercase(Locale.ROOT) }
    }

    /**
     * Deeply searches folders and files inside [activeBrowsingPath] (or across all storage roots when null/blank)
     * on Dispatchers.IO so users can search for any mod file (.BIG, .DAT, .TGA, .ZIP, .RAR, Index, or extensionless)
     * at any nested depth without blocking the UI.
     */
    fun searchFilesAndFoldersInPath(
        query: String,
        activeBrowsingPath: String?,
        allKnownFolders: List<StorageFolderItem>,
        allKnownFiles: List<DeviceMediaItem>,
        context: Context? = null,
        maxResults: Int = 500
    ): Pair<List<StorageFolderItem>, List<DeviceMediaItem>> {
        val q = query.trim().lowercase(Locale.ROOT)
        if (q.isEmpty()) return emptyList<StorageFolderItem>() to emptyList()

        val matchedFolders = LinkedHashMap<String, StorageFolderItem>()
        val matchedFiles = LinkedHashMap<String, DeviceMediaItem>()
        val cleanActive = activeBrowsingPath?.trim()?.trim('/')?.replace('\\', '/').orEmpty()
        val activePrefixSlash = if (cleanActive.isNotEmpty()) "$cleanActive/" else ""

        for (folder in allKnownFolders) {
            val rel = folder.relativeDisplayPath.trim('/')
            val inScope = cleanActive.isEmpty() ||
                rel.startsWith(activePrefixSlash, ignoreCase = true) ||
                folder.path.startsWith("$cleanActive/", ignoreCase = true)
            if (inScope && (folder.name.lowercase(Locale.ROOT).contains(q) || rel.lowercase(Locale.ROOT).contains(q))) {
                matchedFolders.putIfAbsent(rel.lowercase(Locale.ROOT), sessionFolderStatsCache[folder.path] ?: folder)
            }
        }

        for (file in allKnownFiles) {
            val rel = file.relativePathInStorage.trim('/')
            val inScope = cleanActive.isEmpty() ||
                rel.startsWith(activePrefixSlash, ignoreCase = true) ||
                file.bucketOrFolderName.equals(cleanActive, ignoreCase = true) ||
                file.bucketOrFolderName.startsWith(activePrefixSlash, ignoreCase = true) ||
                (file.localFile?.absolutePath?.replace('\\', '/')?.startsWith("$cleanActive/", ignoreCase = true) == true)
            if (inScope && (file.name.lowercase(Locale.ROOT).contains(q) ||
                    rel.lowercase(Locale.ROOT).contains(q) ||
                    file.fileExtensionBadge.lowercase(Locale.ROOT).contains(q))
            ) {
                val key = (file.localFile?.absolutePath ?: rel.ifBlank { file.name }).lowercase(Locale.ROOT)
                matchedFiles.putIfAbsent(key, file)
            }
        }

        @Suppress("DEPRECATION")
        val extRoot = try {
            Environment.getExternalStorageDirectory()
        } catch (_: Exception) {
            null
        }
        val externalRootPath = extRoot?.absolutePath?.trimEnd('/') ?: "/storage/emulated/0"

        val startDir: File? = when {
            cleanActive.isEmpty() -> extRoot
            getRegisteredFolder(cleanActive) != null -> File(getRegisteredFolder(cleanActive)!!.path)
            File(activeBrowsingPath ?: "").isAbsolute && File(activeBrowsingPath ?: "").exists() -> File(activeBrowsingPath!!)
            File("/$cleanActive").exists() && !cleanActive.startsWith("storage/emulated/0", ignoreCase = true) -> File("/$cleanActive")
            extRoot != null -> File(extRoot, cleanActive)
            else -> File(externalRootPath, cleanActive)
        }

        if (startDir != null && startDir.exists() && startDir.isDirectory && isLocalPathReadable(startDir)) {
            val visited = HashSet<String>()
            fun searchRecursive(dir: File, relPrefix: String, depth: Int) {
                if (depth > 32 || (matchedFolders.size + matchedFiles.size) >= maxResults) return
                if (!isLocalPathReadable(dir)) return
                val canon = try { dir.canonicalPath } catch (_: Exception) { dir.absolutePath }
                if (!visited.add(canon)) return
                val children = dir.listFiles() ?: return
                for (child in children) {
                    if ((matchedFolders.size + matchedFiles.size) >= maxResults) break
                    val name = child.name
                    if (name.isEmpty() || name.startsWith(".")) continue
                    val childRel = if (relPrefix.isBlank()) name else "$relPrefix/$name"
                    val nameLower = name.lowercase(Locale.ROOT)
                    if (child.isDirectory) {
                        if (nameLower.contains(q)) {
                            val key = childRel.lowercase(Locale.ROOT)
                            if (key !in matchedFolders) {
                                val cached = sessionFolderStatsCache[child.absolutePath] ?: getRegisteredFolder(child.absolutePath)
                                val folderObj = cached ?: StorageFolderItem(
                                    name = name,
                                    path = child.absolutePath,
                                    relativeDisplayPath = childRel,
                                    parentFolderName = relPrefix,
                                    lastModifiedMillis = child.lastModified(),
                                    statsStatus = FolderStatsStatus.CALCULATING
                                )
                                registerFolderItem(folderObj)
                                matchedFolders[key] = folderObj
                            }
                        }
                        searchRecursive(child, childRel, depth + 1)
                    } else if (!child.isDirectory && isLocalPathReadable(child)) {
                        val extLower = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        if (nameLower.contains(q) || extLower.contains(q)) {
                            val key = child.absolutePath.lowercase(Locale.ROOT)
                            if (key !in matchedFiles) {
                                val len = resolveLocalFileByteSize(child)
                                matchedFiles[key] = DeviceMediaItem(
                                    id = "disk_${child.absolutePath.hashCode()}",
                                    name = name,
                                    localFile = child,
                                    sizeBytes = len,
                                    dateModifiedMillis = child.lastModified(),
                                    bucketOrFolderName = relPrefix,
                                    relativePathInStorage = childRel,
                                    category = FileCategory.fromFileName(name)
                                )
                            }
                        }
                    }
                }
            }
            searchRecursive(startDir, cleanActive, 0)
        }

        return matchedFolders.values.toList() to matchedFiles.values.toList()
    }

    /**
     * Scans received/downloaded APK files from the BarqSher download directory, public Downloads,
     * and transfer history records. Validates each APK via PackageManager.getPackageArchiveInfo
     * and ZIP header inspection, extracting the real App Name, Icon, Package Name, Version, and Status.
     */
    fun loadReceivedApkFiles(
        context: Context,
        @Suppress("DEPRECATION")
        downloadDir: File = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "BarqSher"
        ),
        historyRecords: List<TransferHistoryRecord> = emptyList()
    ): List<ReceivedApkItem> {
        val candidateFiles = LinkedHashMap<String, Pair<File, Boolean>>()

        // 1. From transfer history records (received APKs)
        for (rec in historyRecords) {
            val savedPath = rec.savedPath ?: continue
            val f = File(savedPath)
            if (f.exists() && f.isFile && f.canRead() &&
                (f.name.endsWith(".apk", ignoreCase = true) || f.name.endsWith(".apk.part", ignoreCase = true))
            ) {
                candidateFiles[f.absolutePath] = f to rec.sha256Verified
            }
        }

        // 2. Recursively scan downloadDir (Downloads/BarqSher) and top-level Downloads for .apk / .apk.part
        val visitedCanon = HashSet<String>()
        fun scanDirForApks(dir: File, depth: Int) {
            if (depth > 3 || !dir.exists() || !dir.isDirectory || !dir.canRead()) return
            val canon = try {
                dir.canonicalPath
            } catch (_: Exception) {
                dir.absolutePath
            }
            if (!visitedCanon.add(canon)) return
            val children = dir.listFiles() ?: return
            for (child in children) {
                if (child.name.startsWith(".")) continue
                if (child.isDirectory && child.canRead()) {
                    scanDirForApks(child, depth + 1)
                } else if (child.isFile && child.canRead()) {
                    val lower = child.name.lowercase(Locale.ROOT)
                    if (lower.endsWith(".apk") || lower.endsWith(".apk.part")) {
                        candidateFiles.putIfAbsent(child.absolutePath, child to !lower.endsWith(".part"))
                    }
                }
            }
        }

        scanDirForApks(downloadDir, 0)
        try {
            @Suppress("DEPRECATION")
            val pubDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (pubDownloads != null && pubDownloads.exists()) {
                scanDirForApks(pubDownloads, 0)
            }
        } catch (_: Exception) {
        }

        val items = mutableListOf<ReceivedApkItem>()
        for ((_, pair) in candidateFiles) {
            val (apkFile, shaVerified) = pair
            items.add(inspectApkFile(context, apkFile, shaVerified))
        }

        return items.sortedByDescending { it.lastModifiedMillis }
    }

    fun inspectApkFile(
        context: Context,
        apkFile: File,
        sha256Verified: Boolean = true
    ): ReceivedApkItem {
        val pm = context.packageManager
        val fileLen = if (apkFile.exists()) apkFile.length().coerceAtLeast(0L) else 0L
        val isPartFile = apkFile.name.endsWith(".part", ignoreCase = true)

        if (!apkFile.exists() || !apkFile.canRead() || fileLen <= 0L || isPartFile) {
            val statusLabel = when {
                isPartFile -> "تحميل غير مكتمل (.part) — لا يمكن التثبيت قبل اكتمال النقل"
                fileLen <= 0L -> "ملف فارغ (0 بايت) — غير صالح للتثبيت"
                else -> "ملف غير قابل للقراءة"
            }
            return ReceivedApkItem(
                id = "apk_${apkFile.absolutePath.hashCode()}",
                fileName = apkFile.name,
                appName = apkFile.name.removeSuffix(".part").removeSuffix(".apk"),
                packageName = "حزمة غير مكتملة",
                versionName = "-",
                versionCode = 0L,
                sizeBytes = fileLen,
                lastModifiedMillis = apkFile.lastModified(),
                file = apkFile,
                iconBitmap = null,
                isValidApk = false,
                installStatusLabel = statusLabel,
                sha256Verified = false
            )
        }

        // Check ZIP/APK magic header (PK\x03\x04)
        val hasValidZipHeader = try {
            RandomAccessFile(apkFile, "r").use { raf ->
                if (raf.length() >= 4L) {
                    val b0 = raf.read()
                    val b1 = raf.read()
                    val b2 = raf.read()
                    val b3 = raf.read()
                    b0 == 0x50 && b1 == 0x4B && b2 == 0x03 && b3 == 0x04
                } else false
            }
        } catch (_: Exception) {
            false
        }

        return try {
            val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageArchiveInfo(apkFile.absolutePath, PackageManager.PackageInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageArchiveInfo(apkFile.absolutePath, 0)
            }

            if (pkgInfo != null && pkgInfo.applicationInfo != null) {
                val appInfo = pkgInfo.applicationInfo!!
                appInfo.sourceDir = apkFile.absolutePath
                appInfo.publicSourceDir = apkFile.absolutePath

                val appLabel = try {
                    pm.getApplicationLabel(appInfo).toString().takeIf { it.isNotBlank() }
                } catch (_: Exception) {
                    null
                } ?: apkFile.nameWithoutExtension

                val iconBmp = try {
                    InstalledAppsRepository.drawableToImageBitmap(pm.getApplicationIcon(appInfo))
                } catch (_: Throwable) {
                    null
                }

                val verCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    pkgInfo.longVersionCode
                } else {
                    @Suppress("DEPRECATION")
                    pkgInfo.versionCode.toLong()
                }
                val minSdk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) appInfo.minSdkVersion else 21
                val targetSdk = appInfo.targetSdkVersion
                val isCompatible = Build.VERSION.SDK_INT >= minSdk

                ReceivedApkItem(
                    id = "apk_${apkFile.absolutePath.hashCode()}",
                    fileName = apkFile.name,
                    appName = appLabel,
                    packageName = pkgInfo.packageName ?: "unknown.package",
                    versionName = pkgInfo.versionName ?: "1.0",
                    versionCode = verCode,
                    sizeBytes = fileLen,
                    lastModifiedMillis = apkFile.lastModified(),
                    file = apkFile,
                    iconBitmap = iconBmp,
                    isValidApk = isCompatible,
                    minSdkVersion = minSdk,
                    targetSdkVersion = targetSdk,
                    installStatusLabel = if (isCompatible) {
                        if (sha256Verified) "صالح وجاهز للتثبيت (تم التحقق SHA-256)" else "صالح وجاهز للتثبيت"
                    } else {
                        "غير متوافق مع إصدار جهازك (يتطلب Android API $minSdk+)"
                    },
                    sha256Verified = sha256Verified
                )
            } else {
                ReceivedApkItem(
                    id = "apk_${apkFile.absolutePath.hashCode()}",
                    fileName = apkFile.name,
                    appName = apkFile.nameWithoutExtension,
                    packageName = if (hasValidZipHeader) "حزمة APK قياسية" else "ملف APK تالف أو غير صالح",
                    versionName = "1.0",
                    versionCode = 1L,
                    sizeBytes = fileLen,
                    lastModifiedMillis = apkFile.lastModified(),
                    file = apkFile,
                    iconBitmap = null,
                    isValidApk = hasValidZipHeader,
                    installStatusLabel = if (hasValidZipHeader) {
                        "جاهز للتثبيت عبر مثبت النظام"
                    } else {
                        "ملف APK تالف أو غير مكتمل — تعذر قراءة الحزمة"
                    },
                    sha256Verified = sha256Verified
                )
            }
        } catch (t: Throwable) {
            Log.w(LOG_TAG, "Error inspecting APK ${apkFile.name}: ${t.message}")
            ReceivedApkItem(
                id = "apk_${apkFile.absolutePath.hashCode()}",
                fileName = apkFile.name,
                appName = apkFile.nameWithoutExtension,
                packageName = "تعذر تحليل الحزمة",
                versionName = "-",
                versionCode = 0L,
                sizeBytes = fileLen,
                lastModifiedMillis = apkFile.lastModified(),
                file = apkFile,
                iconBitmap = null,
                isValidApk = hasValidZipHeader,
                installStatusLabel = if (hasValidZipHeader) "جاهز للتثبيت" else "ملف APK غير صالح",
                sha256Verified = sha256Verified
            )
        }
    }

    private fun decodeSampledFileBitmap(file: File, reqWidth: Int, reqHeight: Int): ImageBitmap? {
        return try {
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, boundsOpts)
            if (boundsOpts.outWidth <= 0 || boundsOpts.outHeight <= 0) return null
            var inSampleSize = 1
            if (boundsOpts.outHeight > reqHeight || boundsOpts.outWidth > reqWidth) {
                val halfHeight = boundsOpts.outHeight / 2
                val halfWidth = boundsOpts.outWidth / 2
                while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                    inSampleSize *= 2
                }
            }
            val decodeOpts = BitmapFactory.Options().apply {
                this.inSampleSize = max(1, inSampleSize)
                this.inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
            }
            BitmapFactory.decodeFile(file.absolutePath, decodeOpts)?.asImageBitmap()
        } catch (_: OutOfMemoryError) {
            System.gc()
            null
        } catch (_: Throwable) {
            null
        }
    }

    private fun loadMediaThumbnailFast(
        resolver: ContentResolver,
        uri: Uri?,
        mediaId: Long,
        isVideo: Boolean,
        fallbackFile: File? = null,
        cancellationSignal: CancellationSignal? = null
    ): ImageBitmap? {
        try {
            if (uri != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val thumb = runCatching {
                    resolver.loadThumbnail(uri, Size(THUMBNAIL_TARGET_PX, THUMBNAIL_TARGET_PX), cancellationSignal).asImageBitmap()
                }.getOrNull()
                if (thumb != null) return thumb
            }
            if (mediaId >= 0L) {
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = 4
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                @Suppress("DEPRECATION")
                val bmp = runCatching {
                    if (isVideo) {
                        MediaStore.Video.Thumbnails.getThumbnail(
                            resolver,
                            mediaId,
                            MediaStore.Video.Thumbnails.MINI_KIND,
                            opts
                        )
                    } else {
                        MediaStore.Images.Thumbnails.getThumbnail(
                            resolver,
                            mediaId,
                            MediaStore.Images.Thumbnails.MINI_KIND,
                            opts
                        )
                    }
                }.getOrNull()
                if (bmp != null) return bmp.asImageBitmap()
            }
            if (fallbackFile != null && fallbackFile.exists() && fallbackFile.canRead()) {
                if (!isVideo) {
                    return decodeSampledFileBitmap(fallbackFile, THUMBNAIL_TARGET_PX, THUMBNAIL_TARGET_PX)
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val bmp = runCatching {
                        ThumbnailUtils.createVideoThumbnail(
                            fallbackFile,
                            Size(THUMBNAIL_TARGET_PX, THUMBNAIL_TARGET_PX),
                            cancellationSignal
                        )
                    }.getOrNull()
                    if (bmp != null) return bmp.asImageBitmap()
                }
            }
        } catch (_: OutOfMemoryError) {
            System.gc()
        } catch (_: Throwable) {
        }
        return null
    }
}

